/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// BOARD
//-----------------------------------------------------------------------------
#ifndef BOARD_H
#define BOARD_H

#include "upsd34xx.h"
#include "lis.h"

//-----------------------------------------------------------------------------
//1ms@36MHz --> 250*double_nop();
#define DELAY_1MS   (u16)250
#define DELAY_250MS (u16)(250*DELAY_1MS)

//-----------------------------------------------------------------------------
#define LED0 PB0
#define LED5 PB5
#define LED6 PB6
#define LED7 PB7
#define LEDx_On(led);  {ClrBit(PSD8xx_reg.DATAOUT_B,led);} 
#define LEDx_Off(led); {SetBit(PSD8xx_reg.DATAOUT_B,led);} 
#define LEDs_On();  {LEDx_On(LED5);  LEDx_On(LED6);  LEDx_On(LED7);}
#define LEDs_Off(); {LEDx_Off(LED5); LEDx_Off(LED6); LEDx_Off(LED7);}

#define BUT5 (!P1_5)
#define BUT6 (!P1_6)
#define BUT7 (!P1_7)

//-----------------------------------------------------------------------------
void uPSD_Init (void);

void Time_Delay (const u16 cpu_tics);
void LEDx_toggle (u8 led, u8 required_passes);
void TestBoard1 (void);

//-----------------------------------------------------------------------------
#endif
