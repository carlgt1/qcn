/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          03/06/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// ADC
//-----------------------------------------------------------------------------
#include "upsd34xx.h"
#include "adc.h"
#include "board.h"

#if (COMPILER == KEIL)
  #pragma NOAREGS
#endif  

//-----------------------------------------------------------------------------
void ADC_Init (u8 channels)
{
  ACON   = 0x00;                // No interrupt, ADC disable
  P1SFS0 = channels;            // Activate port alternative function
  P1SFS1 = channels;            // Activate port alternative function
  ADCPS  = ADCPS_VALUE;         // Set ADC clock
  SetBit(ADCPS,ADCCE);          // Enable ADC clock 
  SetBit(ACON,ADEN);            // Enable ADC
  Time_Delay (16*DELAY_1MS);    // Wait for 16ms
}

//-----------------------------------------------------------------------------
u16 ADC_Read16 (u8 channel)
{
  xdata union16 ADAT;           //I suppose my micro is using big endian
  
  ACON &= ~(0x07<<2);           // Clear input channel
  ACON |= ((channel&0x07)<<2);  // Setup input channel

  ClrBit(ACON,ADSF);
  double_nop();
  SetBit(ACON,ADST);            // Start ADC conversion
  double_nop();
  while (!ValBit(ACON,ADSF));   // Wait for the end of the conversion

  ADAT.bit8[1] = ADAT0;
  ADAT.bit8[0] = ADAT1 & 0x03;
  
  return (ADAT.bit16);
}

//-----------------------------------------------------------------------------
void ADC_Read (u8 channel,u8 *dato_hi,u8 *dato_lo)
{
  ACON &= ~(0x07<<2);           // Clear input channel
  ACON |= ((channel&0x07)<<2);  // Setup input channel

  ClrBit(ACON,ADSF);
  double_nop();
  SetBit(ACON,ADST);            // Start ADC conversion
  double_nop();
  while (!ValBit(ACON,ADSF));   // Wait for the end of the conversion

  *dato_lo = ADAT0;
  *dato_hi = ADAT1 & 0x03;

  LEDx_toggle (LED5,15);
}

//-----------------------------------------------------------------------------
void ADC_middle (u8 *dato_hi,u8 *dato_lo)
{
  xdata unions16 dato_union;           //I suppose my micro is using big endian

  dato_union.bit8[0] = *dato_hi;
  dato_union.bit8[1] = *dato_lo;

  dato_union.bit16 -= (s16)512;

  *dato_hi = dato_union.bit8[0];
  *dato_lo = dato_union.bit8[1];
}

//-----------------------------------------------------------------------------

