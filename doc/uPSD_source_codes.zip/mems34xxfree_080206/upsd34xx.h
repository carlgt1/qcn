/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
COMPILER:      SDCC (v2.4.0)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// UPSD
//-----------------------------------------------------------------------------
#ifndef _UPSD_H_
#define _UPSD_H_

//-----------------------------------------------------------------------------
//This software is compatible with following c-compilers
//-----------------------------------------------------------------------------
#ifndef SDCC
  #define KEIL 0x11
#endif  

#ifndef SDCC
  #define SDCC 0x22
#endif  

//-----------------------------------------------------------------------------
//Select your COMPILER!
//-----------------------------------------------------------------------------
#ifndef COMPILER
  #define COMPILER SDCC
#endif  

//-----------------------------------------------------------------------------
//Hardware settings
//-----------------------------------------------------------------------------
#define FREQ_OSC    (24*1000000L)
#define FREQ_TIMERS (FREQ_OSC/12)

//-----------------------------------------------------------------------------
//Registers location in memory
//-----------------------------------------------------------------------------
//#define PSD_REG_ADDR  0x200     /* uPSD PSD Register I/O base addr, using JTAG write */
#define PSD_REG_ADDR   0x6000     /* uPSD PSD Register I/O base addr, using Bootloader */
#define USB_BASE_ADDR	 0x5800	    /* USB FIFO mapped in XDATA space */

//-----------------------------------------------------------------------------
//Do you want debug this application?
//-----------------------------------------------------------------------------
#define DEBUG_ON  0x11
#define DEBUG_OFF 0x22

#define DEBUG     DEBUG_OFF
#define USB_DEBUG DEBUG_OFF

//P1_0 <-- usb
//P1_1 <-- TIMER0 interrupt
//P1_2 <-- I2C interrrupt
//P1_3 <-- TIMER1 interrupt (using for UART) 

//-----------------------------------------------------------------------------
//TYPE DEFINITION
//-----------------------------------------------------------------------------
typedef unsigned char u8;         // unsigned 8 bit type definition
typedef signed char   s8;         // signed 8 bit type definition
typedef unsigned int  u16;        // unsigned 16 bit type definition
typedef signed int    s16;        // signed 16 bit type definition
typedef unsigned long u32;        // unsigned 32 bit type definition
typedef signed long   s32;        // signed 32 bit type definition
typedef unsigned char uchar;
typedef unsigned int  uint;
typedef unsigned char BOOL;
typedef volatile u8   vu8;
typedef volatile s8   vs8;
typedef volatile u16  vu16;
typedef volatile s16  vs16;
typedef volatile u32  vu32;
typedef volatile s32  vs32;

typedef union { 
  u16 bit16;
  u8  bit8[2];
} union16;

typedef union { 
  s16 bit16;
  u8  bit8[2];
} unions16;

typedef union { 
  u32 bit32;
  u8  bit8[4];
} union32;

//-----------------------------------------------------------------------------
//COMPILER DEPENDENT
//-----------------------------------------------------------------------------
#if (COMPILER == KEIL)
  #include <intrins.h>
  #define SFR(NAME,ADDR) sfr NAME = ADDR;
  #define SBIT(NAME,REG,ADDR,BIT) sbit NAME = REG^BIT;  
#endif

#if (COMPILER == SDCC)
  #define SFR(NAME,ADDR) sfr at ADDR NAME;
    #define SBIT(NAME,REG,ADDR,BIT) sbit at (ADDR+BIT) NAME;      
#endif

//-----------------------------------------------------------------------------
//GENERAL
//-----------------------------------------------------------------------------
#ifndef min
  #define min(a,b) (((a)<(b)) ? (a) : (b))
#endif

#ifndef TRUE
  #define TRUE 0x01
#endif

#ifndef FALSE
  #define FALSE 0x00
#endif

#ifndef ON
  #define ON 0x01
#endif

#ifndef OFF
  #define OFF 0x00
#endif

#ifndef NULL
  #define NULL 0x00
#endif

#define pi 3.1415926

#if (COMPILER == SDCC)
  #define _nop_(); {_asm nop _endasm;}
#endif

#define double_nop(); {_nop_(); _nop_();}
#define Wait(); {u8 i; for(i=0;i<0xFF;i++) double_nop;}

//-----------------------------------------------------------------------------
//BIT OPERATION
//-----------------------------------------------------------------------------
#define SetBit(VAR,Place)         ( VAR |= (1<<Place) )
#define ClrBit(VAR,Place)         ( VAR &= ((1<<Place)^255) )
#define ValBit(VAR,Place)         ( VAR & (1<<Place) )
#define MskBit(Dest,Msk,Src)      ( Dest = (Msk & Src) | ((~Msk) & Dest) )

//-----------------------------------------------------------------------------
//GENERAL BIT DEFINITION
//-----------------------------------------------------------------------------
#define bit0 0
#define bit1 1
#define bit2 2
#define bit3 3
#define bit4 4
#define bit5 5
#define bit6 6
#define bit7 7

//-----------------------------------------------------------------------------
//PSD REGISTERS
//-----------------------------------------------------------------------------
//typedef xdata struct REG_PSD_struct {
typedef struct REG_PSD_struct {  
        unsigned char DATAIN_A;         // PSD_REG_BASE +0x00
        unsigned char DATAIN_B;         //              +0x01
        unsigned char CONTROL_A;        //              +0x02
        unsigned char CONTROL_B;        //              +0x03
        unsigned char DATAOUT_A;        //              +0x04
        unsigned char DATAOUT_B;        //              +0x05
        unsigned char DIRECTION_A;      //              +0x06
        unsigned char DIRECTION_B;      //              +0x07
        unsigned char DRIVE_A;          //              +0x08
        unsigned char DRIVE_B;          //              +0x09
        unsigned char IMC_A;            //              +0x0A
        unsigned char IMC_B;            //              +0x0B
        unsigned char OUTENABLE_A;      //              +0x0C
        unsigned char OUTENABLE_B;      //              +0x0D
        unsigned char res2[2];          //              space
        unsigned char DATAIN_C;         //              +0x10
        unsigned char DATAIN_D;         //              +0x11
        unsigned char DATAOUT_C;        //              +0x12 
        unsigned char DATAOUT_D;        //              +0x13
        unsigned char DIRECTION_C;      //              +0x14
        unsigned char DIRECTION_D;      //              +0x15
        unsigned char DRIVE_C;          //              +0x16
        unsigned char DRIVE_D;          //              +0x17
        unsigned char IMC_C;            //              +0x18
        unsigned char res1a;            //              space
        unsigned char OUTENABLE_C;      //              +0x1A
        unsigned char OUTENABLE_D;      //              +0x1B
        unsigned char res4[4];          //              space
        unsigned char OMC_AB;           //              +0x20
        unsigned char OMC_BC;           //              +0x21
        unsigned char OMCMASK_AB;       //              +0x22
        unsigned char OMCMASK_BC;       //              +0x23
        unsigned char res8c[0x8C];      //              space
        unsigned char PMMR0;            //              +0xB0
        unsigned char res1b;            //              space
        unsigned char PMMR1;            //              +0xB2
        unsigned char res1c;            //              space
        unsigned char PMMR2;            //              +0xB4
        unsigned char res0B[0x0B];      //              space
        unsigned char MAINPROTECT;      //              +0xC0
        unsigned char res1d;            //              space
        unsigned char ALTPROTECT;       //              +0xC2
        unsigned char res4a[4];         //              space
        unsigned char JTAG;             //              +0xC7
        unsigned char res18[0x18];      //              space
        unsigned char PAGE;             //              +0xE0
        unsigned char res1e;            //              space
        unsigned char VM;               //              +0xE2
        unsigned char res29[0x1d];      //              space
} PSD_REGS;

//-----------------------------------------------------------------------------
//PSD BIT REGISTERS
//-----------------------------------------------------------------------------
//--- PSD PORTA ---
#define PA0   bit0
#define PA1   bit1  
#define PA2   bit2  
#define PA3   bit3  
#define PA4   bit4  
#define PA5   bit5  
#define PA6   bit6  
#define PA7   bit7  

//--- PSD PORTB ---
#define PB0   bit0
#define PB1   bit1  
#define PB2   bit2  
#define PB3   bit3  
#define PB4   bit4  
#define PB5   bit5  
#define PB6   bit6  
#define PB7   bit7  

//--- PSD PORTC ---
#define PC0   bit0
#define PC1   bit1  
#define PC2   bit2  
#define PC3   bit3  
#define PC4   bit4  
#define PC5   bit5  
#define PC6   bit6  
#define PC7   bit7  

//--- PSD PORTD ---
#define PD0   bit0
#define PD1   bit1  
#define PD2   bit2  

//--- PSD JTAG ---
#define JEN   bit0    // JTAG enable

//--- PSD PMMR0 ---
#define APD_ENABLE    bit1
#define PLD_TURBO     bit3
#define PLD_ARRAY_CLK bit4
#define PLD_MCELL_CLK bit5

//--- PSD PMMR2 ---
#define PLD_CNTL0     bit2
#define PLD_CNTL1     bit3
#define PLD_CNTL2     bit4
#define PLD_ALE       bit5
#define PLD_DBE       bit6

//--- PSD VM ---
#define SRAM_CODE     bit0
#define EE_CODE       bit1
#define FL_CODE       bit2
#define EE_DATA       bit3
#define FL_DATA       bit4
#define PIO_EN        bit7

//-----------------------------------------------------------------------------
//STANDARD 8051 MCU REGISTERS
//-----------------------------------------------------------------------------
SFR(P1        ,0x90) // Port 1
SFR(P3        ,0xB0) // Port 3
SFR(PSW       ,0xD0) // Program Status Word
SFR(ACC       ,0xE0) // Accumulator
SFR(B         ,0xF0) // Register B
SFR(SP        ,0x81) // Stack Pointer
SFR(DPL       ,0x82) // Data Pointer low byte
SFR(DPH       ,0x83) // Data Pointer high byt
SFR(PCON      ,0x87) // MCU Power Control Register
SFR(TCON      ,0x88) // Timer / Counter Control
SFR(TMOD      ,0x89) // Timer / Counter Mode
SFR(TL0       ,0x8A) // Timer 0 low byte
SFR(TL1       ,0x8B) // Timer 1 low byte
SFR(TH0       ,0x8C) // Timer 0 high byte
SFR(TH1       ,0x8D) // Timer 1 high byte
SFR(IE        ,0xA8) // Interrupt Enable (main)
SFR(IP        ,0xB8) // Interrupt Priority (main) 
SFR(SCON      ,0x98) // UART0 Serial Control
SFR(SBUF      ,0x99) // UART0 Serial Buffer
 
//-----------------------------------------------------------------------------
//COMMON 8052 EXTENSIONS
//-----------------------------------------------------------------------------
SFR(T2CON     ,0xC8) // Timer 2 Control
SFR(RCAP2L    ,0xCA) // Timer 2 Reload low byte
SFR(RCAP2H    ,0xCB) // Timer 2 Reload high byte
SFR(TL2       ,0xCC) // Timer 2 low byte
SFR(TH2       ,0xCD) // Timer 2 high byte

//-----------------------------------------------------------------------------
//UPSD 3400 EXTENSIONS
//-----------------------------------------------------------------------------
SFR(P4        ,0xC0) // New port 4
SFR(P1SFS0    ,0x8E) // Port 1 I/O select Register 0
SFR(P1SFS1    ,0x8F) // Port 1 I/O select Register 1
SFR(P3SFS     ,0x91) // Port 3 I/O select
SFR(P4SFS0    ,0x92) // Port 4 I/O select Register 0
SFR(P4SFS1    ,0x93) // Port 4 I/O select Register 1

//--- ADC SFRs ---
SFR(ADCPS     ,0x94) // ADC Clock Control Register
SFR(ADAT0     ,0x95) // ADC Data Register1 ADAT[9:8]
SFR(ADAT1     ,0x96) // ADC Data Register0 ADAT[7:0]
SFR(ACON      ,0x97) // ADC Control Register

//--- UART1 SFRS ---
SFR(SCLK1     ,0xD1) // UART1 Serial Clock     (!CHECK THIS!)
SFR(SCON1     ,0xD8) // UART1 Serial Control
SFR(SBUF1     ,0xD9) // UART1 Serial Buffer

//--- PCA SFRs ---
SFR(PCACL0    ,0xA2) // PCA0 Counter Low
SFR(PCACH0    ,0xA3) // PCA0 Counter High
SFR(PCACON0   ,0xA4) // PCA0 Configuration Register
SFR(PCASTA    ,0xA5) // PCA0, PCA1 Status Register
SFR(PCACL1    ,0xBA) // PCA1 Counter Low
SFR(PCACH1    ,0xBB) // PCA1 Counter High
SFR(PCACON1   ,0xBC) // PCA1 Configuration Register 
SFR(PWMF0     ,0xB4) // PCA0 PWM Frequency
SFR(PWMF1     ,0xC7) // PCA1 PWM Frequency

//--- TCM SFRs ---
SFR(TCMMODE0  ,0xA9) // TCM0 Mode Register   
SFR(TCMMODE1  ,0xAA) // TCM1 Mode Register   
SFR(TCMMODE2  ,0xAB) // TCM2 Mode Register
SFR(TCMMODE3  ,0xBD) // TCM3 Mode Register
SFR(TCMMODE4  ,0xBE) // TCM4 Mode Register
SFR(TCMMODE5  ,0xBF) // TCM5 Mode Register
SFR(CAPCOML0  ,0xAC) // TCM0 Capture/Compare Register Low  
SFR(CAPCOMH0  ,0xAD) // TCM0 Capture/Compare Register High  
SFR(CAPCOML1  ,0xAF) // TCM1 Capture/Compare Register Low  
SFR(CAPCOMH1  ,0xB1) // TCM1 Capture/Compare Register High  
SFR(CAPCOML2  ,0xB2) // TCM2 Capture/Compare Register Low  
SFR(CAPCOMH2  ,0xB3) // TCM2 Capture/Compare Register High 
SFR(CAPCOML3  ,0xC1) // TCM3 Capture/Compare Register Low  
SFR(CAPCOMH3  ,0xC2) // TCM3 Capture/Compare Register High 
SFR(CAPCOML4  ,0xC3) // TCM4 Capture/Compare Register Low  
SFR(CAPCOMH4  ,0xC4) // TCM4 Capture/Compare Register High 
SFR(CAPCOML5  ,0xC5) // TCM5 Capture/Compare Register Low  
SFR(CAPCOMH5  ,0xC6) // TCM5 Capture/Compare Register High 

//--- WDT SFRs ---
SFR(WDTRST    ,0xA6) // Watch Dog Reset         (!WDRST & WDKEY by PF!)
SFR(WDTKEY    ,0xAE) // Watch Dog Key Enable

//--- INTERRUPT 2 SFRs ---
SFR(IEA       ,0xA7) // Interrupt Enable (2nd)
SFR(IPA       ,0xB7) // Interrupt Priority (2nd)

//--- I2C SFRs ---
SFR(S1SETUP   ,0xDB) // I2C S1 Setup
SFR(S1CON     ,0xDC) // I2C Bus Control Register
SFR(S1STA     ,0xDD) // I2C Bus Status
SFR(S1DAT     ,0xDE) // I2C Data Hold Register
SFR(S1ADR     ,0xDF) // I2C Bus Address

//--- SPI SFRs ----
SFR(SPICLKD   ,0xD2) // SPI Clock Divisor
SFR(SPISTAT   ,0xD3) // SPI Status Register
SFR(SPITDR    ,0xD4) // SPI Transmit Register
SFR(SPIRDR    ,0xD5) // SPI Receive Register
SFR(SPICON0   ,0xD6) // SPI Control0 Register
SFR(SPICON1   ,0xD7) // SPI Control1 Register

//--- IrDA SFRs ----
SFR(IRDACON   ,0xCE) // IrDA Configuration Register

//--- MCU Debug ---
SFR(DSTAT     ,0xCF) // Debug MCU Status     (!not confirmed!)
SFR(DIR       ,0x9E) // Debug Index Register (!not confirmed!)
SFR(DVR       ,0x9F) // Debug Value Register (!not confirmed!)

//--- MCU BUS control ---
SFR(BUSCON    ,0x9D) // Bus wait cycle control

//--- Clock Control SFRs ---
SFR(CCON0     ,0xF9) // PLL, Debugber, CPU Clock Control
SFR(CCON1     ,0xFA) // PLL Divider Input  (!not confirmed!)
SFR(CCON2     ,0xFB) // PCA0 Clock Control
SFR(CCON3     ,0xFC) // PCA1 Clock Control

//--- XDATA Pointer SFRs ---
SFR(DPTC      ,0x85) // XData Pointer Control
SFR(DPTM      ,0x86) // XData Pointer Mode

//--- Program Counter ---
SFR(PCL       ,0x9A) // Program Counter Low (!not confirmed!)
SFR(PCH       ,0x9B) // Program Counter High (!not confirmed!)

//--- Temporary SFRs ---
SFR(TSFR0     ,0xB5) // Temporary SFR0 (!not confirmed!)
SFR(TSFR1     ,0xB6) // Temporary SFR1 (!not confirmed!)

//--- USB SFRs --- 
SFR(UADDR     ,0xE2) // USB Address
SFR(UPAIR     ,0xE3) // USB Pairing Control
SFR(UIE0      ,0xE4) // USB Global INT Enable
SFR(UIE1      ,0xE5) // USB IN FIFO INT Enable
SFR(UIE2      ,0xE6) // USB OUT FIFO INT Enable
SFR(UIE3      ,0xE7) // USB IN FIFO NACK INT Enable
SFR(UIF0      ,0xE8) // USB Global INT Flag
SFR(UIF1      ,0xE9) // USB IN FIFO INT Flag
SFR(UIF2      ,0xEA) // USB OUT FIFO INT Flag
SFR(UIF3      ,0xEB) // USB IN FIFO NACK INT Flag
SFR(UCTL      ,0xEC) // USB Control
SFR(USTA      ,0xED) // USB Status
SFR(USEL      ,0xEF) // USB EP Select
SFR(UCON      ,0xF1) // USB EP Control
SFR(USIZE     ,0xF2) // USB FIFO Valid Size
SFR(UBASEH    ,0xF3) // USB Base Addr High
SFR(UBASEL    ,0xF4) // USB Base Addr Low
SFR(USCI      ,0xF5) // USB Setup CMD Index
SFR(USCV      ,0xF6) // USB Setup CMD Value

//-----------------------------------------------------------------------------
//STANDARD 8051 MCU BIT REGISTERS (sorted by address in memory)
//-----------------------------------------------------------------------------
//--- TCON, Standard 8051 timer control - (0x88) ---

#define TCON_ADDR 0x88
SBIT(TCON_TF1      ,TCON,TCON_ADDR,7)
SBIT(TCON_TR1      ,TCON,TCON_ADDR,6)
SBIT(TCON_TF0      ,TCON,TCON_ADDR,5)
SBIT(TCON_TR0      ,TCON,TCON_ADDR,4)
SBIT(TCON_IE1      ,TCON,TCON_ADDR,3)
SBIT(TCON_IT1      ,TCON,TCON_ADDR,2)
SBIT(TCON_IE0      ,TCON,TCON_ADDR,1)
SBIT(TCON_IT0      ,TCON,TCON_ADDR,0)

//--- P1 - GPIO - (0x90) ---
#define P1_ADDR 0x90
SBIT(P1_7          ,P1,P1_ADDR,7) // bit 7 of P1
SBIT(P1_6          ,P1,P1_ADDR,6) // bit 6 of P1
SBIT(P1_5          ,P1,P1_ADDR,5) // bit 5 of P1
SBIT(P1_4          ,P1,P1_ADDR,4) // bit 4 of P1
SBIT(P1_3          ,P1,P1_ADDR,3) // bit 3 of P1
SBIT(P1_2          ,P1,P1_ADDR,2) // bit 2 of P1
SBIT(P1_1          ,P1,P1_ADDR,1) // bit 1 of P1
SBIT(P1_0          ,P1,P1_ADDR,0) // bit 0 of P1

//--- P1 - Alternate 1 ---
SBIT(P1_SPI_SSEL   ,P1,P1_ADDR,7) // SPI SSEL
SBIT(P1_SPI_TxD    ,P1,P1_ADDR,6) // SPI TxD
SBIT(P1_SPI_RxD    ,P1,P1_ADDR,5) // SPI RxD
SBIT(P1_SPI_SCLK   ,P1,P1_ADDR,4) // SPI SCLK
SBIT(P1_UART1_TxD  ,P1,P1_ADDR,3) // UART1 TxD
SBIT(P1_UART1_RxD  ,P1,P1_ADDR,2) // UART1 RxD
SBIT(P1_TMR2_TRG   ,P1,P1_ADDR,1) // Timer 2 Trigger Input
SBIT(P1_TMR2_CNT   ,P1,P1_ADDR,0) // Timer 2 Count Input

//--- P1 - Alternate 2 --
SBIT(P1_ADC7       ,P1,P1_ADDR,7)	// ADC Channel 7
SBIT(P1_ADC6       ,P1,P1_ADDR,6)	// ADC Channel 6
SBIT(P1_ADC5       ,P1,P1_ADDR,5)	// ADC Channel 5
SBIT(P1_ADC4       ,P1,P1_ADDR,4)	// ADC Channel 4
SBIT(P1_ADC3       ,P1,P1_ADDR,3)	// ADC Channel 3
SBIT(P1_ADC2       ,P1,P1_ADDR,2)	// ADC Channel 2
SBIT(P1_ADC1       ,P1,P1_ADDR,1)	// ADC Channel 1
SBIT(P1_ADC0       ,P1,P1_ADDR,0)	// ADC Channel 0

//--- SCON, Standard 8051 Uart Control - (0x98) ---
#define SCON_ADDR 0x98
SBIT(SCON_SM0      ,SCON,SCON_ADDR,7)
SBIT(SCON_SM1      ,SCON,SCON_ADDR,6)
SBIT(SCON_SM2      ,SCON,SCON_ADDR,5)
SBIT(SCON_REN      ,SCON,SCON_ADDR,4)
SBIT(SCON_TB8      ,SCON,SCON_ADDR,3)
SBIT(SCON_RB8      ,SCON,SCON_ADDR,2)
SBIT(SCON_TI       ,SCON,SCON_ADDR,1)
SBIT(SCON_RI       ,SCON,SCON_ADDR,0)

//--- IE - (0xA8) ---
#define IE_ADDR 0xA8
SBIT(IE_EA         ,IE,IE_ADDR,7) // Enable All interrupts
SBIT(IE_EDB        ,IE,IE_ADDR,6) // Enable Debug
SBIT(IE_ET2        ,IE,IE_ADDR,5) // Timer 2
SBIT(IE_ES0        ,IE,IE_ADDR,4) // Uart 0  
SBIT(IE_ET1        ,IE,IE_ADDR,3) // Timer 1
SBIT(IE_EX1        ,IE,IE_ADDR,2) // External Int1
SBIT(IE_ET0        ,IE,IE_ADDR,1) // Timer 0
SBIT(IE_EX0        ,IE,IE_ADDR,0) // External Int0

//--- P3 - GPIO - (0xB0) ---
#define P3_ADDR 0xB0
SBIT(P3_7          ,P3,P3_ADDR,7) // bit 7 of P3
SBIT(P3_6          ,P3,P3_ADDR,6) // bit 6 of P3
SBIT(P3_5          ,P3,P3_ADDR,5) // bit 5 of P3
SBIT(P3_4          ,P3,P3_ADDR,4) // bit 4 of P3
SBIT(P3_3          ,P3,P3_ADDR,3) // bit 3 of P3
SBIT(P3_2          ,P3,P3_ADDR,2) // bit 2 of P3
SBIT(P3_1          ,P3,P3_ADDR,1) // bit 1 of P3
SBIT(P3_0          ,P3,P3_ADDR,0) // bit 0 of P3

//--- P3 - Alternate 1 --
SBIT(P3_I2CSC      ,P3,P3_ADDR,7)	// I2C Serial Clock
SBIT(P3_I2CSD      ,P3,P3_ADDR,6)	// I2C Serial Data
SBIT(P3_CNTR1      ,P3,P3_ADDR,5)	// Counter 1 Input
SBIT(P3_CNTR0      ,P3,P3_ADDR,4)	// Counter 0 Input
SBIT(P3_INT1       ,P3,P3_ADDR,3)	// Ext Int 1 / Timer 1 Gate	
SBIT(P3_INT0       ,P3,P3_ADDR,2)	// Ext Int 0 / Timer 0 Gate
SBIT(P3_UART0_TxD  ,P3,P3_ADDR,1)	// UART0 TxD
SBIT(P3_UART0_RxD  ,P3,P3_ADDR,0)	// UART0 RxD

//--- IP - (0xB8) ---
#define IP_ADDR 0xB8
SBIT(IP_PDB        ,IP,IP_ADDR,6) // Debug
SBIT(IP_PT2        ,IP,IP_ADDR,5) // Timer 2
SBIT(IP_PS         ,IP,IP_ADDR,4) // Usart 0
SBIT(IP_PT1        ,IP,IP_ADDR,3) // Timer 1
SBIT(IP_PX1        ,IP,IP_ADDR,2) // Ext Int1
SBIT(IP_PT0        ,IP,IP_ADDR,1) // Timer 0
SBIT(IP_PX0        ,IP,IP_ADDR,0) // Ext Int 0

//--- P4 - GPIO - (0xC0) ---
#define P4_ADDR 0xC0
SBIT(P4_7          ,P4,P4_ADDR,7) // bit 7 of P4
SBIT(P4_6          ,P4,P4_ADDR,6) // bit 6 of P4
SBIT(P4_5          ,P4,P4_ADDR,5) // bit 5 of P4
SBIT(P4_4          ,P4,P4_ADDR,4) // bit 4 of P4
SBIT(P4_3          ,P4,P4_ADDR,3) // bit 3 of P4
SBIT(P4_2          ,P4,P4_ADDR,2) // bit 2 of P4
SBIT(P4_1          ,P4,P4_ADDR,1) // bit 1 of P4
SBIT(P4_0          ,P4,P4_ADDR,0) // bit 0 of P4

//--- P4 - Alternate 1  ---
SBIT(P4_PCA1_XCLK  ,P4,P4_ADDR,7)	// PCA1
SBIT(P4_TCM5       ,P4,P4_ADDR,6) // TCM5
SBIT(P4_TCM4       ,P4,P4_ADDR,5) // TCM4
SBIT(P4_TCM3       ,P4,P4_ADDR,4) // TCM3
SBIT(P4_PCA0_XCLK  ,P4,P4_ADDR,3)	// PCA0
SBIT(P4_TCM2       ,P4,P4_ADDR,2) // TCM2
SBIT(P4_TCM1       ,P4,P4_ADDR,1) // TCM1
SBIT(P4_TCM0       ,P4,P4_ADDR,0) // TCM0

//--- P4 - Alternate 2 ---  
SBIT(P4_SPI_SSE    ,P4,P4_ADDR,7) // SPI SSEL
SBIT(P4_SPI_TxD    ,P4,P4_ADDR,6) // SPI TxD
SBIT(P4_SPI_RxD    ,P4,P4_ADDR,5) // SPI RxD
SBIT(P4_SPI_SCLK   ,P4,P4_ADDR,4) // SPI SCLK
SBIT(P4_UART1_TxD  ,P4,P4_ADDR,3) // UART1 TxD
SBIT(P4_UART1_RxD  ,P4,P4_ADDR,2) // UART1 RxD
SBIT(P4_TMR2_TRG   ,P4,P4_ADDR,1) // Timer 2 Trigger Input
SBIT(P4_TMR2_CNT   ,P4,P4_ADDR,0) // Timer 2 Count Input

//--- T2CON - (0xC8) ---
#define T2CON_ADDR 0xC8
SBIT(T2CON_TF2     ,T2CON,T2CON_ADDR,7)
SBIT(T2CON_EXF2    ,T2CON,T2CON_ADDR,6)
SBIT(T2CON_RCLK    ,T2CON,T2CON_ADDR,5)
SBIT(T2CON_TCLK    ,T2CON,T2CON_ADDR,4)
SBIT(T2CON_EXEN2   ,T2CON,T2CON_ADDR,3)
SBIT(T2CON_TR2     ,T2CON,T2CON_ADDR,2)
SBIT(T2CON_C_T2    ,T2CON,T2CON_ADDR,1)
SBIT(T2CON_CP_RL2  ,T2CON,T2CON_ADDR,0)

//--- PSW - (0xD0) ---
#define PSW_ADDR 0xD0
SBIT(PSW_CY        ,PSW,PSW_ADDR,7)
SBIT(PSW_AC        ,PSW,PSW_ADDR,6)
SBIT(PSW_F0        ,PSW,PSW_ADDR,5)
SBIT(PSW_RS1       ,PSW,PSW_ADDR,4)
SBIT(PSW_RS0       ,PSW,PSW_ADDR,3)
SBIT(PSW_OV        ,PSW,PSW_ADDR,2)
SBIT(PSW_P         ,PSW,PSW_ADDR,0) 

//--- SCON1 - (0xE0) ---
#define SCON1_ADDR 0xE0
SBIT(SCON1_SM01    ,SCON1,SCON1_ADDR,7)
SBIT(SCON1_SM11    ,SCON1,SCON1_ADDR,6)
SBIT(SCON1_SM21    ,SCON1,SCON1_ADDR,5)
SBIT(SCON1_REN1    ,SCON1,SCON1_ADDR,4)
SBIT(SCON1_TB81    ,SCON1,SCON1_ADDR,3)
SBIT(SCON1_RB81    ,SCON1,SCON1_ADDR,2)
SBIT(SCON1_TI1     ,SCON1,SCON1_ADDR,1)
SBIT(SCON1_RI1     ,SCON1,SCON1_ADDR,0)

//--- USB - (0xE8) ---
#define UIF0_ADDR 0xE8
SBIT(bGLF          ,UIF0,UIF0_ADDR,7)
SBIT(bINF          ,UIF0,UIF0_ADDR,6)
SBIT(bOUTF         ,UIF0,UIF0_ADDR,5)
SBIT(bNAKF         ,UIF0,UIF0_ADDR,4)
SBIT(bRSTF         ,UIF0,UIF0_ADDR,3)
SBIT(bSUSPENDF     ,UIF0,UIF0_ADDR,2)
SBIT(bEOPF         ,UIF0,UIF0_ADDR,1)
SBIT(bRESUMEF      ,UIF0,UIF0_ADDR,0)

//-----------------------------------------------------------------------------
//BITS OF STANDARD 8051 MCU BIT REGISTERS
//-----------------------------------------------------------------------------
//--- PCON - Power Control Register ---
#define SMOD0     bit7 // Baud Rate bit for UART0 
#define SMOD1     bit6 // Baud Rate bit for UART1
#define POR       bit4 // Power on reset
#define RCLK1     bit3 // Received clock flag (UART1)
#define TCLK1     bit2 // Transmit clock flag (UART1)
#define PD        bit1 // Power Down Mode
#define IDLE      bit0 // Idle Mode

//--- TMOD - Timer Mode Register ---
#define GATE1     bit7;
#define C_T1      bit6;
#define M11       bit5;
#define M10       bit4;
#define GATE0     bit3;
#define C_T0      bit2;
#define M01       bit1;
#define M00       bit0;

//-----------------------------------------------------------------------------
//BITS OF COMMON 8052 EXTENSIONS
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
//BITS OF UPSD 3400 EXTENSIONS
//-----------------------------------------------------------------------------
//--- P1SFS0 & P1SFS1 ---
// 0 & x = Default
// 1 & 0 = Alternate 1
// 1 & 1 = Alternate 2
#define SPI_SEL_PIN  bit7
#define SPI_TXD_PIN  bit6
#define SPI_RXD_PIN  bit5
#define SPI_CLK_PIN  bit4

//--- P3SFS ---
// 0 = Default
// 1 = Alternate
#define I2C_SCL_PIN   bit7
#define I2C_SDA_PIN   bit6
#define UART_TXD0_PIN bit1
#define UART_RXD0_PIN bit0

//--- P4SFS0 & P4SFS1 ---
// 0 & x = Default
// 1 & 0 = Alternate 1
// 1 & 1 = Alternate 2

//--- ADC SFRs ---
//--- ACON ---
#define AINTF     bit7
#define AINTEN    bit6
#define ADEN      bit5
#define ADS2      bit4
#define ADS1      bit3
#define ADS0      bit2
#define ADST      bit1
#define ADSF      bit0

//--- ADCPS ---
#define ADCCE     bit3

//--- UART1 SFRS ---
//--- SCLK1 ---

//--- INTERRUPT 2 SFRs ---
//--- IEA ---
#define EADC      bit7
#define ESPI      bit6
#define EPCA      bit5 
#define ES2       bit4
#define EI2C      bit1
#define EUSB      bit0

//--- IPA ---
#define PADC      bit7
#define PSPI      bit6
#define PPCA      bit5 
#define PS2       bit4
#define PI2C      bit1
#define PUSB      bit0

//--- I2C SFRs ---
//--- S1CON ---
#define CR2       bit7
#define ENI       bit6 
#define STA       bit5 
#define STO       bit4
#define ADDR      bit3
#define AA        bit2
#define CR1       bit1
#define CR0       bit0

//--- S1STA ---
#define GC        bit7
#define STOP      bit6 
#define INTR      bit5
#define TX_MODE   bit4
#define BBUSY     bit3
#define BLOST     bit2
#define ACK_REP   bit1
#define SLV       bit0

//--- SPI SFRs ---

//--- IrDA SFRs ---
//--- IRDACON ---
#define IRDAEN    bit6
#define BIT_PULSE bit5
#define CDIV4     bit4
#define CDIV3     bit3
#define CDIV2     bit2
#define CDIV1     bit1
#define CDOV0     bit0

//--- MCU Debug ---

//--- MCU BUS control ---

//--- Clock Control SFRs ---

//--- USB SFRs ---
//--- UPAIR ---
#define	PR1IN		  0x01
#define	PR3IN		  0x02
#define	PR1OUT		0x04
#define	PR3OUT		0x08 

//--- UIE0 ---
#define	RESUMEIE	0x01
#define	EOPIE		  0x02
#define	SUSPENDIE	0x04
#define	RSTIE		  0x08 

//--- UIE1 ---
#define	IN0IE		  0x01
#define	IN1IE		  0x02
#define	IN2IE		  0x04
#define	IN3IE		  0x08
#define	IN4IE		  0x10

//--- UIE2 ---
#define	OUT0IE		0x01
#define	OUT1IE		0x02
#define	OUT2IE		0x04
#define	OUT3IE		0x08
#define	OUT4IE		0x10

//--- UIE3 ---
#define	NAK0IE		0x01
#define	NAK1IE		0x02
#define	NAK2IE		0x04
#define	NAK3IE		0x08
#define	NAK4IE		0x10

//--- UCTL ---
#define	WAKEUP		0x01
#define	VISIBLE		0x02
#define	USBEN		  0x04 

//--- USTA ---
#define	SETUP		  0x04

//--- USEL ---
#define	INDIR		  0x00
#define	OUTDIR		0x80
#define	SELEP0		0x00
#define	SELEP1		0x01
#define	SELEP2		0x02
#define	SELEP3		0x03
#define	SELEP4		0x04

//--- UCON ---
#define	EPFIFO_BSY  0x01
#define	TOGGLE		  0x02
#define	STALL		    0x04
#define	ENABLE_FIFO	0x08 

//--- UIF1 ---
#define IN0F		  0x01
#define IN1F		  0x02
#define IN2F		  0x04
#define IN3F		  0x08
#define IN4F		  0x10

//--- UIF2 ---
#define OUT0F		  0x01
#define OUT1F		  0x02
#define OUT2F		  0x04
#define OUT3F		  0x08
#define OUT4F		  0x10

//-----------------------------------------------------------------------------
//INTERRUPT VECTORS
//Interrupt Address = (Number * 8) + 3
//-----------------------------------------------------------------------------
#define IE0_VECTOR        0      //0x03 External Interrupt 0
#define TF0_VECTOR        1      //0x0B Timer 0                     (confirmed)
#define IE1_VECTOR        2      //0x13 External Interrupt 1
#define TF1_VECTOR        3      //0x1B Timer 1                     (confirmed) 
#define SIO_VECTOR        4      //0x23 Serial Port 0
#define TF2_VECTOR        5      //0x2B Timer 2
#define USB_VECTOR			  6		   //0x33 USB
#define ADC_VECTOR			  7		   //0x3B ADC
#define I2C_VECTOR			  8		   //0x43 I2C
#define UART1_VECTOR   		9		   //0x4B Serial Port 1
#define SPI_VECTOR			  10		 //0x53 SPI
#define PCA_VECTOR			  11		 //0x5B PCA
#define DBG_VECTOR			  12		 //0x63 DEBUG (Highest Priority)

//-----------------------------------------------------------------------------
//PROVIDE PSD REGISTER TO ALL SOURCE FILES --> EXTERN
//DON'T FORGET TO DEFINE IT IN MAIN
//-----------------------------------------------------------------------------
#if (COMPILER == KEIL)
  extern xdata PSD_REGS PSD8xx_reg;
#endif

#if (COMPILER == SDCC)
  extern xdata at PSD_REG_ADDR PSD_REGS PSD8xx_reg;    
#endif

//-----------------------------------------------------------------------------
#endif
