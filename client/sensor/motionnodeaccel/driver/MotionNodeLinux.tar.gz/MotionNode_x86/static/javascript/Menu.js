/**
  @file    javascript/Menu.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/

/**
  Open a drop down command menu under some DOM
  element. Menu is defined by the "definition"
  and "id" input parameters to "open".
*/
var GLI_Menu = function()
{
  var _element_id = 'menu';
  var _accesskey_id = 'command_accesskey';

  return {
    element_id : _element_id,
    
    open : function(event, element, definition, id, is_link_menu)
    {
      var menu = document.getElementById(_element_id);
      if (menu) {
        menu.innerHTML = '';
    
        position = GLI_Position.compute(element);
        menu.style.left = position.left.toString() + 'px';
        menu.style.top = (position.bottom + 4).toString() + 'px';

        var content = null;
        if (true === is_link_menu) {
          content = GLI_Menu.make_link(definition);
        } else {
          content = GLI_Menu.make(definition, id);
        }
        menu.appendChild(content); 
        menu.style.display = 'block';
    
        // Catch the event here. Otherwise we will just handle the parent
        // click event and close the menu again.
        GLI_EventListener.stop(event);    
    
        // Any global click event should close the current menu.
        GLI_EventListener.insert(null, 'click', GLI_Menu.close);
      }
    },
    make : function(definition, id)
    {
      var table = document.createElement('table');
    
      var body = document.createElement('tbody');
      table.appendChild(body);

      var n_active = 0;
      for (var i=0; i<definition.length; i++) {
        var row = document.createElement('tr');
        body.appendChild(row);
       
        var column = document.createElement('td');
        row.appendChild(column);
      
        var column2 = document.createElement('td');
        row.appendChild(column2);
          
        if ((undefined === definition[i]) || (undefined === definition[i].command)) {
          column.className = 'separator';
          column2.className = 'separator';
        } else {
          // Generate the name of the command. Underline the shortcut key
          // if it is available. Do not create underlines for the node
          // inline menu. It is not the shortcut target.
          {
            var div = document.createElement('div');
            column.appendChild(div);
            
            if ((undefined !== definition[i].key) && (undefined === id)) {
              var name = definition[i].name;
              var key = definition[i].key;
              if (key.length > 1) {
                key = key.charAt(0);
              }
              var index = name.indexOf(key);
              if (index < 0) {
                index = name.indexOf(key.toLowerCase());
              }
              
              if (index > 0) {
                var text = document.createTextNode(name.substring(0, index));
                div.appendChild(text);
              }
               
              if (index >= 0) { 
                var span = document.createElement('span');
                span.style.textDecoration = 'underline';
                
                var text = document.createTextNode(name.charAt(index));
                span.appendChild(text);
                
                div.appendChild(span);
              }
              
              if (index >= 0 && index < name.length - 1) {
                var text = document.createTextNode(name.substring(index+1));
                div.appendChild(text);
              }
              
              if (index < 0) {
                var text = document.createTextNode(name);
                div.appendChild(text);
              }
            
            } else {
              var text = document.createTextNode(definition[i].name);
              div.appendChild(text);
            }


            var help_string = null;
            if ((true === definition[i].active) && (undefined !== definition[i].help)) {
              help_string = definition[i].help;
            } else if ((true !== definition[i].active) && (undefined !== definition[i].help_inactive)) {
              help_string = definition[i].help_inactive;
            }

            if (null !== help_string) {
              row.setAttribute('title', help_string);
            }
          }
            
          if (true !== definition[i].active) {
            row.className = 'inactive';
          } else {
            row.className = 'active';
            GLI_EventListener.insert(row, 'click', GLI_Command.make_command_callback(definition[i], id));
          
            GLI_EventListener.insert(row, 'mouseover', set_background_color.bind(set_background_color, row, 'rgb(88%,90%,92%)'));
            GLI_EventListener.insert(row, 'mouseout', set_background_color.bind(set_background_color, row, '#fff'));

            n_active++;
          }


          if ((undefined !== id) && (true === definition[i].active)) {
            var div2 = document.createElement('div');
            column2.appendChild(div2);
            div2.className = 'key';
          
            var text2 = document.createTextNode(id);
            div2.appendChild(text2);
          } else if (false && (undefined !== definition[i].option) && (true === definition[i].active)) {
            var div2 = document.createElement('div');
            column2.appendChild(div2);
            div2.className = 'key';
            
            var text2 = document.createTextNode('[]');
            div2.appendChild(text2);
            
            var fn = function(url, event)
            {
              GLI_EventListener.stop(event);
              window.location.assign(url);
            }
            
            GLI_EventListener.insert(div2, 'click', fn.bind(fn, definition[i].option));

          } else if (false && (undefined !== definition[i].key) && (true === definition[i].active)) {
            var div2 = document.createElement('div');
            column2.appendChild(div2);
            div2.className = 'key';
          
            var text2 = document.createTextNode('(' + definition[i].key + ')');
            div2.appendChild(text2);
          }
        }

      }
    
      return table; 
    },
    make_link : function(definition)
    {
      var table = document.createElement('table');
    
      var body = document.createElement('tbody');
      table.appendChild(body);

      var n_active = 0;
      for (var i=0; i<definition.length; i++) {      
        var row = document.createElement('tr');
        body.appendChild(row);
       
        var column = document.createElement('td');
        row.appendChild(column);
        
        if (undefined !== definition[i].href) {
        
        var div = document.createElement('div');
        column.appendChild(div);

        div.setAttribute('style', 'padding: 4px 8px 4px 8px; font-size: 80%;');
        
        var anchor = document.createElement('a');
        div.appendChild(anchor);
        if (undefined !== definition[i].href) {
          anchor.setAttribute('href', definition[i].href);
        } else {
          anchor.setAttribute('style', 'text-decoration: underline; color: #676767;');
        }
        if (undefined !== definition[i].title) {
          anchor.setAttribute('title', definition[i].title);
        }

        var text = document.createTextNode(definition[i].name);
        anchor.appendChild(text);
        
        } else {
          column.className = 'separator';
        }
      }
      return table;
    },
    make_keyboard_shortcut : function(definition, id)
    {
      var key_to_command = [];
      var n_active = 0;
      
      var div = document.getElementById(_accesskey_id);
      if (div) {
        div.innerHTML = '';
      } 
      
      for (var i=0; i<definition.length; i++) {
          
        if ((undefined === definition[i]) || (undefined === definition[i].command) || (undefined === definition[i].key)) {
          // Ignore this one, no command to call.
        } else {

          if (true !== definition[i].active) {
            // Ignore this one, currently inactive command.
          } else {
            var fn = GLI_Command.make_command_callback(definition[i], definition[i].argument);
          
            var key_array = definition[i].key.toString().toLowerCase().split(',');
          
            for (var j=0; j<key_array.length; j++) {
              key_to_command[key_to_command.length] = {
                key: key_array[j],
                command: fn
              };
              n_active++;
            
              // Generate an anchor tag with an accesskey mapping.
              // Another way to access a short cut. Possibly remove this
              // in favor of simple keystroke system.
              if (div) {
                var anchor = document.createElement('a');
                anchor.setAttribute('href', '#');
                anchor.setAttribute('accesskey', definition[i].key);
              
                GLI_EventListener.insert(anchor, 'click', fn);
            
                var text = document.createTextNode(definition[i].name);
                anchor.appendChild(text);
            
                div.appendChild(anchor);
                div.appendChild(document.createElement('br'));
              }
            }
          }
        }
        
      }
      
      if (n_active > 0) {
      
        var handle_keyboard_shortcut = function(event)
        {
          var map = key_to_command;
        
          // Exclude invalid DOM elements and <input> fields.
          var element = null;
          if (event.target) {
            element = event.target;
          } else if (event.srcElement) {
            element = event.srcElement;
          }
          if (element && (3 == element.nodeType)) {
            element = element.parentNode;
          }
          
          if ((null == element) || ('input' == element.tagName.toLowerCase())) {
            return;
          }
          
          // Disallow key combinations. We do not want to intercept
		  // user interface key presses.
		  if (event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) {
		    return;
		  }
		  
		  // Grab the incoming key code. Convert to a character.
          var code = 0;
          if (undefined !== event.which) {
            code = event.which;
          } else if (undefined !== event.charCode) {
            code = event.charCode;
     	  } else if (undefined !== event.keyCode) {
     	    code = event.keyCode;
     	  }
     	    
     	  if (0 == code) {
     	    return;
     	  }
     	    
     	  var character = String.fromCharCode(code).toLowerCase();
     	  
          // Look up the incoming character in our map
          // of key => command entries. Execute the first
          // match and return.
          for (var i=0; i<map.length; i++) {
		    if ((character == map[i].key) && (undefined !== map[i].command)) {
		      map[i].command();
		      return true;
		    }
		  }
          
          return;
        }
        
        GLI_EventListener.insert(null, 'keypress', handle_keyboard_shortcut);
      }
    },
    close : function()
    {
      var menu = document.getElementById(_element_id);
      if (menu) {
        // <div id="menu"><table><tbody><tr>...</tr>
        var body = menu.firstChild.firstChild;
        if (body) {
          for (var i=0; i<body.childNodes.length; i++) {
            if ('active' === body.childNodes[i].className) {
              GLI_EventListener.erase_element(body.childNodes[i]);
            }
          }
        }
  
        menu.style.display = 'none';
        menu.innerHTML = '';

        GLI_EventListener.erase(null, 'click', GLI_Menu.close);
      }
    },
    keyboard_shortcut : function(definition)
    {
      var shortcut = document.getElementById('command_accesskey');
      if (definition && shortcut) {
        for (var i=0; i<definition.length; i++) {
          if ((true === definition[i].active) && (undefined !== definition[i].key)) {
            var anchor = document.createElement('a');
            
            var command_string = '';
            var argument_string = '';
            if (undefined === definition[i].prompt) {
              command_string = 'send_command';
            } else if (undefined === definition[i].value) {
              command_string = 'send_command_confirm';
              argument_string = ',\'' + definition[i].prompt + '\'';
            } else {
              command_string = 'send_command_prompt';
              argument_string = ',\'' + definition[i].prompt + '\',\'' + definition[i].value + '\'';
            }

            anchor.setAttribute('href', 'javascript:' + command_string + '(\'' + definition[i].command + '\'' + argument_string + ')');
            anchor.setAttribute('accesskey', definition[i].key);
            shortcut.appendChild(anchor);

            var text = document.createTextNode(definition[i].name);
            anchor.appendChild(text); 
          }
        }
      }
    }
  }
}();
// END module GLI_Menu
