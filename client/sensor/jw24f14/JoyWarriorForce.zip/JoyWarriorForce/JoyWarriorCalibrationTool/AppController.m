#import "AppController.h"
#import "AppController+Devices.h"
#import "AppController+JWConfig.h"
#import "DiscoverHIDInterface.h"
#import <IOKit/hid/IOHIDLib.h>

@implementation AppController

void JoyWarriorAddedOrRemoved(void *refCon, io_iterator_t iterator)
{
    io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
    }
	[[NSApp delegate] updateDeviceState];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

- (void) dealloc
{
    [self setXAxis: nil];
    [self setYAxis: nil];
    [self setZAxis: nil];
	
	[self setXOffset: nil];
    [self setYOffset: nil];
    [self setZOffset: nil];
	
	[self setXOffsetHex: nil];
    [self setYOffsetHex: nil];
    [self setZOffsetHex: nil];
	
    [super dealloc];
}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{	
	AddUSBDeviceAddedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	
	[self updateDeviceState];
	
}

- (void) updateDeviceState
{
	NSArray *interfaces;
	ProductID = 0;
	
	interfaces = [self discoverInterfaces];
	if ((nil != interfaces) && ( [interfaces count] >= 2))
	{
		NSArray             *deviceProperties;
		CFNumberRef			interfaceRef;
		
		interfaceRef =	(CFNumberRef)[interfaces objectAtIndex:1];
		CFNumberGetValue(interfaceRef,kCFNumberLongType,&interface);
		
		deviceProperties = [self discoverDeviceProperties];
		
		if ( [deviceProperties count] )
		{
			NSDictionary	  *properties = [deviceProperties objectAtIndex: 0];
			[deviceTypeField setStringValue:[properties valueForKey:@"Product"]]; 
			[deviceSerialField setStringValue:[properties valueForKey:@"SerialNumber"]];
			ProductID = [[properties valueForKey:@"ProductID"] intValue];
		}
		
		
        // F8
        //      Range:  2 (-> 0)
        //   Bandwith: 25 (-> 0)
        // F14
        //      Range:  1 (-> 0)
        //   Bandwith: 10 (-> 0)
        [self switchJoyWarriorAtInterface:interface withProductID:ProductID toRange:0 andBandwidth:0];
		// Is this a JW24F14?
		if (ProductID == 0x1116)
		{
            [zeroButton setTitle:@"Zero X/Y"];
            [zeroZButton setHidden:false];
			[self readOffsetValuesF14];
		}
		else
        {
            [zeroButton setTitle:@"Zero"];
            [zeroZButton setHidden:true];
			[self readOffsetValues];
		}
            
		readTimer = [NSTimer scheduledTimerWithTimeInterval:0.1
													 target:self
												   selector:@selector (readAxisValuesTimed:)
												   userInfo:nil
													repeats:YES];
	}
	else
	{
		interface = 0;
		
		[readTimer invalidate];
		readTimer = nil;
		
		[deviceSerialField setStringValue:@""];
		[deviceTypeField setStringValue:@""];
		
	}
}

- (void) readOffsetValuesF14
{
	UInt8						lsb, msb, temp;
	SInt16						x, y, z;
	
    JWEnableCommandMode24F14(interface);
    
	// Read Bandwidth 
	JWReadByteFromAddress24F14 (interface, 0x20, &temp);
	usleep(50000);
	[self logMessage:[NSString stringWithFormat:@"Bandwidth: %d", (temp>>4)]];
	
	// Read Range
	JWReadByteFromAddress24F14 (interface, 0x35, &temp);
	usleep(50000);
	[self logMessage:[NSString stringWithFormat:@"Range: %d", (temp>>1) & 7]];
	
	/*
	// Soft-reset (save EEPROM-state)
	JWWriteByteToAddress24F14 (interface, 0x10, 0xB6);
	usleep(50000);
	*/
	
	// Read offset X
	JWReadByteFromAddress24F14 (interface, 0x35, &lsb);
	usleep(50000);
	x = lsb & 0xF0;
	JWReadByteFromAddress24F14 (interface, 0x38, &msb);
	usleep(50000);
	x |= (msb<<8);
	x >>= 4;
	
	// Read offset Y
	JWReadByteFromAddress24F14 (interface, 0x36, &lsb);
	usleep(50000);
	y = lsb & 0x0F;
	JWReadByteFromAddress24F14 (interface, 0x39, &msb);
	usleep(50000);
	y |= (msb<<8);
	y >>= 4;
	
	// Read offset Z
	JWReadByteFromAddress24F14 (interface, 0x36, &lsb);
	usleep(50000);
	z = lsb & 0xF0;
	JWReadByteFromAddress24F14 (interface, 0x3A, &msb);
	usleep(50000);
	z |= (msb<<8);
	z >>= 4;
	
    JWDisableCommandMode24F14(interface);
    
	[self setXOffset:[NSString stringWithFormat:@"%d", x]];
	[self setYOffset:[NSString stringWithFormat:@"%d", y]];
	[self setZOffset:[NSString stringWithFormat:@"%d", z]];
	
	[self setXOffsetHex:[NSString stringWithFormat:@"0x%03X", x]];
	[self setYOffsetHex:[NSString stringWithFormat:@"0x%03X", y]];
	[self setZOffsetHex:[NSString stringWithFormat:@"0x%03X", z]];
}

- (void) readOffsetValues
{
	UInt8						rawData[7];
	UInt8						temp;
	int							i;
	SInt16						x, y, z;
        
	// open eprom 
	JWReadByteFromAddress (interface, 0xA, &temp);
	temp = temp | 0x10;
	JWWriteByteToAddress (interface, 0xA, temp);

	for (i = 0; i < 7; i++)
	{
		JWReadByteFromAddress (interface, 0x16 + i, &rawData[i]);
	}
    
	x = JWMergeOffsetBytes(rawData[0], rawData[4]);
	y = JWMergeOffsetBytes(rawData[1], rawData[5]);
	z = JWMergeOffsetBytes(rawData[2], rawData[6]);
	
	[self setXOffset:[NSString stringWithFormat:@"%d", x]];
	[self setYOffset:[NSString stringWithFormat:@"%d", y]];
	[self setZOffset:[NSString stringWithFormat:@"%d", z]];
	
	[self setXOffsetHex:[NSString stringWithFormat:@"0x%03X", x]];
	[self setYOffsetHex:[NSString stringWithFormat:@"0x%03X", y]];
	[self setZOffsetHex:[NSString stringWithFormat:@"0x%03X", z]];
}

- (void) readAxisValuesTimed:(NSTimer*) inTimer
{
	if (interface)
	{
		UInt8						rawData[6];
		int							i;
		SInt16						x = 0, y = 0, z = 0;
        
        if ( ProductID == 0x1116 )
        {
            JWEnableCommandMode24F14(interface);
            
            for (i = 0; i < 6; i++)
            {
                JWReadByteFromAddress24F14(interface, 0x02 + i, &rawData[i]);
            }
            
            JWDisableCommandMode24F14(interface);
            
            x = ((rawData[1] << 8) | (rawData[0] ));
            x >>= 2;        
            y = ((rawData[3] << 8) | (rawData[2] ));
            y >>= 2;
            z = ((rawData[5] << 8) | (rawData[4] ));
            z >>= 2;
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                JWReadByteFromAddress (interface, 0x02 + i, &rawData[i]);
            }
            
            x = JWMergeAxisBytes24F14(rawData[0], rawData[1]);
            y = JWMergeAxisBytes24F14(rawData[2], rawData[3]);
            z = JWMergeAxisBytes24F14(rawData[4], rawData[5]);
        }
        
		[self setXAxis:[NSString stringWithFormat:@"%d", x]];
		[self setYAxis:[NSString stringWithFormat:@"%d", y]];
		[self setZAxis:[NSString stringWithFormat:@"%d", z]];
	}
}


- (NSString *) xAxis
{
    return xAxis; 
}

- (void) setXAxis: (NSString *) inXAxis
{
    if (xAxis != inXAxis) {
        [xAxis autorelease];
        xAxis = [inXAxis retain];
    }
}


- (NSString *) yAxis
{
    return yAxis; 
}

- (void) setYAxis: (NSString *) inYAxis
{
    if (yAxis != inYAxis) {
        [yAxis autorelease];
        yAxis = [inYAxis retain];
    }
}


- (NSString *) zAxis
{
    return zAxis; 
}

- (void) setZAxis: (NSString *) inZAxis
{
    if (zAxis != inZAxis) {
        [zAxis autorelease];
        zAxis = [inZAxis retain];
    }
}

- (NSString *) xOffset
{
    return xOffset; 
}

- (void) setXOffset: (NSString *) inXOffset
{
    if (xOffset != inXOffset) {
        [xOffset autorelease];
        xOffset = [inXOffset retain];
    }
}


- (NSString *) yOffset
{
    return yOffset; 
}

- (void) setYOffset: (NSString *) inYOffset
{
    if (yOffset != inYOffset) {
        [yOffset autorelease];
        yOffset = [inYOffset retain];
    }
}


- (NSString *) zOffset
{
    return zOffset; 
}

- (void) setZOffset: (NSString *) inZOffset
{
    if (zOffset != inZOffset) {
        [zOffset autorelease];
        zOffset = [inZOffset retain];
    }
}

- (NSString *) xOffsetHex
{
    return xOffsetHex; 
}

- (void) setXOffsetHex: (NSString *) inXOffsetHex
{
    if (xOffsetHex != inXOffsetHex) {
        [xOffsetHex autorelease];
        xOffsetHex = [inXOffsetHex retain];
    }
}


- (NSString *) yOffsetHex
{
    return yOffsetHex; 
}

- (void) setYOffsetHex: (NSString *) inYOffsetHex
{
    if (yOffsetHex != inYOffsetHex) {
        [yOffsetHex autorelease];
        yOffsetHex = [inYOffsetHex retain];
    }
}


- (NSString *) zOffsetHex
{
    return zOffsetHex; 
}

- (void) setZOffsetHex: (NSString *) inZOffsetHex
{
    if (zOffsetHex != inZOffsetHex) {
        [zOffsetHex autorelease];
        zOffsetHex = [inZOffsetHex retain];
    }
}


- (IBAction) calibrateButtonClicked:(id) sender
{
	int			response;
	UInt8		temp;

	response = NSRunAlertPanel (@"Calibration Warning",
					 @"Are you sure you want to calibrate the connected device",
					 @"OK",
					 @"Cancel",
					 nil);
	
	if (response != NSAlertDefaultReturn)
		return;
	
	[readTimer invalidate];
    readTimer = nil;
	
	// If we have a JW24F14, calibrate X and Y axes
	if (ProductID == 0x1116)
	{
        JWEnableCommandMode24F14(interface);
        
		[self writeOffsetF14];
				
		// Set image non-writeable
		JWReadByteFromAddress24F14(interface, 0x0D, &temp);
		temp &= 0xEF;
		usleep(10000);
		JWWriteByteToAddress24F14(interface, 0x0D, temp);
        
        JWDisableCommandMode24F14(interface);
        
		[self readOffsetValuesF14];
	}
	// Else it's the old F8
	else
	{
		// open eprom 
		JWReadByteFromAddress (interface, 0xA, &temp);
		temp = temp | 0x10;
		JWWriteByteToAddress (interface, 0xA, temp);
		
		
		[self writeOffset:@"X"];
		[self writeOffset:@"Y"];
		[self writeOffset:@"Z"];

		// open eprom 
		JWReadByteFromAddress (interface, 0xA, &temp);
		temp = temp & 0xEF; 
		JWWriteByteToAddress (interface, 0xA, temp);
	}
	
	readTimer = [NSTimer scheduledTimerWithTimeInterval:0.1
												 target:self
											   selector:@selector (readAxisValuesTimed:)
											   userInfo:nil
												repeats:YES];
	
}

// Calibrate only the Z-Axis
- (IBAction) calibrateZButtonClicked:(id) sender
{
	int			response;
	int         temp;
    
    // If we have a JW24F14
	if (ProductID == 0x1116)
	{
    
        response = NSRunAlertPanel (@"Calibration Warning",
                                    @"In order to calibrate the Z-Axis, you will need to flip the sensor sideways.",
                                    @"OK",
                                    @"Cancel",
                                    nil);
        
        if (response != NSAlertDefaultReturn)
            return;
        
        [readTimer invalidate];
        readTimer = nil;
	
        JWEnableCommandMode24F14(interface);
        
        // open eprom 
        JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
        usleep(50000);
        temp &= 0xEF;
        temp |= 0x10;
        JWWriteByteToAddress24F14 (interface, 0x0D, temp);
        usleep(50000);
        
        // Bandwidth 150Hz 
        JWReadByteFromAddress24F14 (interface, 0x20, &temp);
        usleep(50000);
        [self logMessage:[NSString stringWithFormat:@"Old bandwidth: %d", (temp>>4)]];
        temp &= 0x0F;
        JWWriteByteToAddress24F14 (interface, 0x20, temp | 0x40);
        usleep(50000);
        
        // Range 1G
        JWReadByteFromAddress24F14 (interface, 0x35, &temp);
        usleep(50000);
        [self logMessage:[NSString stringWithFormat:@"Old range: %d", (temp>>1) & 7]];
        temp &= 0xF1;
        JWWriteByteToAddress24F14 (interface, 0x35, temp);
        usleep(50000);
        
		// Calibration Z
        JWWriteByteToAddress24F14 (interface, 0x22, 0x03);
        usleep(50000);
        JWWriteByteToAddress24F14 (interface, 0x0E, 0x20);
        usleep(1000000);
        
        JWWriteByteToAddress24F14 (interface, 0x56 & 0xFE, 0);
        usleep(50000);
        JWWriteByteToAddress24F14 (interface, 0x5A & 0xFE, 0);
        usleep(50000);
        
        // Soft-reset (save EEPROM-state)
        JWWriteByteToAddress24F14 (interface, 0x10, 0xB6);
        usleep(50000);
        
        JWDisableCommandMode24F14(interface);
        
		[self readOffsetValuesF14];
        
        readTimer = [NSTimer scheduledTimerWithTimeInterval:0.1
                                                     target:self
                                                   selector:@selector (readAxisValuesTimed:)
                                                   userInfo:nil
                                                    repeats:YES];
	}
}

- (void) writeOffsetF14
{
	int temp;
	    
	// open eprom 
	JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
	usleep(50000);
	temp &= 0xEF;
	temp |= 0x10;
	JWWriteByteToAddress24F14 (interface, 0x0D, temp);
	usleep(50000);
	
	// Bandwidth 150Hz 
	JWReadByteFromAddress24F14 (interface, 0x20, &temp);
	usleep(50000);
	[self logMessage:[NSString stringWithFormat:@"Old bandwidth: %d", (temp>>4)]];
	temp &= 0x0F;
	JWWriteByteToAddress24F14 (interface, 0x20, temp | 0x40);
	usleep(50000);
	
	// Range 1G
	JWReadByteFromAddress24F14 (interface, 0x35, &temp);
	usleep(50000);
	[self logMessage:[NSString stringWithFormat:@"Old range: %d", (temp>>1) & 7]];
	temp &= 0xF1;
	JWWriteByteToAddress24F14 (interface, 0x35, temp);
	usleep(50000);
	
	// Calibration X
	JWWriteByteToAddress24F14 (interface, 0x22, 0x03);
	usleep(50000);
	JWWriteByteToAddress24F14 (interface, 0x0E, 0x80);
	usleep(1000000);
	
	// Calibration Y
	JWWriteByteToAddress24F14 (interface, 0x22, 0x03);
	usleep(50000);
	JWWriteByteToAddress24F14 (interface, 0x0E, 0x40);
	usleep(1000000);
	
	// Save changes to EEPROM by touching the registers
	JWWriteByteToAddress24F14 (interface, 0x40 & 0xFE, 0);
	usleep(50000);
	JWWriteByteToAddress24F14 (interface, 0x55 & 0xFE, 0);
	usleep(50000);
	JWWriteByteToAddress24F14 (interface, 0x56 & 0xFE, 0);
	usleep(50000);
	JWWriteByteToAddress24F14 (interface, 0x58 & 0xFE, 0);
	usleep(50000);
	
	// Soft-reset (save EEPROM-state)
	JWWriteByteToAddress24F14 (interface, 0x10, 0xB6);
	usleep(50000);
    
    
}
- (void) writeOffset:(NSString*) inAxis
{
	UInt8 offset_lsb;
	UInt8 offset_msb;
	UInt8 set_offset;
	UInt8 acc_value_lsb;
	UInt8 acc_value_msb;
	
	UInt8 OFF_MSB, OFF_LSB, OFF_GAIN;
	
	UInt8 ACC_MSB, ACC_LSB;

	
	/*
	 For more detail of reference take  look into the datasheet (page 9)
	 Default for 2g is (0;0;256)	
	 */
	SInt16 reference_x[6] = {0,0,0,0,256,-256};
	SInt16 reference_y[6] = {0,0,256,-256,0,0};
	SInt16 reference_z[6] = {256,-256,0,0,0,0};
	
	SInt16 reference;
	SInt16 ref = 0;

	
	if ([inAxis isEqualToString:@"X"])
	{
		offset_lsb = 0x16;
		offset_msb = 0x1A;
		acc_value_lsb = 0x02;
		acc_value_msb = 0x03;
		reference = reference_x[0];
	}
	else if ([inAxis isEqualToString:@"Y"])
	{
		offset_lsb = 0x17;
		offset_msb = 0x1B;
		acc_value_lsb = 0x04;
		acc_value_msb = 0x05;
		reference = reference_y[0];
	}
	else if ([inAxis isEqualToString:@"Z"])
	{
		offset_lsb = 0x18;
		offset_msb = 0x1C;
		acc_value_lsb = 0x06;
		acc_value_msb = 0x07;
		reference = reference_z[0];
	}
	
	/*save GAIN*/

	JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
	OFF_GAIN = OFF_LSB & 0x3F;
	

	do
	{
		SInt16 dif = 0;
		SInt16 off = 0;
		
		JWReadByteFromAddress(interface, acc_value_lsb, &ACC_LSB);
		JWReadByteFromAddress(interface, acc_value_msb, &ACC_MSB);

		dif = JWMergeAxisBytes(ACC_LSB, ACC_MSB); //get Acc -> double-wert
		
		JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
		JWReadByteFromAddress(interface, offset_msb, &OFF_MSB);

		off = JWMergeAxisBytes(OFF_LSB, OFF_MSB); //get Offset -> double-wert
		
		/*division with 8 (for 2G & >25Hz*/
		ref = floor((dif - reference)/8.00);
		
		if ((dif > (reference + 4)) || (dif < (reference - 4)))  // is calibration needed?
		{
			UInt8 tempLSB, tempMSB;
			
			if((dif < 8) && (dif > 0)) //acc > +0 and < +8
				JWDiffMsbLsb (off -1, &tempLSB, &tempMSB);
			else if((dif > -8) && (dif < 0)) //acc < -0 and > -8
				JWDiffMsbLsb (off +1, &tempLSB, &tempMSB);
			else
				JWDiffMsbLsb (off - (short)ref, &tempLSB, &tempMSB);
			
			JWWriteByteToAddress(interface, offset_lsb | 0x00, tempLSB);
			JWWriteByteToAddress(interface, offset_msb | 0x00, tempMSB);
			
			usleep(50);
			
			/*write GAIN into LSB to restore old GAIN-Value*/
			JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
			set_offset = OFF_LSB | OFF_GAIN;
			JWWriteByteToAddress(interface, offset_lsb | 0x00, set_offset);
			
			usleep(50); //Sleep because set register need short time to set
		}
		else
			break;
	}while(ref < 1);
	
	
	/*write offset from image -> eeprom*/
	
	OFF_LSB = 0;
	OFF_MSB = 0;
	
	JWReadByteFromAddress(interface, offset_lsb, &OFF_LSB);
	JWReadByteFromAddress(interface, offset_msb, &OFF_MSB);
	
	usleep(50);
	
	JWWriteByteToAddress(interface, offset_lsb | 0x20, OFF_LSB);

	usleep(50);
	
	JWWriteByteToAddress(interface, offset_msb | 0x20, OFF_MSB);

	usleep(200);
	
}

- (void) logMessage: (NSString *) msg
{
	NSString * inString = msg;
	inString = [inString stringByAppendingString:@"\n"];
	
	NSMutableAttributedString	*attributedString = [[[NSMutableAttributedString alloc] initWithString:inString] autorelease];
	[attributedString addAttributes:[NSDictionary dictionaryWithObject:[NSFont systemFontOfSize:12.0] forKey:NSFontAttributeName]
							  range:NSMakeRange (0, [attributedString length])];
	
	[[logTextView textStorage] appendAttributedString:attributedString];
	
	
	[logTextView scrollRangeToVisible:NSMakeRange ([[logTextView textStorage] length] -1, 0)];
}

@end
