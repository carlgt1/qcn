//
//  AxisButtonView.m
//  JoyWarriorTest
//
//  Created by Guido K�rber on 17.09.04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import "AxisButtonView.h"


@implementation AxisButtonView

- (void) resetState
{
	[super resetState];
	
	[self setMinValue: 1000];
	[self setMaxValue:0];
}

- (void) drawRect:(NSRect) inRect
{
	[super drawRect:inRect];
	
	inRect = NSInsetRect (inRect, 2,2);
	
	NSBezierPath *path = [NSBezierPath bezierPath];
	
	[path moveToPoint:NSMakePoint (NSMidX(inRect), NSMidY(inRect))];
	[path lineToPoint:NSMakePoint (NSMidX(inRect), NSMinY(inRect))];
	
	[[NSColor whiteColor] set];
	[path setLineWidth:3];
	[path stroke];
}

- (void) setLastValue:(int) inValue
{	
	if (inValue < minValue)
		[self setMinValue:inValue];
	
	if (inValue > maxValue)
		[self setMaxValue:inValue];
	
	[super setLastValue:inValue];
}

- (int) maxValue { return maxValue; }
- (void) setMaxValue: (int) inMaxValue
{
	maxValue = inMaxValue;
}


- (int) minValue { return minValue; }
- (void) setMinValue: (int) inMinValue
{
	minValue = inMinValue;
}


@end
