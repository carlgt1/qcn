/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// TIMER1
//-----------------------------------------------------------------------------
#ifndef TIMER1_H
#define TIMER1_H

#include "upsd34xx.h"

//-----------------------------------------------------------------------------
void TIMER1_Init_Mode2 (u8 auto_reload_value);

//-----------------------------------------------------------------------------
#endif
