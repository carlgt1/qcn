/**
  @file    tools/sdk/cs/Test.cs
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.0

  (C) Copyright GLI Interactive LLC 2008. All rights reserved.

  The coded instructions, statements, computer programs, and/or related
  material (collectively the "Data") in these files contain unpublished
  information proprietary to GLI Interactive LLC, which is protected by
  US federal copyright law and by international treaties.

  The Data may not be disclosed or distributed to third parties, in whole
  or in part, without the prior written consent of GLI Interactive LLC.

  The Data is provided "as is" without express or implied warranty, and
  with no claim as to its suitability for any purpose.
*/
using System;
using System.Collections.Generic;
using System.Text;

using MotionNode.SDK;

namespace Test
{
  /**
   Test functions for the MotionNode SDK.
   */
  class Test
  {
    static void test_Console()
    {
      try
      {
        String chunk =
          // Close all connections.
          // Set the G range for all configured devices
          // Start reading
          "node.close() node.set_gselect(6) node.start()" +
          // Print the result of node.is_reading()
          " print('node.is_reading() == ', node.is_reading())"
        ;
        Console.WriteLine("test_Console, sending chunk: \"" + chunk + "\"");

        Client client = new Client("", 32075);

        LuaConsole.ResultType result =
          LuaConsole.SendChunk(client, chunk);

        if (LuaConsole.ResultCode.Success == result.first)
        {
          // Should be:
          // "node.is_reading() == true\n"
          Console.WriteLine(result.second);
        }
        else if (LuaConsole.ResultCode.Continue == result.first)
        {
          Console.WriteLine("incomplete Lua chunk: " + result.second);
        }
        else
        {
          Console.WriteLine("command failed: " + result.second);
        }

        client.close();
      }
      catch (Exception e)
      {
        Console.WriteLine(e.ToString());
      }
    }
    
    static void test_Client()
    {
      try
      {
        Console.WriteLine("test_Client, connecting to Preview service");

        Client client = new Client("", 32079);

        if (client.waitForData())
        {
          int i = 0;
          while (i++ < 10)
          {
            byte[] data = client.readData();
            if (null != data)
            {
              IDictionary<int, Format.PreviewElement> preview = Format.Preview(data);
              Console.WriteLine(preview.Count.ToString() + " active node(s)");
              foreach (KeyValuePair<int, Format.PreviewElement> itr in preview)
              {
                Console.WriteLine("[" + itr.Key + "] => <rx: " + itr.Value.getEuler()[0] + ">");
              }
            }
            else
            {
              break;
            }
          }
        }

        client.close();
      }
      catch (Exception e)
      {
        Console.WriteLine(e.ToString());
      }
    }

    static void test_File()
    {
      try
      {
        String filename = "../../../../test_data/output.bin";
        Console.WriteLine("test_File, reading data file: \"" + filename + "\"");
        
        File file = new File(filename);
        int i = 0;
        while (i++ < 10)
        {
          float[] x = file.readOutputData();
          if (null == x)
          {
            break;
          }
          else
          {
            Console.WriteLine("q(" + i + ") = <" + x[0] + ", " + x[1] + "i, " + x[2] + "j, " + x[3] + "k>");
          }
        }

        file.close();
      }
      catch (Exception e)
      {
        Console.WriteLine(e.ToString());
      }
    }

    static void Main(string[] args)
    {
      test_Console();
      test_Client();
      test_File();
    }
  }
}
