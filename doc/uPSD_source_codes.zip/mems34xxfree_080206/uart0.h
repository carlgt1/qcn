/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// UART0
//-----------------------------------------------------------------------------
#ifndef UART0_H
#define UART0_H

#include "upsd34xx.h"
#include "lis.h"

//-----------------------------------------------------------------------------
//choose uart_mode
#define UART0_ACTIVE_WAIT_MODE 0x01
#define UART0_CONTINUOUS_MODE  0x02
#define UART0_OPERATION_MODE   UART0_CONTINUOUS_MODE

//-----------------------------------------------------------------------------
//chose uart baud rate

//-------------------------------------------------
//| fosc [MHz] | Baud Rate | SMOD bit | TH1 value |
//-------------------------------------------------
//|    40.0    |   19200   |    1     |     F5    |
//|    40.0    |    9600   |    1     |     EA    |
//|    36.0    |   19200   |    1     |     F6    |
//|    36.0    |    9600   |    1     |     EC    |
//|    36.0    |    4800   |    1     |     D9    | 
//|    33.3    |   57600   |    1     |     FD    |
//|    33.3    |   28800   |    1     |     FA    |
//|    33.3    |   19200   |    1     |     F7    |
//|    33.3    |    9600   |    1     |     EE    |
//|    24.0    |    9600   |    1     |     F3    |
//|    24.0    |    4800   |    1     |     E6    |
//|    12.0    |    4800   |    1     |     F3    |
//-------------------------------------------------

#define SMOD0_value 1

//let's calculate it
#define uart_baudrate 19200
#define TIMER_RATIO (u8)(FREQ_TIMERS/(2L-SMOD0_value)/16L/uart_baudrate)
//#define TH1_VALUE (u8)(256-TIMER_RATIO)

//or assign it manualy
#define TH1_VALUE (u8)(0xF3)

//-----------------------------------------------------------------------------
void UART0_Init            (void);
void UART0_Send            (u8 value);
void UART0_Send_Buffer     (void);
u8   UART0_Receive         (void);

//-----------------------------------------------------------------------------
void UART0_Print_u8        (u8 dato);
void UART0_Print_Out16     (t_out16 *out);
void UART0_Print_ConstText (const u8 *config_str, const u8 *text_buffer);

//-----------------------------------------------------------------------------
#endif
