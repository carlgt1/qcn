/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Petr Pfeifer & Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// UPSD34XX_USB
//-----------------------------------------------------------------------------
#include "usb.h"

//-----------------------------------------------------------------------------
const t_device_descriptor code deviceDesc =
{
  sizeof(t_device_descriptor),               // Size of this Descriptor in Bytes
  DT_DEVICE,                                 // Descriptor Type (=1)
  {0x00, 0x02},                              // USB Spec Release Number in BCD = 2.00 = 0x00,0x02     
  0,                                         // Device Class Code (none)
  0,                                         // Device Subclass Code (none)
  0,                                         // Device Protocol Code (none)
  EP0_PKT_SIZE,                              // Maximum Packet Size for EP0
  {0x83, 0x04},                              // Vendor ID
  {0x20, 0x34},                              // Product ID
  {0x00, 0x01},                              // Device Release Number in BCD
  1,                                         // Index of String Desc for Manufacturer
  2,                                         // Index of String Desc for Product
  3,                                         // Index of String Desc for SerNo
  1                                          // Number of possible Configurations
};

const unsigned char code deviceDescSize = sizeof(t_device_descriptor);

//-----------------------------------------------------------------------------
const unsigned char code reportDesc[] =
{
  0x06, 0xA0, 0xFF,                          // Usage page (vendor defined)
  0x09, 0xA5,                                // Usage (vendor defined)

  0xA1, 0x01,                                // Collection (application)
  0x09, 0xA6,                                // Usage (vendor defined)

                                             // Input report
  0x09, 0xA7,                                // Usage (vendor defined)
  0x15, 0x80,                                // Logical min (-127)
  0x25, 0x7F,                                // Logical max (128)
  0x75, 0x08,                                // Report size (8 bits)
  0x95, 0x0A,                                // Report count (bytes), your size of protocol, (7 for t_out)
  0x81, 0x02,                                // Input (data, variable, absolute)

                                             // Output report
  0x09, 0xA9,                                // Usage (vendor defined)
  0x15, 0x80,                                // Logical min (-127)
  0x25, 0x7F,                                // Logical max (128)
  0x75, 0x08,                                // Report size (8 bits)
  0x95, 0x0A,                                // Report count (bytes), your size of protocol, (7 for t_out)
  0x91, 0x02,                                // Output (data, variable, absolute)

  0xC0                                       // End Collection (Application)
};

const unsigned char code reportDescSize = sizeof(reportDesc);
#define REPORT_DESC_LEN sizeof(reportDesc)

//-----------------------------------------------------------------------------
const unsigned char code PhysicalReportDesc[] =
{
  0,0,0                                      // no physical descriptor defined now
};

const unsigned char code PhysicalReportDescSize = sizeof(PhysicalReportDesc);

//-----------------------------------------------------------------------------
// Copy of HID class descriptor embedded in configDesc below

const unsigned char code hidClassDesc[] =
{
  9,                                         // Descriptor length
  0x21,                                      // Descriptor type (HID)
  0x00,0x02,                                 // HID release (2.0)
  0,                                         // Country code (none)
  1,                                         // Number of HID class descriptors to follow
  0x22,                                      // Report descriptor type (HID)
  REPORT_DESC_LEN, 0                         // Byte length of report descriptor
};

const unsigned char code hidClassDescSize = sizeof(hidClassDesc);

//-----------------------------------------------------------------------------
const unsigned char code configDesc[] =
{
  9,                                         // Configuration descriptor length
  2,                                         // Descriptor type (configuration)
  34, 0,                                     // Total length of this descriptor
  1,                                         // Number of interfaces
  1,                                         // Configuration value (OnSetConfiguration)
  0,                                         // Index of string descriptor (none)
  0x80,                                      // No remote wakeup  
  75,                                        // 150 mA max power consumption including user application (50mA max for uPSD), 2mA steps

                                             // --- Interface ---
  9,                                         // Descriptor length
  DT_INTERFACE,                              // Descriptor type
  1,                                         // Number of interface
  0,                                         // Alternate setting
  1,                                         // Number of endpoints (except EP0)
  3,                                         // HID
  0,                                         // Subclass - SCSI Type
  0,                                         // Protocol (2=mouse, 0=general, 0x50=Bulk Only)
  0,                                         // Index of string descriptor (none)

  9,                                         // Descriptor length
  DT_HID_CLASS,                              // Descriptor type
  0x00,0x02,                                 // HID release (0.0)
  0,                                         // Country code (none)
  1,                                         // Number of HID class descriptors to follow
  0x22,                                      // Report descriptor type (HID)
  REPORT_DESC_LEN, 0,                        // Byte length of report descriptor   

                                             // --- Endpoint descriptor (EP1) ---
  7,                                         // Descriptor length (7 bytes)
  DT_ENDPOINT,                               // Descriptor type
  0x81,                                      // Address (IN1)
  EP_ATTR_INTERRUPT,                         // Attributes
//EP_ATTR_ISOCHRONOUS,                       // Attributes
  EP1_PKT_SIZE, 0,                           // Maximum packet size
  1,                                         // Polling interval
};

const unsigned char code configDescSize = sizeof(configDesc);

//-----------------------------------------------------------------------------
const unsigned char code string0Desc[] =
{
  0x04, DT_STRING,                           // Size, Type
  0x09, 0x04                                 // LangID Codes
};

//-----------------------------------------------------------------------------
// Manufacturer String
//-----------------------------------------------------------------------------
#define SD1LEN sizeof("ST Microelectronics")*2
const unsigned char code string1Desc[] =
{
  SD1LEN, DT_STRING ,                        // Size, Type
  'S', 0,                                    // Unicode String
  'T', 0,
  ' ', 0,
  'M', 0,
  'i', 0,
  'c', 0,
  'r', 0,
  'o', 0,
  'e', 0,
  'l', 0,
  'e', 0,
  'c', 0,
  't', 0,
  'r', 0,
  'o', 0,
  'n', 0,
  'i', 0,
  'c', 0,
  's', 0
};

//-----------------------------------------------------------------------------
// Product String
//-----------------------------------------------------------------------------
#define SD2LEN sizeof("DK34xx & MEMS")*2
const unsigned char code string2Desc[] =
 {
  SD2LEN, DT_STRING,                         
  'D', 0,
  'K', 0,
  '3', 0,
  '4', 0,
  'x', 0,
  'x', 0,
  ' ', 0,
  '&', 0,
  ' ', 0,
  'M', 0,
  'E', 0,
  'M', 0,
  'S', 0
};

//-----------------------------------------------------------------------------
// Serial Number String
//-----------------------------------------------------------------------------
#define SD3LEN sizeof("S/N:001/2004")*2
const uchar code string3Desc[] =
{
  SD3LEN, DT_STRING,                         // Size, Type
  'S', 0,                                    // Unicode String
  '/', 0,
  'N', 0,
  ':', 0,
  '0', 0,
  '0', 0,
  '1', 0,
  '/', 0,
  '2', 0,
  '0', 0,
  '0', 0,
  '4', 0,
};

//-----------------------------------------------------------------------------
const unsigned char code stringXDesc[2] =
{
  0, 0,                                      
};

// Table of String Descriptors
const unsigned char * const code stringDescTable[] =
{
  string0Desc,
  string1Desc,
  string2Desc,
  string3Desc,
  stringXDesc
};

//-----------------------------------------------------------------------------
