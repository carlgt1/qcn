/**
  @file    javascript/Position.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/

/**
  Find the bounding box of a single DOM element.
*/
var GLI_Position = function() {
  return {
    compute : function(element)
    {
      var result = {left: 0, right: 0, top: 0, bottom: 0};
      
      result.right = element.offsetWidth;
      result.bottom = element.offsetHeight;

      // Take a walk up the tree.
      while (element) {
        result.left += element.offsetLeft;
        result.top += element.offsetTop;
        element = element.offsetParent;
      }

      result.right += result.left;
      result.bottom += result.top;
      
      return result;
    }
  }
}();
// END module GLI_Position
