#!/bin/sh
#
# Launch script for the MotionNode system. Start the daemon if
# necessary and then start a web browser session with the
# default service address.
#
# @file    Launch.sh
# @author  Luke Tokheim, luke@motionnode.com
# @version 1.2
#

if [ "$MOTIONNODE_HOME" != "" ]; then
  TARGET=$MOTIONNODE_HOME
else
  TARGET=$HOME
fi

#
# Verify that the MotionNode data folder exists. If not, use the
# InitializeHome.sh script to create it for us.
#
if [ ! -d $TARGET ] || [ ! -d $TARGET/MotionNode ] || [ ! -d $TARGET/MotionNode/default ]; then
  if [ -x ./InitializeHome.sh ]; then
    ./InitializeHome.sh $TARGET
  else
    echo Failed to find \"InitializeHome.sh\" script in working directory
  fi
fi

#
# Check for a running instance of the MotionNodeDaemon. Create
# a new one if none are running.
#
RUNNING=`ps -ef | grep -v grep | grep MotionNodeDaemon | wc -l`;
if [ 0 = $RUNNING ]; then
  if [ -x ./MotionNodeDaemon ]; then
    echo Starting daemon with MotionNode data folder \"$TARGET\", using daemon log
    ./MotionNodeDaemon
  else
    echo Failed to find \"MotionNodeDaemon\" application in working directory
  fi
fi

#
# Launch the User Interface web address.
#
URL=http://127.0.0.1:32080/

if [ "$DISPLAY" != "" ]; then
  if [ -x `which gnome-open` ]; then
    `which gnome-open` $URL
  elif [ -x `which kfmclient` ]; then
    `which kfmclient` $URL
  elif [ -x `which firefox` ]; then
    `which firefox` $URL
  else
    echo Failed to find web browser. Can not launch user interface at \"$URL\".
  fi
else
  echo No active display. Can not launch user interface at \"$URL\".
fi

