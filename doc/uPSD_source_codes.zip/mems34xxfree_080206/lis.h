/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          03/05/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// LIS
//-----------------------------------------------------------------------------
#ifndef LIS_H
#define LIS_H

#include "upsd34xx.h"

//-----------------------------------------------------------------------------
typedef struct {  
  s16 x;
  s16 y;
  s16 z;
} t_out16;

typedef struct {
  u8 outx_l;
  u8 outx_h;
  u8 outy_l;
  u8 outy_h;
  u8 outz_l;
  u8 outz_h;
} t_mems_data;  

typedef struct {
  u8 offset_x;
  u8 offset_y;
  u8 offset_z;    
  u8 gain_x;
  u8 gain_y;
  u8 gain_z;
  u8 ctrl_reg1;
  u8 ctrl_reg2;  
} t_mems_regs;

//-----------------------------------------------------------------------------
//---accelerometer register addresses---
#define OFFSET_X         0x16
#define OFFSET_Y         0x17
#define OFFSET_Z         0x18
#define GAIN_X           0x19
#define GAIN_Y           0x1A
#define GAIN_Z           0x1B
#define CTRL_REG1        0x20
#define CTRL_REG2        0x21
#define WAKE_UP_CFG      0x23
#define WAKE_UP_SRC      0x24
#define WAKE_UP_ACK      0x25
#define STATUS_REG       0x27
#define OUTX_L           0x28
#define OUTX_H           0x29
#define OUTY_L           0x2A
#define OUTY_H           0x2B
#define OUTZ_L           0x2C
#define OUTZ_H           0x2D
#define THS_L            0x2E
#define THS_H            0x2F
#define REPETIR          0x80

//-----------------------------------------------------------------------------
//---Settings for CTRL_REG1---

// Power Down Control (PD)
#define LIS_PD_OFF 0x00
#define LIS_PD_ON  0x40

// Decimation Factor Control (DF)
#define LIS_DF_BY128 0x00
#define LIS_DF_BY64  0x10
#define LIS_DF_BY32  0x20
#define LIS_DF_BY8   0x30

// Self Test
#define LIS_ST_NORMAL 0x00
#define LIS_ST_TEST   0x08

// Enable Axis
#define LIS_EA_ALL    0x07

//-----------------------------------------------------------------------------
//---Settings for CTRL_REG2---

// Full Scale (FS)
#define LIS_FS_2G 0x00
#define LIS_FS_6G 0x80

// Block Data Update (BDU)
#define LIS_BDU_CONTINUOUS 0x00
#define LIS_BDU_WAIT       0x40

// Big/Little Endian Selection (BLE)
#define LIS_BLE_LE 0x00
#define LIS_BLE_BE 0x20

// Data Alignment Selection DAS
#define LIS_DAS_12BIT 0x00
#define LIS_DAS_16BIT 0x01

//-----------------------------------------------------------------------------
//---Settings for ANALOG version---
// Power Down Control (PD), connected to P3.4
#define LISA_PD_OFF 0x00
#define LISA_PD_ON  0x10

// Full Scale (FS), connected to P3.5
#define LISA_FS_2G 0x00
#define LISA_FS_6G 0x20

// To clear P3.4, P3.5
#define BITS4_5 0x30

//-----------------------------------------------------------------------------
#define LIS_BLE_XX LIS_BLE_BE

//-----------------------------------------------------------------------------
void  LIS_Init (void);
void  LIS_Init_Analog (void);
void  LIS_Read_Out (t_out16 *a_actual);
void  LIS_Read_Out_Regs (t_mems_regs *mems_regs);
void  LIS_Read_Out_Data (t_mems_data *mems_data);

//-----------------------------------------------------------------------------
#endif
