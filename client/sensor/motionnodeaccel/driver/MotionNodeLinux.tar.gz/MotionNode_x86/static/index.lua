--
-- Return an string XML description of the current state of
-- the MotionNode system.
--
-- @file    static/index.lua
-- @author  Luke Tokheim, luke@motionnode.com
-- @version 1.2
--

-- 
local result = "<?xml version=\"1.0\"?>"
local root_name = "state"


if not node.system.is_initialized() then
  -- The system has not been initialized yet, i.e. no
  -- "initialize.lua" file has been loaded with the site
  -- specific preferences. Print the current preference
  -- values so the user can edit them and generate the
  -- "initialize.lua" file.
  root_name = "initialize"

  local preference = node.system.get_preference()
  local valid = false
  if (string.len(preference.address_canonical) > 0) and (string.len(preference.data_path) > 0) then
    valid = true
  end

  if (preference.valid_location == true) and (string.len(preference.data_path) > 0) then
    valid = true
  end


  result = result ..
    "<" .. root_name .. " version=\"1.0\""
  if node._DEMO then
    result = result .. " demo=\"" .. node.xml.encode_attribute(node._DEMO) .. "\""
  end
  result = result ..  
    " valid=\"" .. node.xml.encode_attribute(valid) .. "\">" ..
    "<address>" ..
    "<input>" .. node.xml.encode_string(preference.address_input) .. "</input>" ..
    "<canonical>" .. node.xml.encode_string(preference.address_canonical) .. "</canonical>" ..
    "</address>" ..
    "<data_path>" .. node.xml.encode_string(preference.data_path) .. "</data_path>" ..
    "<location>" .. 
    "<latitude>" .. node.xml.encode_string(preference.latitude) .. "</latitude>" ..
    "<longitude>" .. node.xml.encode_string(preference.longitude) .. "</longitude>" ..
    "<elevation>" .. node.xml.encode_string(preference.elevation) .. "</elevation>" ..
    "</location>" ..
    "<log_path>" .. node.xml.encode_string(preference.log_path) .. "</log_path>"
else
  
  function configuration_node_to_xml(configured_node, close_tag, is_connected, is_reading)
    if close_tag then
      close_tag = "/"
    else
      close_tag = ""
    end

    local optional = ""
    if configured_node.delay and configured_node.delay > 0 then
      optional = optional .. " delay=\"" .. node.xml.encode_attribute(configured_node.delay) .. "\""
      optional = optional .. " sample_rate=\"" .. node.xml.encode_attribute(node.delay_to_sample_rate(configured_node.delay)) .. "\""
    end    
    if not configured_node.active then
      optional = optional .. " active=\"" .. node.xml.encode_attribute(configured_node.active) .. "\""
    end
    if configured_node.bus then
      optional = optional .. " bus=\"" .. node.xml.encode_attribute(configured_node.bus) .. "\""
    end
    if configured_node.parent and string.len(configured_node.parent) > 0 then
      optional = optional .. " parent=\"" .. node.xml.encode_attribute(configured_node.parent) .. "\""
    end
    if configured_node.gyroscope_only then
      optional = optional .. " gyroscope_only=\"" .. node.xml.encode_attribute(configured_node.gyroscope_only) .. "\""
    end
    if configured_node.gain_sensor < 1 then
      optional = optional .. " gain_sensor=\"" .. node.xml.encode_attribute(configured_node.gain_sensor) .. "\""
    end
    if configured_node.gain_sensor_prefilter < 1 then
      optional = optional .. " gain_sensor_prefilter=\"" .. node.xml.encode_attribute(configured_node.gain_sensor_prefilter) .. "\""
    end     
    if configured_node.filter_version and configured_node.filter_version > 0 then
      optional = optional .. " filter_version=\"" .. node.xml.encode_attribute(configured_node.filter_version) .. "\""
    end
    --if configured_node.confidence and configured_node.confidence >= 0 then
    --  optional = optional .. " confidence=\"" .. node.xml.encode_attribute(configured_node.confidence) .. "\""
    --end

    return
      "<node" ..
      " key=\"" .. node.xml.encode_attribute(configured_node.key) .. "\"" ..
      " id=\"" .. node.xml.encode_attribute(configured_node.id) .. "\"" ..
      " name=\"" .. node.xml.encode_attribute(configured_node.name) .. "\"" ..
      " source=\"" .. node.xml.encode_attribute(configured_node.source) .. "\"" ..
      " gain=\"" .. node.xml.encode_attribute(configured_node.gain) .. "\"" ..
      " gselect=\"" .. node.xml.encode_attribute(configured_node.gselect) .. "\"" ..
      optional ..
      " connected=\"" .. node.xml.encode_attribute(is_connected or node.is_connected(configured_node.id)) .. "\"" ..
      " reading=\"" .. node.xml.encode_attribute(is_reading or node.is_reading(configured_node.id)) .. "\"" .. 
      close_tag ..
      ">"
  end

  function configuration_tree_to_xml(configured_node, close_tag)
    local result = configuration_node_to_xml(configured_node.value)
    
    for child_node in configured_node:children() do
      result = result .. configuration_tree_to_xml(child_node)
    end  
    
    result = result .. "</node>"
    
    return result
  end
  
  local is_taking = node.is_taking()
  local is_reading = is_taking or node.is_reading()
  local is_connected = is_reading or node.is_connected()
  local is_configured = is_connected or node.is_configured() 

  -- Create a summary of the configuration state in the root node.
  result = result ..
    "<" .. root_name .. " version=\"" .. node._VERSION .. "\""
  if node._DEMO then
    result = result .. " demo=\"" .. node.xml.encode_attribute(node._DEMO) .. "\""
  end
  result = result ..
    " configured=\"" .. node.xml.encode_attribute(is_configured) .. "\"" ..
    " connected=\"" .. node.xml.encode_attribute(is_connected) .. "\"" ..
    " reading=\"" .. node.xml.encode_attribute(is_reading) .. "\"" ..
    " taking=\"" .. node.xml.encode_attribute(is_taking) .. "\"" ..
    ">"

  -- The current configuration state. Print the current status of each
  -- configured Node.
  local container = node.configuration()
  if container then
    result = result .. "<configuration>"
    local configured_node
    for _,configured_node in pairs(container:list()) do
      result = result .. configuration_node_to_xml(configured_node, true, is_connected, is_reading)
    end
    result = result .. "</configuration>"
  end

  local preference = node.system.get_preference()
  if preference then
    result = result ..
      "<data_path>" .. node.xml.encode_string(preference.data_path) .. "</data_path>" .. 
      "<log_path>" .. node.xml.encode_string(preference.log_path) .. "</log_path>"
  end

  local take = node.take()
  if take then
    result = result ..
      "<take" ..
      " name=\"" .. node.xml.encode_attribute(take.name) .. "\"" ..
      " description=\"" .. node.xml.encode_attribute(take.description) .. "\"" ..
      " loaded_from=\"" .. node.xml.encode_attribute(take.loaded_from) .. "\"" ..
      ">"
    result = result .. "</take>"
  end 

end -- if not node.is_initialized() else


--
-- Shared nodes. 
--
local history = node.system.get_history()
if history then
  result = result .. "<history"
  local key, value
  for key,value in pairs(history) do
    result = result .. " " .. key .. "=\"" .. node.xml.encode_attribute(value) .. "\""
  end
  result = result .. "/>"
end

result = result .. "</" .. root_name .. ">"

return result
