//
//  AppController.h
//  JoyWarriorProgrammingTool24F14
//
//  Created by Erasmus Schröder on 5/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class IOHIDDeviceInterface122;

@interface AppController : NSObject {
	BOOL							deviceConnected;
    NSArray                         *interfaces;
	IOHIDDeviceInterface122			**interface;
	
	IBOutlet NSWindow				*imageWindow;
	NSMutableArray					*imageContent;
	
	IBOutlet NSPopUpButton			*deviceSerialField;
	IBOutlet NSPopUpButton			*deviceBandwidthField;
	IBOutlet NSPopUpButton			*deviceRangeField;
	IBOutlet NSPopUpButton			*deviceCompensationField;
	IBOutlet NSTextField			*customerSpecificByte1Field;
	IBOutlet NSTextField			*customerSpecificByte2Field;
	
	IBOutlet NSButton				*saveButton;
	IBOutlet NSButton				*statusUpdateButton;
	IBOutlet NSPopUpButton			*saveImageOrEEPROMField;
	IBOutlet NSProgressIndicator	*saveProgressIndicator;
	
	IBOutlet NSTableView			*statusTable;
	NSMutableArray					*statusFieldContent;
}

- (IBAction)	saveButtonClicked:(id) sender;
- (IBAction)	statusUpdateClicked:(id) sender;
- (IBAction)	showImageWindow:(id) sender;
- (IBAction)	setDeviceSerial:(id) sender;
- (IBAction)    doSoftReset:(id) sender;

- (NSArray *)   discoverInterfacesForJW24F14;
- (NSArray *)   discoverDevicePropertiesForJW24F14;

- (void)		updateDeviceState;
- (BOOL)		deviceConnected;
- (void)		setDeviceConnected: (BOOL) flag;

- (NSArray*)	statusFieldContent;


- (NSArray*)	imageContent;
- (void)		setImageContent:(NSArray *)a;
- (NSArray*)	retrieveImageContent;

@end
