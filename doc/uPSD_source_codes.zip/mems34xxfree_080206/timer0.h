/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// TIMER0
//-----------------------------------------------------------------------------
#ifndef TIMER0_H
#define TIMER0_H

#include "upsd34xx.h"

//-----------------------------------------------------------------------------
// TIMER0 basic functions
void TIMER0_Init_Mode1 (u16 timer_tics, u8 passes);
u8   TIMER0_Read_Flag (void);
u32  TIMER0_Read_Rtc (void);

// TIMER0 interrupt rutine
#if (COMPILER == SDCC)
  void TIMER0_isr (void) interrupt TF0_VECTOR using 1;
#endif

//-----------------------------------------------------------------------------
#endif
