Tests with JoyWarrior, MotionNode, and ONavi USB sensors side-by-side
(literally taped next to each other on ruler, resting on a desk which I "tapped")

x-bash slow 1-sec period 10 soft 10 hard, fast 3-5/sec 20 soft then 20 hard
y-bash slow 1-sec period 10 soft 10 hard, fast 3-5/sec 20 soft then 20 hard
z-bash slow 1-sec period 10 soft 10 hard, fast 3-5/sec 20 soft then 20 hard
very fast x/y/z periods
invert/rotate about x/y/z


onavi & motionnode had some dropouts, perhaps 3 devices on my Macbook's USB bus was too much?

