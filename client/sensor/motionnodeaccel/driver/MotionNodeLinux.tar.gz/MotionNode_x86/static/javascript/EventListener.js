/**
  @file    javascript/EventListener.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/

/**
  Add and remove element event listeners. Keep track
  of the current set so we can clear them on page
  unload.
*/
var GLI_EventListener = function() {
  var _container = [];

  return {
    clear : function()
    {
      for (var i=0; i<_container.length; i++) {
        GLI_EventListener.erase(_container[i].element, _container[i].type, _container[i].listener);
      }
      _container = null;
      _container = [];
    },
    erase : function(element, type, listener)
    {
      if (null === element) {
        if (window.removeEventListener) {
          window.removeEventListener(type, listener, false);
        } else if (document.detachEvent) {
          document.detachEvent('on' + type, listener);
        } else {
          throw "failed to remove event listener, missing implementation";
        }
      } else {
        if (element.removeEventListener) {
          element.removeEventListener(type, listener, false);
        } else if (element.detachEvent) {
          element.detachEvent('on' + type, listener);
        } else {
          throw "failed to remove event listener, missing implementation";
        }
      }

      for (var i=0; i<_container.length; i++) {
        if ((_container[i].element === element) && (_container[i].type === type) && (_container[i].listener === listener)) {
          _container.splice(i, 1);
          break;
        }
      }
    },
    erase_element : function(element)
    {
      var to_erase = [];
      for (var i=0; i<_container.length; i++) {
        if (_container[i].element === element) {
          to_erase.push(_container[i]);
        }
      }

      for (var i=0; i<to_erase.length; i++) {
        GLI_EventListener.erase(to_erase[i].element, to_erase[i].type, to_erase[i].listener);
      } 
    },
    insert : function(element, type, listener)
    {
      if (null === element) {
        if (window.addEventListener) {
          window.addEventListener(type, listener, false);
        } else if (document.attachEvent) {
          document.attachEvent('on' + type, listener);
        } else {
          throw "failed to add event listener, missing implementation";
        }
      } else {
        if (element.addEventListener) {
          element.addEventListener(type, listener, false);
        } else if (element.attachEvent) {
          element.attachEvent('on' + type, listener);
        } else {
          throw "failed to add event listener, missing implementation";
        }
      }
      _container.push({element: element, type: type, listener: listener});
    },
    stop : function(event)
    {
      if (event.stopPropagation) {
        event.stopPropagation();
      } else if (false === event.cancelBubble) {
        event.cancelBubble = true;
      } else {
        throw "failed to stop event propagation, missing implementation";
      }
    }
  }
}();
// END module GLI_EventListener
