//
//  main.m
//  JoyWarrior Calibration Tool
//
//  Created by ilja on 19.02.08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
