/**
  @file    javascript/Monitor.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/

/**
  Read this page in the background through an asyncronous
  HTTP request. Keep track of the string value of this page.
  If it changes, run a load_state command to refresh the page.
  
  This will only send a request if "false === GLI_Command.in_command()".
  A command will refresh the state if necessary after it completes.
*/
var GLI_Monitor = function()
{
  var _content = null;
  var _load_state_after_command = null;
  var _rate = 1000;

  return {
    check_content : function()
    {
      if ((false == GLI_Command.in_command())) { // && (false == GLI_Overlay.in_overlay())) {
        var rpc = new GLI_RemoteProcedureCall();
        rpc.get_xml(this_uri(), GLI_Monitor.check_content_callback);
      } else {
        // We are waiting for the result of an asynchronous command,
        // do not check the state for changes now, but schedule another
        // check for later.
        GLI_Monitor.schedule_check();
      }
    },
    schedule_check : function()
    {
      window.setTimeout(GLI_Monitor.check_content, _rate); 
    },
    check_content_callback : function(xml)
    {
      if (undefined !== xml) {
        if ((null !== _content) && (xml !== _content)) {
          window.location.reload(true);
        } else {
          _content = xml;
          window.setTimeout(GLI_Monitor.check_content, _rate);
        }
      }
    },
    load_state : function()
    {
      GLI_Command.notify('Loading state...');
  
      var state_pathname = '/';
      if ((false == _load_state_after_command) || (this_uri() == state_pathname)) {
        window.location.reload(true);
      } else {
        window.location.assign(state_pathname);
      }
    }, 
    set_rate : function(rate)
    {
      _rate = rate;
    },
    set_load_state : function(load_state_after_command)
    {
      _load_state_after_command = load_state_after_command;
    }   
  }
}();
// END module GLI_Monitor
