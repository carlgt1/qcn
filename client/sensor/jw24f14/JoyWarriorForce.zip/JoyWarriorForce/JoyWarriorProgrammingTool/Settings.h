//
//  Settings.h
//  JoyWarrior Programmingtool
//
//  Created by ilja on 26.10.07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Settings : NSObject {

	int			range;
	int			bandwidth;
	
	int			counterLG;
	BOOL		enableLG;
	int			hystLG;
	NSString	*durationLG;
	NSString	*thresholdLG;

	BOOL		enableHG;
	int			counterHG;
	int			hystHG;
	NSString	*durationHG;
	NSString	*thresholdHG;

	BOOL		enableAnyMotion;
	int			anyMotionDuration;
	NSString	*anyMotionThreshold;
	
	BOOL		latchInt;
	BOOL		newDataInt;
	BOOL		advInt;
	BOOL		alert;

	BOOL		shadowDis;

	NSString	*customByte1;
	NSString	*customByte2;
	
	BOOL		useEEPROM;
	
}

+ (int) intFromHexString:(NSString*) inString;
+ (NSString*) hexStringFromInt:(int) inValue;

- (NSData*) reportDataWithReadData:(NSData*) readData;
- (id) initWithReportData:(NSData*) inData fieldDescriptions:(NSDictionary*) inFieldDescriptions;

- (int) range;
- (void) setRange: (int) inRange;

- (int) bandwidth;
- (void) setBandwidth: (int) inBandwidth;

- (int) counterLG;
- (void) setCounterLG: (int) inCounterLG;

- (BOOL) enableLG;
- (void) setEnableLG: (BOOL) flag;

- (int) hystLG;
- (void) setHystLG: (int) inHystLG;

- (NSString *) durationLG;
- (void) setDurationLG: (NSString *) inDurationLG;

- (NSString *) thresholdLG;
- (void) setThresholdLG: (NSString *) inThresholdLG;

- (BOOL) enableHG;
- (void) setEnableHG: (BOOL) flag;

- (int) counterHG;
- (void) setCounterHG: (int) inCounterHG;

- (int) hystHG;
- (void) setHystHG: (int) inHystHG;

- (NSString *) durationHG;
- (void) setDurationHG: (NSString *) inDurationHG;

- (NSString *) thresholdHG;
- (void) setThresholdHG: (NSString *) inThresholdHG;

- (BOOL) enableAnyMotion;
- (void) setEnableAnyMotion: (BOOL) flag;

- (int) anyMotionDuration;
- (void) setAnyMotionDuration: (int) inAnyMotionDuration;

- (NSString *) anyMotionThreshold;
- (void) setAnyMotionThreshold: (NSString *) inAnyMotionThreshold;

- (BOOL) latchInt;
- (void) setLatchInt: (BOOL) flag;

- (BOOL) newDataInt;
- (void) setNewDataInt: (BOOL) flag;

- (BOOL) advInt;
- (void) setAdvInt: (BOOL) flag;

- (BOOL) alert;
- (void) setAlert: (BOOL) flag;

- (BOOL) shadowDis;
- (void) setShadowDis: (BOOL) flag;

- (NSString *) customByte1;
- (void) setCustomByte1: (NSString *) inCustomByte1;

- (NSString *) customByte2;
- (void) setCustomByte2: (NSString *) inCustomByte2;

- (BOOL) useEEPROM;
- (void) setUseEEPROM: (BOOL) flag;



@end
