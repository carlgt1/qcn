#import "AppController.h"
#import "Settings.h"
#include "DiscoverHIDInterface.h"
#include "JoyWarrior24F8.h"

@interface AppController (Private)

- (void) readStatusBitsFromInterface:(IOHIDDeviceInterface122**) inInterface;

@end

@implementation AppController

void JoyWarriorAddedOrRemoved(void *refCon, io_iterator_t iterator)
{
    io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
    }
	[[NSApp delegate] updateDeviceState];
}

- (CFMutableArrayRef) discoverInterfaces
{
	CFMutableArrayRef interfaces;

	// JoyWarrior24 Force 8
	interfaces = DiscoverHIDInterfaces	(0x07c0, 0x1113);
	if (CFArrayGetCount (interfaces) >= 2)
		return interfaces;
	
	if (interfaces)
		CFRelease (interfaces);
	// MouseWarrior25 Force 6
	
	interfaces = DiscoverHIDInterfaces	(0x07c0, 0x1114);
	if (CFArrayGetCount (interfaces) >= 2)
		return interfaces;
	
	CFRelease (interfaces);
	return nil;
}

- (CFMutableArrayRef) discoverDeviceProperties
{
	CFMutableArrayRef deviceProperties;
	
	// JoyWarrior24 Force 8
	deviceProperties = DiscoverHIDDeviceProperties	(0x07c0, 0x1113);
	if (CFArrayGetCount (deviceProperties))
		return deviceProperties;
	
	if (deviceProperties)
		CFRelease (deviceProperties);
	
	// MouseWarrior25 Force 6
	deviceProperties = DiscoverHIDDeviceProperties (0x07c0, 0x1114);
	if (CFArrayGetCount (deviceProperties))
		return deviceProperties;
	
	CFRelease (deviceProperties);
	return nil;
}

- (void) updateDeviceState
{
	CFMutableArrayRef interfaces;
	
	interfaces = [self discoverInterfaces];
	[self setDeviceConnected:(nil != interfaces) && (CFArrayGetCount (interfaces) >= 2)];
	if (interfaces)
	{
		CFRelease (interfaces);
	}
	if (deviceConnected)
	{
		CFMutableArrayRef deviceProperties;
		
		deviceProperties = [self discoverDeviceProperties];
		if ( CFArrayGetCount (deviceProperties))
		{
			CFDictionaryRef	  properties = CFArrayGetValueAtIndex(deviceProperties, 0);
			[deviceTypeField setStringValue:[(NSDictionary*) properties valueForKey:@"Product"]]; 
			[deviceSerialField setStringValue:[(NSDictionary*) properties valueForKey:@"SerialNumber"]];
			
			[self readSettings:nil];
		}
		
		CFRelease (deviceProperties);
	}
	else
	{
		[deviceSerialField setStringValue:@""];
		[deviceTypeField setStringValue:@""];
		
		[self resetColorWells];
		[self setRegisterCheckStati:[NSArray array]];
	}
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	[self setCurrentSettings:[[[Settings alloc] init] autorelease]]; 
	
	// trigger data window update
	[self observeValueForKeyPath:@"" ofObject:[self currentSettings] change:nil context:NULL];
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	
	[self updateDeviceState];
	
	[self resetColorWells];

}

- (void) resetColorWells
{
	[self setSelfTestColor:[NSColor grayColor]];
	[self setHighGColor:[NSColor grayColor]];
	[self setLowGColor:[NSColor grayColor]];
	[self setHgLatchedColor:[NSColor grayColor]];
	[self setLgLatchedColor:[NSColor grayColor]];
	[self setAlertPhaseColor:[NSColor grayColor]];
}

- (void) registerForSettingsKeyChange:(Settings*) inSettings
{
	NSEnumerator	*e = [[[self fieldsDictionary] allKeys] objectEnumerator];
	NSString		*key;
	
	while (nil != (key = [e nextObject]))
	{
		[inSettings addObserver:self
			   forKeyPath:key
				  options:0
				  context:nil];
	}
}

- (void) unregisterForSettingsKeyChange:(Settings*) inSettings
{
	NSEnumerator	*e = [[[self fieldsDictionary] allKeys] objectEnumerator];
	NSString		*key;
	
	while (nil != (key = [e nextObject]))
	{
		[inSettings removeObserver:self
					 forKeyPath:key];
	}
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{	
	UInt8						emptyData[11];
	UInt8						*reportBytes;
	NSData						*reportData;
	int							i;
	NSMutableAttributedString	*newBitString = [[[NSMutableAttributedString alloc] init] autorelease];
	NSDictionary				*keyDictionary = [[self fieldsDictionary] objectForKey:keyPath]; 
	
	bzero (emptyData, sizeof (emptyData));
	reportData = [[self currentSettings] reportDataWithReadData:[NSData dataWithBytes:emptyData
																			   length:11]];
	
	reportBytes = (UInt8*)[reportData bytes];
	for (i = 10; i >= 0; i--)
	{
		int j = 0;
		
		for (j = 7; j >= 0; j--)
		{
			if (reportBytes[i] & 1 << j)
			{
				[newBitString appendAttributedString:[[[NSAttributedString alloc] initWithString:@"1"] autorelease]]; 
			}
			else
			{
				[newBitString appendAttributedString:[[[NSAttributedString alloc] initWithString:@"0"] autorelease]]; 
			}
			// check if this bit belongs to the changed key, if so, color it red
			if ((i == [[keyDictionary objectForKey:@"byte"] intValue]) &&
				(j >= [[keyDictionary objectForKey:@"startBit"] intValue]) &&
				(j < [[keyDictionary objectForKey:@"startBit"] intValue] + [[keyDictionary objectForKey:@"length"] intValue]))
			{
				[newBitString setAttributes:[NSDictionary dictionaryWithObject:[NSColor redColor] forKey:NSForegroundColorAttributeName]
									  range:NSMakeRange ([newBitString length] - 1, 1)];
			}
		}
		[newBitString appendAttributedString:[[[NSAttributedString alloc] initWithString:@"\n"] autorelease]]; 
		
	}
	
	[newBitString addAttributes:[NSDictionary dictionaryWithObject:[NSFont fontWithName:@"Monaco" size:10] forKey:NSFontAttributeName]
						  range:NSMakeRange (0, [newBitString length])];
	
	[self setBitString:newBitString];

}

- (NSDictionary*) fieldsDictionary
{
	static NSDictionary *result = nil;
	
	if (result == nil)
	{
		NSString	 *fieldsFilePath = [[NSBundle mainBundle] pathForResource:@"fields" ofType:@"plist"];
		
		result = [NSDictionary dictionaryWithContentsOfFile:fieldsFilePath];
		NSAssert (result, @"couldn't load field.plist");
		[result retain];
	}
	return result;
}

- (IBAction)readSettings:(id)sender
{
	CFMutableArrayRef interfaces;
	
	if (NO == [self checkForJoyWarrior])
		return;
	
	interfaces = [self discoverInterfaces];

	if (CFArrayGetCount (interfaces) >= 2)
	{
		CFNumberRef				hidInterfaceRef;
		IOHIDDeviceInterface122	**hidInterface;
		int						address;
		UInt8					reportData[11];
		
		hidInterfaceRef = CFArrayGetValueAtIndex(interfaces,1);
		CFNumberGetValue(hidInterfaceRef,kCFNumberLongType,&hidInterface);
		
		if ([currentSettings useEEPROM])
		{
			// force eeprom content to be written to image
			NSLog (@"Write to address: 0x%02X value: 0x%02X", 0x0A, 0x20);
			JWWriteByteToAddress (hidInterface, 0x0A, 0x20);
		}
		
		for (address = 0x0B; address < 0x16; address++)
		{
			JWReadByteFromAddress (hidInterface, address, &reportData[address - 0x0B]);
			
			NSLog (@"Read from address: 0x%02X value: 0x%02X", address, reportData[address - 0x0B]);
		}
		
		Settings *newSettings = [[[Settings alloc] initWithReportData:[NSData dataWithBytes:reportData length:11]
												   fieldDescriptions:[self fieldsDictionary]] autorelease];
		
		[self updateRegisterStatiWithReadData:[NSData dataWithBytes:reportData length:11]  expectedData:nil];

		
		// copy EEPROM flag to preserve current settings
		[newSettings setUseEEPROM:[currentSettings useEEPROM]];
																	
		[self setCurrentSettings:newSettings];
		
		[self readStatusBitsFromInterface:hidInterface];
	}
		
	ReleaseInterfaces (interfaces);
	CFRelease (interfaces);

}

- (IBAction)writeSettings:(id)sender
{
	if (NO == [self checkForJoyWarrior])
		return;
	

	UInt8						emptyData[11];
	CFNumberRef					hidInterfaceRef;
	IOHIDDeviceInterface122		**hidInterface;
	int							address;
	NSData						*reportData;
	UInt8*						reportDataBytes;
	CFMutableArrayRef			interfaces;
	int							addressOffset = 0;

	interfaces = [self discoverInterfaces];
	hidInterfaceRef = CFArrayGetValueAtIndex(interfaces,1);
	CFNumberGetValue(hidInterfaceRef,kCFNumberLongType,&hidInterface);
	
	if ([currentSettings useEEPROM])
	{
		// force eeprom content to be written to image
		NSLog (@"Write to address: 0x%02X value: 0x%02X", 0x0A, 0x20);
		JWWriteByteToAddress (hidInterface, 0x0A, 0x20);
	}
	
	bzero (emptyData,sizeof(emptyData));
	// read byte at 0x14 to get value of reserved field
	JWReadByteFromAddress(hidInterface,0x14,&emptyData[9]);
	NSLog (@"Read from address: 0x%02X value: 0x%02X", 0x14, emptyData[9]);

	reportData = [[self currentSettings] reportDataWithReadData:[NSData dataWithBytes:emptyData
																			   length:11]];
	
	reportDataBytes =  (UInt8*)[reportData bytes];
	
	if ([currentSettings useEEPROM])
	{
		// unlock eeprom
		NSLog (@"Write to address: 0x%02X value: 0x%02X", 0x0A, 0x10);
		JWWriteByteToAddress (hidInterface, 0x0A, 0x10);
	}
	
	if ([currentSettings useEEPROM])
		addressOffset = 0x20;
	
	for (address = 0x0B; address < 0x16; address++)
	{
		NSLog (@"Write to address: 0x%02X value: 0x%02X", address + addressOffset, reportDataBytes[address - 0x0B]);

		JWWriteByteToAddress (hidInterface, address + addressOffset, reportDataBytes[address - 0x0B]);
		if ([currentSettings useEEPROM])
			usleep(10000);
	}
	
	if ([currentSettings useEEPROM])
	{
		// force eeprom content to be written to image
		NSLog (@"Write to address: 0x%02X value: 0x%02X", 0x0A, 0x20);
		JWWriteByteToAddress (hidInterface, 0x0A, 0x20);
	}
	
	// read back written data to compare it computed report data
	
	UInt8			readBytes[11];
	
	for (address = 0x0B; address < 0x16; address++)
	{
		JWReadByteFromAddress (hidInterface, address, &readBytes[address - 0x0B]);
	}
	[self updateRegisterStatiWithReadData:[NSData dataWithBytes:readBytes length:11]
							 expectedData:reportData];
	
	ReleaseInterfaces (interfaces);
	CFRelease (interfaces);
}

- (void) updateRegisterStatiWithReadData:(NSData*) inReadData expectedData:(NSData*) inExpectedData
{
	NSMutableArray	*registerStati = [NSMutableArray array];
	UInt8			*readData = (UInt8*)[inReadData bytes],
					*expectedData = (UInt8*) [inExpectedData bytes];
	int				i;
	
	for (i = 0; i < [inReadData length]; i++)
	{
		NSMutableDictionary	*registerStatus = [NSMutableDictionary dictionary];
				
		[registerStatus setObject:[NSString stringWithFormat:@"0x%02X", i + 0x0B] forKey:@"register"];
		[registerStatus setObject:[NSString stringWithFormat:@"0x%02X", readData[i]] forKey:@"value"];
		if (inExpectedData != nil)
		{
			[registerStatus setObject: ((readData[i] ==  expectedData[i]) ? @"OK" : @"Fail") forKey:@"check"];
		}
		else
		{
			[registerStatus setObject: @"" forKey:@"check"];
		}
		
		[registerStati addObject:registerStatus];
	}	
	
	
	
	[self setRegisterCheckStati:registerStati];
}

- (BOOL) checkForJoyWarrior
{
	CFMutableArrayRef	interfaces = [self discoverInterfaces];
	int					interfaceCount = CFArrayGetCount (interfaces);
	
	ReleaseInterfaces (interfaces);
	CFRelease (interfaces);
	
	if (interfaceCount == 0)
	{
		 NSRunAlertPanel (@"No JoyWarrior Found",
													 @"Please connect a JoyWarrior to you Mac.",
													 @"OK",
													 @"Cancel",
													 nil);
	}
	
	return (interfaceCount > 0);
}


- (void) dealloc
{
    [self setCurrentSettings: nil];
	[self setBitString: nil];
	[self setLastFileName: nil];
	[self setRegisterCheckStati: nil];
	
	[self setSelfTestColor: nil];
    [self setHighGColor: nil];
    [self setLowGColor: nil];
    [self setHgLatchedColor: nil];
    [self setLgLatchedColor: nil];
    [self setAlertPhaseColor: nil];
	
    [super dealloc];
}



- (Settings *) currentSettings
{
    return currentSettings; 
}

- (void) setCurrentSettings: (Settings *) inCurrentSettings
{
    if (currentSettings != inCurrentSettings) {
		
		if (nil != currentSettings)
		{
			[self unregisterForSettingsKeyChange:currentSettings];
		}
		
        [currentSettings autorelease];
        currentSettings = [inCurrentSettings retain];
		
		if (nil != currentSettings)
		{
			[self registerForSettingsKeyChange:currentSettings];
		}
    }
}

- (NSAttributedString *) bitString
{
    return bitString; 
}

- (void) setBitString: (NSAttributedString *) inBitString
{
    if (bitString != inBitString) {
        [bitString autorelease];
        bitString = [inBitString retain];
    }
}

- (IBAction) save:(id) sender
{
	[self saveSettings];
}

- (IBAction) saveAs:(id) sender
{
	NSString *temp = [[self lastFileName] retain];
	
	[self setLastFileName:nil];
	if (NO == [self saveSettings])
	{
		[self setLastFileName:temp];
	}
	[temp release];
}


- (BOOL) saveSettings
{
	if ([self lastFileName])
	{
		[NSKeyedArchiver archiveRootObject:[self currentSettings] toFile:[self lastFileName]];
		return YES;
	}

	NSSavePanel *savePanel= [NSSavePanel savePanel];
	
	[savePanel setAllowedFileTypes:[NSArray arrayWithObject:@"jwSettings"]];
	if ([savePanel runModal])
	{
		NSString *filename = [savePanel filename];
		
		[NSKeyedArchiver archiveRootObject:[self currentSettings] toFile:filename];
		[self setLastFileName:filename];
		return YES;
	}
	return NO;
}

- (IBAction) open:(id) sender
{
	NSOpenPanel *openPanel= [NSOpenPanel openPanel];
	
	[openPanel setCanChooseDirectories:NO];
	[openPanel setCanChooseFiles:YES];
	if ([openPanel runModalForDirectory:nil
								   file:nil
								  types:[NSArray arrayWithObject:@"jwSettings"]])
	{
		[self setCurrentSettings:[NSKeyedUnarchiver unarchiveObjectWithFile:[openPanel filename]]];
		[self setLastFileName:[openPanel filename]];
	}
}

- (BOOL) deviceConnected
{
	
    return deviceConnected;
}

- (void) setDeviceConnected: (BOOL) flag
{
	deviceConnected = flag;
}

- (NSString *) lastFileName
{
    return lastFileName; 
}

- (void) setLastFileName: (NSString *) inLastFileName
{
    if (lastFileName != inLastFileName) {
        [lastFileName autorelease];
        lastFileName = [inLastFileName retain];
    }
}

- (IBAction) anyMotionMatrixClicked:(id) sender
{

	switch  ([[sender selectedCell] tag])
	{
		case 0:
			[currentSettings setEnableAnyMotion:NO];
			[currentSettings setAlert:NO];
			break;
		
		case 1:
			[currentSettings setEnableAnyMotion:YES];
			[currentSettings setAlert:NO];
			break;
			
		case 2:
			[currentSettings setEnableAnyMotion:NO];
			[currentSettings setAlert:YES];
			break;
			
		
	}
}

- (NSArray *) registerCheckStati
{
    return registerCheckStati; 
}

- (void) setRegisterCheckStati: (NSArray *) inRegisterCheckStati
{
    if (registerCheckStati != inRegisterCheckStati) {
        [registerCheckStati autorelease];
        registerCheckStati = [inRegisterCheckStati retain];
    }
}

- (NSColor *) selfTestColor
{
    return selfTestColor; 
}

- (void) setSelfTestColor: (NSColor *) inSelfTestColor
{
    if (selfTestColor != inSelfTestColor) {
        [selfTestColor autorelease];
        selfTestColor = [inSelfTestColor retain];
    }
}


- (NSColor *) highGColor
{
    return highGColor; 
}

- (void) setHighGColor: (NSColor *) inHighGColor
{
    if (highGColor != inHighGColor) {
        [highGColor autorelease];
        highGColor = [inHighGColor retain];
    }
}


- (NSColor *) lowGColor
{
    return lowGColor; 
}

- (void) setLowGColor: (NSColor *) inLowGColor
{
    if (lowGColor != inLowGColor) {
        [lowGColor autorelease];
        lowGColor = [inLowGColor retain];
    }
}


- (NSColor *) hgLatchedColor
{
    return hgLatchedColor; 
}

- (void) setHgLatchedColor: (NSColor *) inHgLatchedColor
{
    if (hgLatchedColor != inHgLatchedColor) {
        [hgLatchedColor autorelease];
        hgLatchedColor = [inHgLatchedColor retain];
    }
}


- (NSColor *) lgLatchedColor
{
    return lgLatchedColor; 
}

- (void) setLgLatchedColor: (NSColor *) inLgLatchedColor
{
    if (lgLatchedColor != inLgLatchedColor) {
        [lgLatchedColor autorelease];
        lgLatchedColor = [inLgLatchedColor retain];
    }
}


- (NSColor *) alertPhaseColor
{
    return alertPhaseColor; 
}

- (void) setAlertPhaseColor: (NSColor *) inAlertPhaseColor
{
    if (alertPhaseColor != inAlertPhaseColor) {
        [alertPhaseColor autorelease];
        alertPhaseColor = [inAlertPhaseColor retain];
    }
}

- (BOOL) colorWellEnabledState
{
	
    return colorWellEnabledState;
}

- (void) setColorWellEnabledState: (BOOL) flag
{
	colorWellEnabledState = flag;
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

@end

@implementation AppController (Private)

- (void) readStatusBitsFromInterface:(IOHIDDeviceInterface122**) inInterface
{
  UInt8	statusBits;
  
  JWReadByteFromAddress (inInterface, 0x9, &statusBits);
  
  [self setSelfTestColor:(statusBits & 0x80 ? [NSColor greenColor] : [NSColor grayColor])];
  [self setHighGColor:(statusBits & 0x01 ? [NSColor greenColor] : [NSColor grayColor])];
  [self setLowGColor:(statusBits & 0x02 ? [NSColor greenColor] : [NSColor grayColor])];
  [self setHgLatchedColor:(statusBits & 0x04 ? [NSColor greenColor] : [NSColor grayColor])];
  [self setLgLatchedColor:(statusBits & 0x08 ? [NSColor greenColor] : [NSColor grayColor])];
  [self setLgLatchedColor:(statusBits & 0x10 ? [NSColor greenColor] : [NSColor grayColor])];
}
		  
@end