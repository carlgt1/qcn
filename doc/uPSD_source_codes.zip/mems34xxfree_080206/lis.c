/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          03/05/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// LIS
//-----------------------------------------------------------------------------
#include "upsd34xx.h"
#include "board.h"
#include "lis.h"
#include "i2c.h"

#if (COMPILER == KEIL)
  #pragma NOAREGS
#endif  

//-----------------------------------------------------------------------------
void LIS_Init (void)
{
  Time_Delay (10*DELAY_1MS);
  (void) i2c_write_reg (kLIS3L02DQ_SLAVE_ADDR, WAKE_UP_CFG, 0x00);   //no wake-up
  (void) i2c_write_reg (kLIS3L02DQ_SLAVE_ADDR, STATUS_REG, 0x00);    //no flag
  (void) i2c_write_reg (kLIS3L02DQ_SLAVE_ADDR, CTRL_REG2, LIS_FS_2G + LIS_BDU_CONTINUOUS + LIS_BLE_XX + LIS_DAS_12BIT); //0x00
  (void) i2c_write_reg (kLIS3L02DQ_SLAVE_ADDR, CTRL_REG1, LIS_PD_ON + LIS_DF_BY32 + LIS_ST_NORMAL + LIS_EA_ALL);       //0x47
  Time_Delay (10*DELAY_1MS);
}

//-----------------------------------------------------------------------------
void LIS_Init_Analog (void)
{
  P3 &= ~BITS4_5;
  P3 |= LISA_PD_OFF|LISA_FS_2G;
  Time_Delay (10*DELAY_1MS);
}

//-----------------------------------------------------------------------------
// Work with LIS
//-----------------------------------------------------------------------------
void LIS_Read_Out (t_out16 *a_actual)
{
  u16 dato;

  if (i2c_read_buffer_u16 (0,&dato,LIS_BLE_XX))
    a_actual->x = (s16) dato;

  if (i2c_read_buffer_u16 (2,&dato,LIS_BLE_XX))
    a_actual->y = (s16) dato;

  if (i2c_read_buffer_u16 (4,&dato,LIS_BLE_XX))
    a_actual->z = (s16) dato;
}

//-----------------------------------------------------------------------------
void LIS_Read_Out_Regs (t_mems_regs *mems_regs)
{
  u8 dato;

  if (i2c_read_buffer_u8 (0,&dato))
    mems_regs->offset_x = dato;

  if (i2c_read_buffer_u8 (1,&dato))
    mems_regs->offset_y = dato;

  if (i2c_read_buffer_u8 (2,&dato))
    mems_regs->offset_z = dato;

  if (i2c_read_buffer_u8 (3,&dato))
    mems_regs->gain_x = dato;

  if (i2c_read_buffer_u8 (4,&dato))
    mems_regs->gain_y = dato;

  if (i2c_read_buffer_u8 (5,&dato))
    mems_regs->gain_z = dato;

  if (i2c_read_buffer_u8 (10,&dato))
    mems_regs->ctrl_reg1 = dato;

  if (i2c_read_buffer_u8 (11,&dato))
    mems_regs->ctrl_reg2 = dato;
}

//-----------------------------------------------------------------------------
void LIS_Read_Out_Data (t_mems_data *mems_data)
{
  u8 dato;
  
#if (LIS_BLE_XX == LIS_BLE_BE)
  if (i2c_read_buffer_u8 (0,&dato))
    mems_data->outx_h = dato;

  if (i2c_read_buffer_u8 (1,&dato))
    mems_data->outx_l = dato;
      
  if (i2c_read_buffer_u8 (2,&dato))    
    mems_data->outy_h = dato;

  if (i2c_read_buffer_u8 (3,&dato))   
    mems_data->outy_l = dato;
       
  if (i2c_read_buffer_u8 (4,&dato))    
    mems_data->outz_h = dato;  

  if (i2c_read_buffer_u8 (5,&dato))    
    mems_data->outz_l = dato;
#endif

#if (LIS_BLE_XX == LIS_BLE_LE)
  if (i2c_read_buffer_u8 (0,&dato))
    mems_data->outx_l = dato;

  if (i2c_read_buffer_u8 (1,&dato))   
    mems_data->outx_h = dato;
    
  if (i2c_read_buffer_u8 (2,&dato))   
    mems_data->outy_l = dato;
    
  if (i2c_read_buffer_u8 (3,&dato))    
    mems_data->outy_h = dato;
    
  if (i2c_read_buffer_u8 (4,&dato))    
    mems_data->outz_l = dato;
    
  if (i2c_read_buffer_u8 (5,&dato))    
    mems_data->outz_h = dato;
#endif    
}  

//-----------------------------------------------------------------------------