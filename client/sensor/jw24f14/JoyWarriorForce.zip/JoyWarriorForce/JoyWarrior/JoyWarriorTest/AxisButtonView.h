//
//  AxisButtonView.h
//  JoyWarriorTest
//
//  Created by Guido K�rber on 17.09.04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ButtonView.h"

@interface AxisButtonView : ButtonView {
	int	maxValue;
	int	minValue;

}

- (int) maxValue;
- (void) setMaxValue: (int) inMaxValue;

- (int) minValue;
- (void) setMinValue: (int) inMinValue;


@end
