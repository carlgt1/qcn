/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// UART0
//-----------------------------------------------------------------------------
#include "upsd34xx.h"
#include "uart0.h"
#include "timer1.h"
#include <stdio.h>

#if (COMPILER == KEIL)
  #pragma NOAREGS
#endif  

//-----------------------------------------------------------------------------
#define UART0_BUFFER_SIZE 100
xdata u8 UART0_Print_Buffer [UART0_BUFFER_SIZE];
xdata u16 UART0_Print_Length = 0;

//-----------------------------------------------------------------------------
void UART0_Init (void)
{
  //Enable UART pins
  SetBit(P3SFS,UART_TXD0_PIN); //Enable TXD0
  SetBit(P3SFS,UART_RXD0_PIN); //Enable RXD0

  //Start TIMER1 for UART timing
  TIMER1_Init_Mode2 (TH1_VALUE);

  //Configure UART
  if (SMOD0_value == 1)
    SetBit(PCON,SMOD0);
  else
    ClrBit(PCON,SMOD0);

  SCON = 0x50;        //0101 0000, mode=1, REN
  #if (UART0_OPERATION_MODE == UART0_CONTINUOUS_MODE)
    SCON_TI = 1;
  #endif

  UART0_Print_Length = 0;
}

//-----------------------------------------------------------------------------
void UART0_Send (u8 value)
{
  #if (UART0_OPERATION_MODE == UART0_CONTINUOUS_MODE)
    while (!SCON_TI);
    SCON_TI = 0;
    SBUF = value;
  #else
    SCON_TI = 0;
    SBUF = value;
    while (!SCON_TI);
    SCON_TI = 0;
  #endif
}

//-----------------------------------------------------------------------------
void UART0_Send_Buffer (void)
{
  //xdata u8 i;
  xdata u16 i;

  for (i=0;i<UART0_Print_Length;i++)
    UART0_Send (UART0_Print_Buffer[i]);

  UART0_Send (0x0A);  //comment this line for excel capture
  UART0_Send (0x0D);

  UART0_Print_Length = 0;
}

//-----------------------------------------------------------------------------
u8 UART0_Receive (void)
{
  while (!SCON_RI);
  SCON_RI = 0;
  return (SBUF);
}

//-----------------------------------------------------------------------------
// Work with UART
//-----------------------------------------------------------------------------
void UART0_Print_u8 (u8 dato)
{ 
  if (UART0_Print_Length < (UART0_BUFFER_SIZE-5))
    UART0_Print_Length += sprintf (UART0_Print_Buffer + UART0_Print_Length,"%bu ", dato);    
}

//-----------------------------------------------------------------------------
void UART0_Print_Out16 (t_out16 *out)
{
  if (UART0_Print_Length < (UART0_BUFFER_SIZE-20))
    UART0_Print_Length += sprintf (UART0_Print_Buffer + UART0_Print_Length,"%+5d %+5d %+5d ", out->x, out->y, out->z);    
}

//-----------------------------------------------------------------------------
// For USB debug purposes
//-----------------------------------------------------------------------------
void UART0_Print_ConstText (const u8 *config_str, const u8 *text_buffer)
{  
  if (UART0_Print_Length < (UART0_BUFFER_SIZE-30))
    UART0_Print_Length += sprintf (UART0_Print_Buffer + UART0_Print_Length,config_str,text_buffer);       
}

//-----------------------------------------------------------------------------

