/**
  @file    javascript/Command.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/

/**
  Execute a user interface command. This may include prompting
  for an input parameter or command confirmation.
*/
var GLI_Command = function() {
  var _in_command = false;
  var _in_chunk = null;
  var _notify_id = 'notify';

  return {
    /**
      Send an asynchronous command to the HTTP console. Variable number of arguments.
    */
    send : function()
    {
      if ((false === _in_command) && (arguments.length > 0)) {
        _in_command = true;
        try {
          var rpc = new GLI_RemoteProcedureCall(GLI_Command.notify, GLI_Command.callback_send);
          rpc.command(arguments);
        } catch (e) {
          GLI_Command.callback_send();
          throw e;
        }
      }
    },
    /**
      Prompt the user for some string value before we issue the command.
    */
    send_prompt : function(command, message, value, id)
    {      
      var argument = window.prompt(message, value);
      if (argument) {
        if (typeof value == "number") {
          argument = parseFloat(argument);
        }
      
        GLI_Command.send(command, argument, id);
      }
    },
    /**
      Ask the user for confirmation before we issue the command.
    */
    send_confirm : function(command, message, id)
    {
      var argument = window.confirm(message);
      if (argument) {
        GLI_Command.send(command, id);
      }
    },
    /**
      Utility function to generate a zero-arity function from a menu item definition.
    */
    make_command_callback : function(definition, id)
    {
      if (undefined === definition.prompt) {
        return GLI_Command.send.bind(GLI_Command.send, definition.command, id);
      } else if (undefined === definition.value) {
        return GLI_Command.send_confirm.bind(GLI_Command.send_confirm, definition.command, definition.prompt, id);
      } else {
        return GLI_Command.send_prompt.bind(GLI_Command.send_prompt, definition.command, definition.prompt, definition.value, id);
      } 
    },
    send_chunk : function(chunk)
    {
      if ((false === _in_command) && chunk && (chunk.length > 0)) {
        _in_command = true;
        try {
          var rpc = new GLI_RemoteProcedureCall(GLI_Command.notify, GLI_Command.callback_send_chunk);
          _in_chunk = chunk;
          rpc.command_chunk(chunk);
        } catch (e) {
          GLI_Command.callback_send_chunk();
          throw e;
        }
      }
    },
    /**
      Public accessor for command in progress flag.
    */
    in_command : function()
    {
      return _in_command;
    },
    callback_send : function(result)
    {
      GLI_Command.notify("");
      _in_command = false;
    },
    callback_send_chunk : function(result)
    {
      GLI_Command.notify("");
      _in_command = false;
      
      var element = document.getElementById('interactive_output');
      if (element) {
        if (_in_chunk) {
          var div = document.createElement('div');
          div.appendChild(document.createTextNode('http> ' + _in_chunk));
          
          element.appendChild(div);
        }
        
        if (result && (result.length > 0)) {
          var div = document.createElement('div');
          div.appendChild(document.createTextNode(result));
        
          element.appendChild(div);
        }
      }
    },
    notify : function(message)
    {
      var element = document.getElementById(_notify_id);
      if (element) {
        element.innerHTML = message.toString();
    
        if (message.length > 0) {
          element.style.display = 'block';
        } else {
          element.style.display = 'none';
        }
      }
    }
  }
}();
// END module GLI_Command
