/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// I2C(2)
//-----------------------------------------------------------------------------
#include "upsd34xx.h"
#include "board.h"
#include "i2c.h"
#include "lis.h"

#if (COMPILER == KEIL)
  #pragma NOAREGS
#endif

//-----------------------------------------------------------------------------
// Variables for I2C
//-----------------------------------------------------------------------------
xdata u8 i2c_buffer[20];                           
xdata u8 i2c_data_index, i2c_data_length, i2c_state;

//-----------------------------------------------------------------------------
// I2C basic functions
//-----------------------------------------------------------------------------
void I2C_Init (void)
{    
  //Disable SPI first (SPI and I2C are wired on the same pin of MEMS chip)
  ClrBit(P4SFS0,SPI_SEL_PIN); ClrBit(P4SFS1,SPI_SEL_PIN); //GPIO, input
  ClrBit(P4SFS0,SPI_TXD_PIN); ClrBit(P4SFS1,SPI_TXD_PIN); //GPIO, input
  ClrBit(P4SFS0,SPI_RXD_PIN); ClrBit(P4SFS1,SPI_RXD_PIN); //GPIO, input
  ClrBit(P4SFS0,SPI_CLK_PIN); ClrBit(P4SFS1,SPI_CLK_PIN); //GPIO, input

  //Enable I2C
  P4_7 = 1;                     // GPIO, output = 1 (= select I2C on MEMS chip)
  SetBit(P3SFS,I2C_SDA_PIN);    // Enable P3.6 for SDA 
  SetBit(P3SFS,I2C_SCL_PIN);    // Enable P3.7 for SCL

  S1CON = S1CON_VALUE;          // I2C bit rate  
  S1SETUP = kS1SETUP_VALUE;     // Set start and stop hold time

  SetBit(IPA,PI2C);             // Set high priority for I2C interrupt
//ClrBit(IPA,PI2C);             // Set low priority for I2C interrupt
  SetBit(IEA,EI2C);             // Set I2C interrupt Enable bit
  
  i2c_state = kNO_ACTION;       // Set I2C state
  SetBit(S1CON,ENI);            // Enable I2C
}

//-----------------------------------------------------------------------------
u8 i2c_write_reg (u8 device_addr, u8 reg_addr, u8 reg_value)
{
  i2c_state = kMASTER_SEND;                         // Set up I2C state.
  i2c_buffer[0] = device_addr + kSLAVE_ADDR_WRITE;  // SAD+W
  i2c_buffer[1] = reg_addr;                         // SUB (register address)
  i2c_buffer[2] = reg_value;                        // DATA (value of register)
  i2c_data_length = 3;                              // Initialize length of data to be transmitted
  return (i2c_master ());
}

//-----------------------------------------------------------------------------
u8 i2c_read_reg (u8 device_addr, u8 reg_addr, u8 length)
{
  i2c_state = kMASTER_RECEIVE;                      // Set up I2C state.
  i2c_buffer[0] = device_addr + kSLAVE_ADDR_WRITE;  // SAD+W
  i2c_buffer[1] = reg_addr;                         // SUB (register address )
  i2c_buffer[2] = device_addr + kSLAVE_ADDR_READ;   // SAD+R
  i2c_data_length = 3+length;        
  return (i2c_master ());
}

//-----------------------------------------------------------------------------
u8 i2c_master (void)
{
  LEDx_toggle (LED5,5);
  ClrBit(IEA,EI2C);             // Disable I2C interrupt
  while (ValBit(S1STA,BBUSY));  // wait for BBUSY to be clear
  SetBit(S1CON,ENI);            // Enable I2C
  SetBit(S1CON,STA);            // Set STA (send start bit)
  ClrBit(S1CON,STO);            // Clear STO (no stop bit)
  ClrBit(S1CON,AA);             // Clear AA (no acknowledge)
  S1DAT = i2c_buffer[0];        // it should be SAD (+W or +R)
  i2c_data_index = 1;           // First data has been sent
  SetBit(IEA,EI2C);             // Enable I2C interrupt

  while ((i2c_state == kMASTER_SEND) || (i2c_state == kMASTER_RECEIVE));
  return(i2c_state);            // Return I2C current state
}

//-----------------------------------------------------------------------------
void i2c_isr (void) interrupt I2C_VECTOR using 2
{ 
  #if (DEBUG == DEBUG_ON)
    P1_2 = 1;
    P1_2 = 0;
  #endif

  ClrBit(S1STA,INTR);                       // Clear interrupt flag

  //------Master transmit operation--------------------------------------------
  if (i2c_state == kMASTER_SEND)
  {
    if (i2c_test_BLOST() == kBUSLOST)
      return;

    if (i2c_test_ACKREP() == kNACK)
      return;

    //send data
    if (i2c_data_index < (i2c_data_length-1))   
    {
      ClrBit(S1CON,STA);
      ClrBit(S1CON,STO);
      ClrBit(S1CON,AA);
      S1DAT = i2c_buffer[i2c_data_index]; 
      i2c_data_index++; 
      return;
    }

    //send last data byte
    if (i2c_data_index == (i2c_data_length-1))   
    {
      ClrBit(S1CON,STA);
      ClrBit(S1CON,STO);
      ClrBit(S1CON,AA);
      S1DAT = i2c_buffer[i2c_data_length-1];  
      i2c_data_index++; 
      return;
    }

    //send dummy byte to make a stop condition
    if (i2c_data_index > (i2c_data_length-1))   
    {
      ClrBit(S1CON,STA);
      SetBit(S1CON,STO);
      ClrBit(S1CON,AA);
      S1DAT = 0xFF; 
      i2c_state = kMASTER_SEND_END;                
      i2c_data_index++; 
      return;

    }

  }

  //------Master receive operation--------------------------------------------
  if (i2c_state == kMASTER_RECEIVE)
  {
    if (i2c_test_BLOST() == kBUSLOST)
      return;

    if ((i2c_data_index >= 1) && (i2c_data_index <= 2))   
      if (i2c_test_ACKREP() == kNACK)
        return;

    if (i2c_data_index == 1)   
    {
      ClrBit(S1CON,STA);
      ClrBit(S1CON,STO);
      ClrBit(S1CON,AA);
      S1DAT = i2c_buffer[i2c_data_index]; 
      i2c_data_index++; 
      return;
    }

    if (i2c_data_index == 2)   
    {
      SetBit(S1CON,STA);
      ClrBit(S1CON,STO);
      ClrBit(S1CON,AA);
      S1DAT = i2c_buffer[i2c_data_index]; 
      i2c_data_index++; 
      return;
    }

    //i2c_data_index=3..7 for i2c_data_length=3+6
    if ((i2c_data_index >= 3) && (i2c_data_index < (i2c_data_length-1)))   
    {
      ClrBit(S1CON,STA);
      ClrBit(S1CON,STO);
      SetBit(S1CON,AA);
      i2c_buffer[i2c_data_index] = S1DAT;
      i2c_data_index++; 
      return;
    }

    //i2c_data_index=8
    if (i2c_data_index == (i2c_data_length-1))
    {
      ClrBit(S1CON,STA);
      ClrBit(S1CON,STO);
      ClrBit(S1CON,AA);
      i2c_buffer[i2c_data_index] = S1DAT;  
      i2c_data_index++; 
      return;
    }

    //i2c_data_index=9 (last one)
    if (i2c_data_index > (i2c_data_length-1))
    {
      ClrBit(S1CON,STA);
      SetBit(S1CON,STO);
      ClrBit(S1CON,AA);     
      i2c_buffer[i2c_data_index] = S1DAT;  
      i2c_data_index++;     
      i2c_state = kMASTER_RECEIVE_END;
      return;
    }
  } 
  //------
}

//-----------------------------------------------------------------------------
u8 i2c_test_BLOST (void)
{
  u8 u8_dummy;

  if (ValBit(S1STA,BLOST))             // if bus lost, read dummybyte to turn to Slave mode
  {
    u8_dummy = S1DAT;
    i2c_data_index = 0;
    i2c_state = kBUSLOST;            
  }
  return (i2c_state);
}

//-----------------------------------------------------------------------------
u8 i2c_test_ACKREP (void)
{
  if (ValBit(S1STA,ACK_REP))           // if no ACK, send STOP condition to Bus
  {
    ClrBit(S1CON,STA);
    SetBit(S1CON,STO);                 // send stop bit
    ClrBit(S1CON,AA);
    S1DAT = 0;    
    i2c_data_index = 0;              
    i2c_state = kNACK;
  }

  return (i2c_state);
}

//-----------------------------------------------------------------------------
// READ DATA FROM I2C BUFFER
//-----------------------------------------------------------------------------
u8 i2c_read_buffer_u8 (u8 position, u8 *dato)
{
  if ((i2c_state == kMASTER_SEND_END) || (i2c_state == kMASTER_RECEIVE_END))
  {
    position += 4;  
    *dato = (u8)i2c_buffer[position];
    return (TRUE);
  } else 
    return (FALSE);
}

//-----------------------------------------------------------------------------
u8 i2c_read_buffer_u16 (u8 position, u16 *dato, u8 ble)
{
  xdata union16 dato16; //I suppose my micro is using big endian

  if ((i2c_state == kMASTER_SEND_END) || (i2c_state == kMASTER_RECEIVE_END))
  {
    position += 4;  
  
    if (ble == LIS_BLE_LE) //little endian on MEMS
    {
      dato16.bit8[1] = i2c_buffer[position];
      dato16.bit8[0] = i2c_buffer[position+1];
      *dato = dato16.bit16;
      return (TRUE);
    }

    if (ble == LIS_BLE_BE) //big endian on MEMS
    {
      dato16.bit8[0] = i2c_buffer[position];
      dato16.bit8[1] = i2c_buffer[position+1];
      *dato = dato16.bit16;
      return (TRUE);
    }

    *dato = 0;
    return (FALSE);
  } else 
    return (FALSE);
}

//-----------------------------------------------------------------------------
