/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          04/10/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// BOARD
//-----------------------------------------------------------------------------
#include "upsd34xx.h"
#include "board.h"

#if (COMPILER == KEIL)
  #pragma NOAREGS
#endif  

//-----------------------------------------------------------------------------
void uPSD_Init (void)
{
  //I want PB0..PB7 as outputs
  PSD8xx_reg.OUTENABLE_B = 0xFF;
  PSD8xx_reg.CONTROL_B   = 0x00;
  PSD8xx_reg.DIRECTION_B = 0xFF;      
  PSD8xx_reg.DATAOUT_B   = 0x00; 

  //Set Pull-up on PC7 due to the USB on DK3420
  PSD8xx_reg.OUTENABLE_C = 0x80;  //PC7 enable
  PSD8xx_reg.DIRECTION_C = 0x80;  //PC7 OUT, others IN
  PSD8xx_reg.DRIVE_C     = 0x00;  //All Push/Pull (default)
  PSD8xx_reg.DATAOUT_C   = 0x80;  //PC7=1

  //I want all pins as GPIO inputs for the moment
  P1SFS0  = 0;
  P1SFS1  = 0;
  P3SFS   = 0;
  P4SFS0  = 0;
  P4SFS1  = 0;

  //Disable all interrupts, clear all priority
  IE  = 0;
  IEA = 0;
  IP  = 0;
  IPA = 0;

  //Enable following interrupts
  IE_EA = 1;                  // Enable interrupts in general  

  WDTKEY = 0x55;              // Disable watchdog
  //WDTRST = 0;               // Refresh watchdog

  //Set internal pull-ups for buttons
  P1_5 = 1;
  P1_6 = 1;
  P1_7 = 1;
}

//-----------------------------------------------------------------------------
void Time_Delay (const u16 cpu_tics)
{
  u16 i;

  for (i=0; i<cpu_tics; i++)
    double_nop();
}

//-----------------------------------------------------------------------------
void LEDx_toggle (u8 led, u8 required_passes)
{
  static xdata u8 toggle_counter[8] = {0,0,0,0,0,0,0,0};

  toggle_counter[led]++;

  if (toggle_counter[led] >= required_passes)
  {
    if (ValBit(PSD8xx_reg.DATAOUT_B,led))
      ClrBit(PSD8xx_reg.DATAOUT_B,led);
    else
      SetBit(PSD8xx_reg.DATAOUT_B,led);

    toggle_counter[led] = 0;
  }
}

//-----------------------------------------------------------------------------
void TestBoard1 (void)
{
  while (1)
  {
    if (BUT5) {
      LEDx_On(LED5);
    } else {
      LEDx_Off(LED5);
    }

    if (BUT6) {
      LEDx_On(LED6);
    } else {
      LEDx_Off(LED6);
    }

    if (BUT7) {
      LEDx_On(LED7);
    } else {
      LEDx_Off(LED7);
    }
  }

}

//-----------------------------------------------------------------------------
