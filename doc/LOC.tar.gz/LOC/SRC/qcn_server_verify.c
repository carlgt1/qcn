#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM1 86400
#define DIM2 20

void event(float strig[], int ntrig[], int itrig[DIM1][DIM2], int i0, int ntr, int cit[], float sx[], float sy[], float wt[], float ttobs[]);
int fake_trigs(float prob, int nstn, float strig[], int ntrig[], int itrig[DIM1][DIM2], int i0, int ntr, int cit[], float sx[], float sy[], float wt[], float ttobs[], float xx[], float yy[]);
float rand01();

int main ()
{
/* This program simulates the monitoring that we want to do with QCN software. Note that it is all in parallel, so it
 *         does not respond in real time.  But it should be internally consistent and should simulate a day with an
 *         event in it.
 *
 *      1) The code reads in a list of sensor locations (For QCN this will be dynamic as sensor-computers join the
 *         network.
 *
 *      2) It runs through the day (at one second intervals). It assumes a random distribution of spurious triggers, where
 *         each sensor triggers 20 times on average a day.
 *
 *      3) An event with a location specified in (epicenter.xy) will happen at some random point in the day. Note, because
 *         it is random, no event may occure or several.
 *         
 *      4) It will run fake_trigs_all, which creates a set of triggers that will decrease in significance and increase
 *         in time with distance from the earthquake.
 *      
 *      5) The code will continuously monitor for a bunch (10) of triggers simultiously (in a 4 second window). 
 *
 *      6) If a bunch of triggers are observed, it will then run a location program. 
 *
 * Note: Currently this code assumes a flat Earth, but eventually this code should be set
 *         up with spherical distance/travel times. 
 *
 * Note 2: I still need to add in the earthquake magnitude estimation into this. The significance level decrease with 
 *         distance probably needs to be improved. It is currently sl ~ 1/distance, but should probably be sl ~ 1/dis^2.
 *
 */



   float w_long = 720.; float w_short = 4.;                                             /*  Long- & Short-Term Durations   */
   int   n_long = 730 ; int   n_short = 4 ;                                             /*  Long- & Short-Term # of Points */
   float s_long;        float s_short;                                                  /*  Long- & Short-Term Averages    */
   float dt = 1.;                                                                       /*  Sampling Interval              */
   srand( time(NULL) );                                                                 /*  Initialize random seed         */
   int nstn = 1000;                                                                     /*  # of sensors in network        */
   float t_day = 86400.;                                                                /*  Duration of 1 Day in Seconds   */
   int   nt_day = (int)(t_day/dt)+1;                                                    /*  Number of Time Steps in a Day  */
   float avtr_d = 20.;                                                                  /*  Ave # False Triggers/Day/Sensor*/
   float prob = avtr_d / t_day;                                                         /*  Probability of Trigger per sec */
   
   float strig[DIM1]; int ntrig[DIM1];                                                  /*  Weight Sum of Triggers/second  */
   int   itrig[DIM1][DIM2];                                                             /*  Index 4 Trigger @ ith Time Step*/
   
   int   i, j, k, kk;                                                                   /*  Matrix indices                 */
   int   nwarn = 1;                                                                     /*  # of Seconds Since Last Warning*/ 
   int   hr,mn,sc;                                                                      /*  Hour, Min, & Second of Warning */
   char  *cmd = "time ./qcn_server_loc";                                                     /*  Sys Command: Locate Epicenter  */
   
   for (i = 0; i <= nt_day; i++) {                                                      /*  Zero Trigger WeightSum & Count */
      strig[i]=0.;                                                                      /*                                 */
      ntrig[i]=0 ;                                                                      /*                                 */
      for (j = 0; j < DIM2; j++) {                                                      /*  Zero Trigger Index (Per Time)  */
         itrig[i][j] = 0;                                                               /*                                 */
      }                                                                                 /*                                 */
   }                                                                                    /*                                 */
   
   float  xx[1000], yy[1000];                                                           /*  Sensor Locations               */
   FILE   *fp2;                                                                         /*  Sensor Locations File          */
   fp2 = fopen("sensor_locs.xy","r");                                                   /*  Open Sensor Locations File     */
   j = 0;                                                                               /*                                 */
   while ( fscanf(fp2,"%f %f",&yy[j],&xx[j]) != EOF ) {                                 /*  Read In Lat & Lon              */
    if (xx[j] < 0.) {xx[j]=xx[j]+360.;};                                                /*  Make Lon from 0 to 360         */
    j = j + 1;                                                                          /*  Count Up                       */
   }                                                                                    /*                                 */
   nstn = j;                                                                            /*  Reset # of Stations            */
   fclose(fp2);                                                                         /*  Close Sensor Locations File    */
        
   int    MX_TRIG = 10000;                                                              /*  Dimmension For Trigger Index   */
   int    ntr = 0; int cit[MX_TRIG];                                                    /*  # of Triggers & Time Index     */
   float  sx[MX_TRIG],sy[MX_TRIG],wt[MX_TRIG],ttobs[MX_TRIG];                           /*  Trigger Lon, Lat, Weight & Time*/
   
   for (i = 0; i < nt_day-1; i++) {                                                       /*  Go Through Day                 */
      fake_trigs(prob,nstn,strig,ntrig,itrig,i,ntr,cit,sx,sy,wt,ttobs,xx,yy);           /*  Simmulate Fake False Triggers  */
      event(strig,ntrig,itrig,i,ntr,cit,sx,sy,wt,ttobs);                                /*  Simulate a False Event         */
      if ( (ntrig[i] > 0)&&(nwarn >= 0) ) {                                                               /*  If No New Trigger Don't Verify */
         if (i > n_short) {                                                             /*  Kluge: No negatve index numbers*/
           s_short = 0;                                                                 /*  Zero Trigger Count             */
           for (j = i-n_short; j < i; j++) {                                            /*  For Short Term Window (STW):   */
               s_short=s_short+ntrig[j];                                                /*     Count Triggers In STW       */
            };                                                                          /*                                 */
            
            if (s_short > 10.) {                                                        /*     Many Triggers!Issue Warning!*/            
               nwarn = -n_long;
               hr =   (int)   (  ((float)i)/60./60.);                                   /*     Hour of Day: Warning        */  
               mn =   (int)  (( (((float)i)/60./60.) - hr)*60.);                        /*     Minute of Hour: Warning     */
               sc =   (int) ((( (((float)i)/60./60.) - hr)*60 - mn)*60);                /*     Second of Minute: Warning   */
               printf("Warning: %d %d %d \n", hr, mn, sc);                                 /*     Issue Warning!!!!           */
               fp2 = fopen("triggers.xywt","w");                                        /*     Output Triggers to File     */
               
               for (j = i-n_short; j < i; j++) {                                         /*     For Short Term Window       */
                  if ( ntrig[j] > 0 ) {                                                 /*     Go Through Indexed Triggers */
                     for (k = 0; k <= ntrig[j]; k++) {
                        kk = itrig[j][k];                                               /*     Index of Trigger            */
                        fprintf(fp2,"%f %f %f %f \n",sx[kk],sy[kk],wt[kk],ttobs[kk]);   /*     Output Indexed Trigger      */
                     }                                                                  /*                                 */
                  }                                                                     /*                                 */
               };                                                                       /*                                 */
               
               fclose(fp2);                                                             /*      Close Output Trigger File  */
               system(cmd);                                                             /*  Run Epicenter Location Program!*/
            }                                                                           /*                                 */
         }                                                                              /*                                 */
      } else {
          nwarn = nwarn + 1;                                                            /*  Count Since Last Trigger       */
      }                                                                                 /*                                 */
   }
}


void event(float strig[], int ntrig[], int itrig[DIM1][DIM2], int i0, int ntr, int cit[], float sx[], float sy[], float wt[], float ttobs[])
{
   float t_day = 86400.;                                                                /*  Duration of 1 Day in Seconds   */
   float dt = 1.;                                                                       /*  Sampling Interval              */
   int   nt_day = (int)(t_day/dt)+1;                                                    /*  Number of Time Steps in a Day  */
   float prob = 1. / t_day;                                                             /*  Probability of an Earthquake   */
   char  *cmd = "./fake_trigs_all";                                                     /*  Sys Command: Create Fake Event */
   int   nstn,it;                                                                       /*  # of Sensors & Time Index      */
   int   hr,mn,sc;                                                                      /*  Hour, Min & Sec of Fake Event  */
   FILE *fpin;                                                                          /*  Trigger Input File             */                                 
   
   if ( rand01() <= prob ) {                                                            /*  If Random Below Probability    */
      system(cmd);                                                                      /*  Create a Fake Set of Triggers  */
      fpin = fopen("triggers.xywt","r");                                                /*  Open Input Trigger File        */

      while (fscanf(fpin,"%f %f %f %f",&sx[ntr],&sy[ntr],&wt[ntr],&ttobs[ntr]) != EOF) {/*  Read All Available Triggers    */

         if (wt[ntr] > 3.) {                                                            /*  Only Considr 99th %ile Triggers*/      
            ntr = ntr + 1;                                                              /*  Add To Total Count Of Triggers */
            it = i0 + (int)ttobs[ntr];                                                  /*  Time Index of Trigger          */
            strig[it] = strig[it] + wt[ntr];                                            /*  Summed Trigger Weight at Time  */
            ntrig[it] = ntrig[it] +  1;                                                 /*  # of Trigger at ith Time       */
            cit[ntr] = it;                                                              /*  Index the Time of each Trigger */
            itrig[it][ntrig[it]] = ntr;                                                 /*  Index of Triggers at Ith Time  */
            ttobs[it] = ttobs[it] + (float)it;                                          /*  from EQ Time to Time of Day    */
         }                                                                              /*                                 */

      }                                                                                 /*                                 */

      fclose(fpin);                                                                     /*  Close Input File               */
      
      hr =   (int)   (  ((float)i0)/60./60.);                                           /*  Output EQ Source Time          */ 
      mn =   (int)  (( (((float)i0)/60./60.) - hr)*60.);                                /*     Minute of Hour: Source      */
      sc =   (int) ((( (((float)i0)/60./60.) - hr)*60 - mn)*60);                        /*     Second of Minute: Source    */
      printf("Event Rupture At: %d %d %d \n", hr, mn, sc);
      printf("# of Triggers: %d \n", ntr);                                              /*                                 */

   }                                                                                    /*                                 */
}                                                                                       /*                                 */


int fake_trigs(float prob, int nstn, float strig[], int ntrig[], int itrig[DIM1][DIM2], int i0, int ntr, int cit[], float sx[], float sy[], float wt[], float ttobs[], float xx[], float yy[])
{
   int i; int im1 = i0-1;                                                               /*  Indexing Variables             */
   for (i = 0; i < nstn; i++) {                                                         /*  For Each Station               */
      if ( rand01() <= prob ) {                                                         /*  Chance A False Trigger         */
         ntr = ntr + 1;                                                                 /*  Chance A False Trigger         */
         wt[ntr] = ( 1. + rand01() ) * 3;                                               /*  Create a random weighting      */
         ttobs[ntr] = (float)ntr;                                                       /*  Time of Trigger                */
         sx[ntr] = xx[i];                                                               /*  Index Sensor Locations (lon)   */
         sy[ntr] = yy[i];                                                               /*                          (lat)  */
         cit[ntr] = im1;                                                                /*  Time Index per Sensor          */
         strig[im1] = strig[im1] + wt[ntr];                                             /*  Sum Weight at Time             */
         ntrig[im1] = ntrig[im1] + 1 ;                                                  /*  # of Triggers at Time          */
         int nm1 = ntrig[im1];                                                          /*  Kludge: For Next Line          */
         itrig[im1][nm1] = ntr;                                                         /*  Index triggers at ith Time     */
      }                                                                                 /*                                 */
   }                                                                                    /*                                 */
   return 0;                                                                            /*                                 */
}                                                                                       /*                                 */


float rand01() {float r0 = rand()/((double)RAND_MAX + 1); return r0;}                   /* Makes Random # From Zero to One */


