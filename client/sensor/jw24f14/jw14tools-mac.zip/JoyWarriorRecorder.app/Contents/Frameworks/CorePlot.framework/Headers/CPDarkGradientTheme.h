#import <Foundation/Foundation.h>
#import "CPXYTheme.h"

@interface CPDarkGradientTheme : CPXYTheme {

}

@end
