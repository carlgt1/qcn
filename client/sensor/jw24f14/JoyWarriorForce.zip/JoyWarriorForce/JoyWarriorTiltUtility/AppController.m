#import "AppController.h"
#import "AppController+Devices.h"
#import "AppController+JWConfig.h"
#import "DiscoverHIDInterface.h"
#import <IOKit/hid/IOHIDLib.h>
#include "math.h"
#import "RecorderThread.h"

#define DENOISE_VALUE_COUNT 16

void JoyWarriorAddedOrRemoved(void *refCon, io_iterator_t iterator)
{
    io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
    }
	[[NSApp delegate] updateDeviceState];
}

@implementation AppController

- (void) dealloc
{
	[self setXAxis: nil];
    [self setXAxisDegrees: nil];
    [self setXAxisPercent: nil];
    [self setYAxis: nil];
    [self setYAxisDegrees: nil];
    [self setYAxisPercent: nil];
    [self setZAxis: nil];
    
    [noisyX release]; noisyX = nil;
    [noisyY release]; noisyY = nil;
	
    [super dealloc];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{	
    noisyX = [[NSMutableArray arrayWithCapacity:DENOISE_VALUE_COUNT] retain];
    noisyY = [[NSMutableArray arrayWithCapacity:DENOISE_VALUE_COUNT] retain];
	
    AddUSBDeviceAddedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	
	AddUSBDeviceAddedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	
	[self updateDeviceState];
}



- (BOOL) deviceConnected
{
	
    return deviceConnected;
}

- (void) setDeviceConnected: (BOOL) flag
{
	deviceConnected = flag;
}

- (void) addDataForX:(SInt16) inX y:(SInt16) inY z:(SInt16) inZ
{
    // NSLog(@"> %s -- x: %i y: %i z: %i", _cmd, inX, inY, inZ);
	@synchronized(self)
	{
        lastX = inX;
        lastY = inY;
        lastZ = inZ;
        [self rememberValuesForNoiseReductionX:inX Y:inY];
	}
}

- (void) updateDeviceState
{
	CFArrayRef interfaces;
	
	interfaces = (CFArrayRef)[self discoverInterfaces];
	[self setDeviceConnected:(nil != interfaces) && (CFArrayGetCount (interfaces) >= 2)];
	if (deviceConnected)
	{
		NSArray                     *deviceProperties;
		CFNumberRef					interfaceRef;
			
		interfaceRef =	CFArrayGetValueAtIndex(interfaces,1);
		CFNumberGetValue(interfaceRef,kCFNumberLongType,&interface);
		
		deviceProperties = [self discoverDeviceProperties];
		
		if ( [deviceProperties count] )
		{
			NSDictionary	  *properties = [deviceProperties objectAtIndex: 0];
			[deviceTypeField setStringValue:[ properties valueForKey:@"Product"]]; 
			NSLog(@"properties: %@", [ properties valueForKey:@"Product"]);
			[deviceSerialField setStringValue:[ properties valueForKey:@"SerialNumber"]];
            ProductID = [[properties valueForKey:@"ProductID"] intValue];
		}
		
        // F8
        //      Range:  2 (-> 0)
        //   Bandwith: 25 (-> 0)
        // F14
        //      Range:  1 (-> 0)
        //   Bandwith: 10 (-> 0)
        [self switchJoyWarriorAtInterface:interface withProductID:ProductID toRange:0 andBandwidth:0];

		CFNumberRef readInterfaceRef =	CFArrayGetValueAtIndex(interfaces,0);
        IOHIDDeviceInterface122**	readInterface;
		CFNumberGetValue(readInterfaceRef,kCFNumberLongType,&readInterface);

        RecorderThread	*newRecorderThread;
        newRecorderThread = [RecorderThread startedRecorderThreadForInterface:readInterface
                                                                    productID:ProductID
                                                                     interval:0.008f
                                                                     document:self
                                                                        range:1];  // not used in recorder thread ATM
        [self setRecorderThread:newRecorderThread];
        
		readTimer = [NSTimer scheduledTimerWithTimeInterval:0.2
													 target:self
												   selector:@selector (displayAxisValuesTimed:)
												   userInfo:nil
													repeats:YES];
    }
	else
	{
		interface = 0;
		
		[readTimer invalidate];
		readTimer = nil;
		
		[deviceSerialField setStringValue:@""];
		[deviceTypeField setStringValue:@""];

        [[self recorderThread] stopRecording];
		[self setRecorderThread:nil];
	}
}

- (void) rememberValuesForNoiseReductionX:(SInt16)x Y:(SInt16)y;
{
    [noisyX addObject:[NSNumber numberWithShort:x]];
    [noisyY addObject:[NSNumber numberWithShort:y]];
    
    if ([noisyX count] > DENOISE_VALUE_COUNT) {
        [noisyX removeObjectsInRange:NSMakeRange(0, [noisyX count]-DENOISE_VALUE_COUNT)];
    }
    if ([noisyY count] > DENOISE_VALUE_COUNT) {
        [noisyY removeObjectsInRange:NSMakeRange(0, [noisyY count]-DENOISE_VALUE_COUNT)];
    }
}

- (NSNumber *) medianForArray:(NSArray *)numberArray;
{
    int count = [numberArray count];
    NSNumber *median = [[numberArray sortedArrayUsingSelector:@selector(compare:)] objectAtIndex:(count/2)];

    return median;
}

- (SInt16) denoisedX;
{
    NSNumber  *median = [self medianForArray:noisyX];
    // NSNumber *average = [noisyX valueForKeyPath:@"@avg.self"];
    // NSLog(@"X: median: %@ -- average: %@", median, average);
    return [median shortValue];
}

- (SInt16) denoisedY;
{
    NSNumber  *median = [self medianForArray:noisyY];
    return [median shortValue];
}

- (void) displayAxisValuesTimed:(NSTimer*) inTimer
{
    // NSLog(@"> %s", _cmd);
	if (!interface)
        return;
    
    double xDegrees = 0, yDegrees = 0, xPercentage = 0, yPercentage = 0;
    
    SInt16 denoisedX = [self denoisedX];
    SInt16 denoisedY = [self denoisedY];
    
    xDegrees = [self calculateAxisDegrees:denoisedX];
    yDegrees = [self calculateAxisDegrees:denoisedY];
    
    xPercentage = [self caclculateAxisPercent:denoisedX];
    yPercentage = [self caclculateAxisPercent:denoisedY];

    [self setXAxis:[NSString stringWithFormat:@"%d", lastX]];
    [self setXAxisDegrees:[NSString stringWithFormat:@"%.2f°", xDegrees]];
    [self setXAxisPercent:[NSString stringWithFormat:@"%.2f%", xPercentage]];
    
    [self setYAxis:[NSString stringWithFormat:@"%d", lastY]];
    [self setYAxisDegrees:[NSString stringWithFormat:@"%.2f°", yDegrees]];
    [self setYAxisPercent:[NSString stringWithFormat:@"%.2f%", yPercentage]];

    [self setZAxis:[NSString stringWithFormat:@"%d", lastZ]];
}

- (double) caclculateAxisPercent:(SInt16) inAxisValue 
{
	UInt16	limitValue;
	double	sin;
	double	value = inAxisValue;
	
    if ( ProductID == 0x1116 )
        limitValue = MAX(ABS(inAxisValue), 8192);
    else
        limitValue = MAX(ABS(inAxisValue), 256);
    
	sin = value / limitValue;

    return 100.0 * sin;
	//return 100.0 * tan (asin (sin));
}

- (double) calculateAxisDegrees:(SInt16) inAxisValue
{
    UInt16	limitValue;
	double	sine;
	double	value = inAxisValue;
	//bool	limit = true;
	double  degrees;
	
    if ( ProductID == 0x1116 )
        limitValue = MAX(ABS(inAxisValue), 8192);
    else
        limitValue = MAX(ABS(inAxisValue), 256);

	sine = value / limitValue;
	
	//if (value > limitValue)
	//	limit = false;
	
	//*outPercentage = 100.0 * tan (asin (sin));
	//*outDegrees = degrees = asin (sin) * 180/M_PI;
	
	degrees = asin (sine) * 180.0/M_PI;
    
    return degrees;
}

- (double) calculateAxisDegreesX: (double) x Y:(double) y
{
    //a² + b² = c² (Satz des Phytagoras)
    
    double c;
    double erg;
    
    c = sqrt((x*x) + (y*y));
    
    erg = asin(c) * 180.0 / M_PI;
    
    return erg;
}

- (NSString *) xAxis
{
    return xAxis; 
}

- (void) setXAxis: (NSString *) inXAxis
{
    if (xAxis != inXAxis) {
        [xAxis autorelease];
        xAxis = [inXAxis retain];
    }
}


- (NSString *) xAxisDegrees
{
    return xAxisDegrees; 
}

- (void) setXAxisDegrees: (NSString *) inXAxisDegrees
{
    if (xAxisDegrees != inXAxisDegrees) {
        [xAxisDegrees autorelease];
        xAxisDegrees = [inXAxisDegrees retain];
    }
}


- (NSString *) xAxisPercent
{
    return xAxisPercent; 
}

- (void) setXAxisPercent: (NSString *) inXAxisPercent
{
    if (xAxisPercent != inXAxisPercent) {
        [xAxisPercent autorelease];
        xAxisPercent = [inXAxisPercent retain];
    }
}


- (NSString *) yAxis
{
    return yAxis; 
}

- (void) setYAxis: (NSString *) inYAxis
{
    if (yAxis != inYAxis) {
        [yAxis autorelease];
        yAxis = [inYAxis retain];
    }
}


- (NSString *) yAxisDegrees
{
    return yAxisDegrees; 
}

- (void) setYAxisDegrees: (NSString *) inYAxisDegrees
{
    if (yAxisDegrees != inYAxisDegrees) {
        [yAxisDegrees autorelease];
        yAxisDegrees = [inYAxisDegrees retain];
    }
}


- (NSString *) yAxisPercent
{
    return yAxisPercent; 
}

- (void) setYAxisPercent: (NSString *) inYAxisPercent
{
    if (yAxisPercent != inYAxisPercent) {
        [yAxisPercent autorelease];
        yAxisPercent = [inYAxisPercent retain];
    }
}


- (NSString *) zAxis
{
    return zAxis; 
}

- (void) setZAxis: (NSString *) inZAxis
{
    if (zAxis != inZAxis) {
        [zAxis autorelease];
        zAxis = [inZAxis retain];
    }
}

- (RecorderThread *) recorderThread
{
    return recorderThread; 
}

- (void) setRecorderThread: (RecorderThread *) inRecorderThread
{
    if (recorderThread != inRecorderThread) {
        [recorderThread autorelease];
        recorderThread = [inRecorderThread retain];
    }
}

@end
