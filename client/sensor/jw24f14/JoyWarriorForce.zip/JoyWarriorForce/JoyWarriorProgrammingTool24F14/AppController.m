//
//  AppController.m
//  JoyWarriorProgrammingTool24F14
//
//  Created by Erasmus Schröder on 5/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"
#import "AppController+Devices.h"
#import "DiscoverHIDInterface.h"
#import <IOKit/hid/IOHIDLib.h>
#import "JoyWarrior24F14.h"

#include <unistd.h>

void JoyWarriorAddedOrRemoved(void *refCon, io_iterator_t iterator)
{
    io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
    }
	[[NSApp delegate] updateDeviceState];
}

@implementation AppController

- (void) dealloc
{	
	[statusFieldContent release];
	[imageContent release];
    [super dealloc];
}

// can't use -discoverInterfaces , as that would also return non JoyWarrior24F14 devices (e.g. JoyWarrior24F8)
- (NSArray *) discoverInterfacesForJW24F14;
{
    return [self discoverInterfacesWithDeviceID: 0x1116];
}
// can't use -discoverDeviceProperties , as that would also return non JoyWarrior24F14 devices (e.g. JoyWarrior24F8)
- (NSArray *) discoverDevicePropertiesForJW24F14;
{
    return [self discoverDevicePropertiesWithDeviceID: 0x1116];
}


- (BOOL) deviceConnected
{
	
    return deviceConnected;
}

- (void) setDeviceConnected: (BOOL) flag
{
	deviceConnected = flag;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{	
	AddUSBDeviceAddedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	
	[self updateDeviceState];
}

// A device was plugged in or removed
- (void) updateDeviceState
{	
	[deviceSerialField removeAllItems];
	
    if ( interfaces )
        [interfaces release];
	interfaces = [[self discoverInterfacesForJW24F14] retain];
	[self setDeviceConnected:(nil != interfaces) && ( [interfaces count] >= 2)];
	if (deviceConnected)
	{
		NSArray *deviceProperties;
		CFNumberRef					interfaceRef;
		
        int i = 1;
        //NSLog(@"count: %d", [interfaces count]);
        
        for ( i = 0; i < [interfaces count]; i+=2 )
        {
            
            
            deviceProperties = [self discoverDevicePropertiesForJW24F14];
            
            if ( [deviceProperties count] )
            {
                CFDictionaryRef	  properties = (CFDictionaryRef)[deviceProperties objectAtIndex: i];
                [deviceSerialField addItemWithTitle:[(NSDictionary*) properties valueForKey:@"SerialNumber"]];
            }
        }
        
        interfaceRef =	(CFNumberRef)[interfaces objectAtIndex: 1];
        CFNumberGetValue(interfaceRef,kCFNumberLongType,&interface);
        
        [deviceSerialField selectItemAtIndex:0];
        
        [saveButton setEnabled:TRUE];
        [statusUpdateButton setEnabled:TRUE];
        
        // Get values from sensor
        UInt8 temp;
        JWEnableCommandMode24F14 (interface);
        
        // Open 
        JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
        usleep(50000);
        temp &= 0xEF;
        temp |= 0x10;
        JWWriteByteToAddress24F14 (interface, 0x0D, temp);
        usleep(50000);
        
        // Read Bandwidth & Compensation
        JWReadByteFromAddress24F14 (interface, 0x20, &temp);
        usleep(50000);
        [deviceBandwidthField selectItemAtIndex:(temp & 0xF0) >> 4];
        [deviceCompensationField selectItemAtIndex:(temp & 0x0F)];
        
        // Read Range
        JWReadByteFromAddress24F14 (interface, 0x35, &temp);
        usleep(50000);
        temp &= 0x0E;
        [deviceRangeField selectItemAtIndex:(temp >> 1)];
        
        // Read customer specific byte 1
        JWReadByteFromAddress24F14 (interface, 0x2c, &temp);
        usleep(50000);
        [customerSpecificByte1Field setStringValue:[NSString stringWithFormat:@"%x", temp] ];
        
        // Read customer specific byte 2
        JWReadByteFromAddress24F14 (interface, 0x2d, &temp);
        usleep(50000);
        [customerSpecificByte2Field setStringValue:[NSString stringWithFormat:@"%x", temp] ];
        
        // Close Image
        JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
        usleep(50000);
        temp &= 0xEF;
        JWWriteByteToAddress24F14 (interface, 0x0D, temp);
        usleep(50000);
        
        JWDisableCommandMode24F14(interface);
	}
	else
	{
		interface = 0;
		[deviceSerialField addItemWithTitle:@"Not connected"];
		[saveButton setEnabled:FALSE];
		[statusUpdateButton setEnabled:FALSE];
	}
}

- (IBAction)setDeviceSerial:(id) sender
{
    CFNumberRef					interfaceRef;
    
    interfaceRef =	(CFNumberRef)[interfaces objectAtIndex: ([deviceSerialField indexOfSelectedItem]*2)+1];
    CFNumberGetValue(interfaceRef,kCFNumberLongType,&interface);
    
    //NSLog(@"chosen interface: %d", ([deviceSerialField indexOfSelectedItem]*2)+1);
}

// Save settings to image or EEPROM
- (IBAction) saveButtonClicked:(id) sender
{
	UInt8       temp;
	int         range		 = 0,
                bandwidth	 = 0,
                compensation = 0;
	NSScanner   *theScanner;
    
	[saveProgressIndicator startAnimation:sender];
	
	range			= [deviceRangeField indexOfSelectedItem];
	bandwidth		= [deviceBandwidthField indexOfSelectedItem];
	compensation	= [deviceCompensationField indexOfSelectedItem];
	
    JWEnableCommandMode24F14 (interface);
    
	// Open 
	JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
	usleep(50000);
	temp &= 0xEF;
	temp |= 0x10;
	JWWriteByteToAddress24F14 (interface, 0x0D, temp);
	usleep(50000);
	
	// Write Bandwidth & Compensation
	JWReadByteFromAddress24F14 (interface, 0x20, &temp);
	usleep(50000);
	temp &= 0x00;
	temp |= (bandwidth<<4);
	temp |= compensation;
	JWWriteByteToAddress24F14 (interface, 0x20, temp);
	usleep(50000);
	
	// Write Range
	JWReadByteFromAddress24F14 (interface, 0x35, &temp);
	usleep(50000);
	temp &= 0xF1;
	temp |= (range<<1);
	JWWriteByteToAddress24F14 (interface, 0x35, temp);
	usleep(50000);
	
	// Write customer specific byte 1
    theScanner = [NSScanner scannerWithString:[customerSpecificByte1Field stringValue]]; 
    int value;
    [theScanner scanHexInt:(unsigned int*)&value];
    temp = value;
	JWWriteByteToAddress24F14 (interface, 0x2c, value);
	usleep(50000);
	
	// Write customer specific byte 2
    theScanner = [NSScanner scannerWithString:[customerSpecificByte2Field stringValue]]; 
    [theScanner scanHexInt:(unsigned int*)&value];
    temp = value;
	JWWriteByteToAddress24F14 (interface, 0x2d, temp);
	usleep(50000);
	
	// Are we going to save to EEPROM or Image only?
	if ( [saveImageOrEEPROMField indexOfSelectedItem] == 0 )
	{
		// Close Image
		JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
		usleep(50000);
		temp &= 0xEF;
		JWWriteByteToAddress24F14 (interface, 0x0D, temp);
		usleep(50000);
	}
	else {
		// Save changes to EEPROM by touching the registers we want to change
		JWWriteByteToAddress24F14 (interface, 0x40 & 0xFE, 0);
		usleep(50000);
		JWWriteByteToAddress24F14 (interface, 0x55 & 0xFE, 0);
		usleep(50000);
		
		// Soft-reset (save EEPROM-state)
		JWWriteByteToAddress24F14 (interface, 0x10, 0xB6);
		usleep(50000);
	}
    
    JWDisableCommandMode24F14 (interface);

	[saveProgressIndicator stopAnimation:sender];
}

// Initialize the statusFieldContent array with the status register names
- (NSArray *)statusFieldContent
{
	if (nil == statusFieldContent)
	{
		NSBundle *b = [NSBundle mainBundle];
		NSString *path;
		NSArray  *statusFieldNames;
		
		path = [b pathForResource:@"StatusFields" ofType:@"plist"];
		NSAssert (path, @"couldnt load StatusFields.plist");
		
		statusFieldNames = [NSArray arrayWithContentsOfFile:path];
		
		statusFieldContent = [[NSMutableArray alloc] init];
		
		NSEnumerator *e = [statusFieldNames objectEnumerator];
		NSDictionary *dict;
		
		while (nil != (dict = [ e nextObject]))
		{
			NSMutableDictionary *mutableDict = [NSMutableDictionary dictionaryWithDictionary: dict];
			[mutableDict setObject:@"0" forKey:@"value"];
			[statusFieldContent addObject:mutableDict];
		}
	}
	return statusFieldContent;
}

// Refresh status registers
- (IBAction) statusUpdateClicked:(id) sender
{
	int					i = 0, j = 0;
	UInt8				bytes[4];
	NSEnumerator		*e = [statusFieldContent objectEnumerator];
	NSMutableDictionary *dict;
	
    JWEnableCommandMode24F14 (interface);
    
	JWReadByteFromAddress24F14 (interface, 0x09, &bytes[3]);
	JWReadByteFromAddress24F14 (interface, 0x0A, &bytes[2]);
	JWReadByteFromAddress24F14 (interface, 0x0B, &bytes[1]);
	JWReadByteFromAddress24F14 (interface, 0x0C, &bytes[0]);
	
    JWDisableCommandMode24F14(interface);
    
	while (nil != (dict = [ e nextObject]))
	{
		int status = bytes[j] & (1 << i++);
		[dict setObject:(status>0 ? @"1":@"0") forKey:@"value"];
		if ( i > 7 ) { i=0; j++; };
	}
	
	[statusTable reloadData];
}

// Put images into the img column of the status table
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex
{
	if ( aTableView == statusTable )
	{
		if ( [[aTableColumn identifier] isEqualToString:@"img"] ) {
			if ( [[statusFieldContent objectAtIndex:rowIndex] valueForKey:@"value"] == @"1" )
				return [NSImage imageNamed:@"AddItemSuccess.png"];
			return [NSImage imageNamed:@"AddItemSuccessGray.png"];
		}
	}
	return nil;
}

- (IBAction) showImageWindow:(id) sender
{
	if ( interface != 0 )
	{
		NSArray *im = [self retrieveImageContent];
		[self setImageContent:im];
	}
	
	[imageWindow makeKeyAndOrderFront:NSApp];
}

- (IBAction) doSoftReset:(id) sender
{
	JWEnableCommandMode24F14 (interface);
    
    // Soft-reset 
    JWWriteByteToAddress24F14 (interface, 0x10, 0xB6);
    usleep(50000);
    
    JWDisableCommandMode24F14(interface);
}

// Read contents of all registers into an array of dictionaries
- (NSArray*) retrieveImageContent
{
	NSMutableArray  *result;
	int				i  = 0;
	UInt8			val;
	NSBundle		*b;
	NSString		*path;
	NSArray			*registerNames;
	
	result = [NSMutableArray array];
	
	b = [NSBundle mainBundle];
	
	path = [b pathForResource:@"ImageRegisters" ofType:@"plist"];
	NSAssert (path, @"couldnt load ImageRegisters.plist");
	
	registerNames = [NSArray arrayWithContentsOfFile:path];
	
	NSEnumerator *e = [registerNames objectEnumerator];
	NSDictionary *dict;
	JWEnableCommandMode24F14(interface);
	while (nil != (dict = [ e nextObject]))
	{
		NSMutableDictionary *mutableDict = [NSMutableDictionary dictionaryWithDictionary: dict];
		
		[mutableDict setObject:[NSString stringWithFormat:@"%02xh",i] forKey:@"num"];
		
		JWReadByteFromAddress24F14 (interface, i, &val);
		[mutableDict setObject:[NSString stringWithFormat:@"%02xh", val] forKey:@"value"];
		
		[result addObject:mutableDict];
		
		i++;
	}
    JWDisableCommandMode24F14(interface);
	return result;
}

- (void)setImageContent:(NSArray *)inImageContent
{
	[imageContent autorelease];
	imageContent = [inImageContent retain];
}

- (NSArray *)imageContent
{
	return imageContent;
}
@end
