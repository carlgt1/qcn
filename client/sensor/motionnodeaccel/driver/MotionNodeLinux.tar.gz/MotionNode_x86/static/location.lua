--
-- Return an string XML description of the current location of
-- the MotionNode system.
--
-- @file    static/location.lua
-- @author  Luke Tokheim, luke@motionnode.com
-- @version 1.2
--

local result =
  "<?xml version=\"1.0\"?>" ..
  "<geocode version=\"1.0\">"

local preference = node.system.get_preference()
if preference then
  result = result ..
    "<location active=\"1\">" ..
    "<address>" ..
    node.xml.encode_string(preference.address_canonical) ..
    "</address>" ..
    "<point>" ..
    "<latitude>" ..
    node.xml.encode_string(preference.latitude) ..
    "</latitude>" ..
    "<longitude>" ..
    node.xml.encode_string(preference.longitude) ..
    "</longitude>" ..
    "<elevation unit=\"meter\">" ..
    node.xml.encode_string(preference.elevation) ..
    "</elevation>" ..
    "</point>" ..
    "</location>"
end

result = result .. "</geocode>"

return result
