//
//  RecorderThread.h
//  JoyWarriorRecorder
//
//  Created by ilja on 02.08.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class IOHIDDeviceInterface122;

@interface RecorderThread : NSObject {

	id                          document;
	IOHIDDeviceInterface122**	interface;
	int                         productID;
	NSTimeInterval				interval;
	
	long                        x_axis_cookie;
    long                        y_axis_cookie;
    long                        z_axis_cookie;
	
	int							range;
	
	BOOL recording;
}

+ (id) startedRecorderThreadForInterface:(IOHIDDeviceInterface122**) interface productID:(int) inProductID interval:(NSTimeInterval) inTimeInterval document:(id) inDocument range:(int) inRange;

- (id) document;
- (void) setDocument: (id) inDocument;

- (IOHIDDeviceInterface122* *) interface;
- (void) setInterface: (IOHIDDeviceInterface122* *) inInterface;

- (int) productID;
- (void) setProductID: (int) inProductID;

- (NSTimeInterval) interval;
- (void) setInterval: (NSTimeInterval) inInterval;

- (void) stopRecording;
- (void) startRecording;

- (void) readCookiesForCurrentInterface;

- (int) range;
- (void) setRange: (int) inRange;

- (void) normalizeValuesX:(SInt16 *)x y:(SInt16 *)y z:(SInt16 *)z;
- (void) normalizeValuesForProduct:(int)inProductID x:(SInt16 *)x y:(SInt16 *)y z:(SInt16 *)z;

@end
