-------------------------------------------------------------------------------

                 MotionNode Software Development Kit (SDK)

-------------------------------------------------------------------------------
                     Version 1.0, January 31, 2007
                        Updated April 1, 2008
                  http://www.motionnode.com/tools/sdk/
-------------------------------------------------------------------------------

1. Introduction

The MotionNode SDK is a collection of classes that provides real-time access to
the output of the MotionNode system. This includes orientation output as well
as the raw and calibrated sensor signals. The SDK is open source and available
in the C++, C#, Java, and Python programming languages.

The SDK is not required to access data from MotionNode system. It is intended
to simplify development of third-party applications.


2. Components

2.1 Client

Opens a client connection to a MotionNode real-time data service. This is
simply a TCP socket connection with a binary message protocol. The Client class
implements data streaming over the socket connection and the message protocol.

Use the Format class to interpret the binary message.

2.2 File

Opens a binary data file from a MotionNode take. Read a single sample at a time
into an array of typed elements. Analagous to reading data over a real-time
Client connection, but only for a single MotionNode device.

Use the Format class to interpret the array of typed elements.

2.3 Format

Wrap a binary message from Client or an array of typed elements from File in an
object representation of that message or array. For example, the Preview data
service provides the current global orientation as a quaternion. The
Format::PreviewElement class implements a getQuaternion() method that returns
this quaternion.

2.4 LuaConsole

Send arbitrary Lua chunks to the MotionNode console service and get the printed
output. A client application can control all aspects of the MotionNode system
through the Lua scripting interface.


3. Platforms

3.1 C++

3.1.1 Windows

The SDK is designed for use with Microsoft Visual Studio 2005 (MSVC8). We do
not support older versions.

Use the "cpp/build/build.sln" solution to build the static library
"libMotionNodeSDK.lib" and test/example projects.

3.1.2 Linux

We tested the GCC compiler versions 3.4, 4.0, and 4.1.

Use the "cpp/build/Makefile" build the static library "libMotionNodeSDK.a" and
test/example files.

3.1.3 Borland CodeGear C++

We tested the SDK with the CodeGear C++Builder 2007. We do not support older
versions.

Use the "cpp/build/build.groupproj" project to build the static library
and test/example project.

3.2 C#

We tested the SDK with Microsoft Visual Studio 2005 (MSVC8). We do not support
older versions.

Use the "cs/MotionNodeSDK.sln" solution to build the "MotionNodeSDK.dll"
assembly and test/example project.

3.3 Java

The SDK was developed on the Java SE 6 platform, with the 1.5 compiler. We do
not support older versions.

Use the "java/build/build.bat" script on Windows and the "java/build/Makefile"
on Linux to build the "MotionNodeSDK.jar" class archive.

3.4 Python

We tested the SDK with Python versions 2.4 and 2.5.

Use the included "python/setup.py" script to install the "MotionNodeSDK"
module in your Python site-packages directory.


4. License

(C) Copyright GLI Interactive LLC 2008. All rights reserved.

The coded instructions, statements, computer programs, and/or related material
(collectively the "Data") in these files contain unpublished information
proprietary to GLI Interactive LLC, which is protected by US federal copyright
law and by international treaties.

The Data may not be disclosed or distributed to third parties, in whole or in
part, without the prior written consent of GLI Interactive LLC.

The Data is provided "as is" without express or implied warranty, and with no
claim as to its suitability for any purpose.
