#import <Cocoa/Cocoa.h>

@class IOHIDDeviceInterface122;
@class RecorderThread;

@interface AppController : NSObject /* Specify a superclass (eg: NSObject or NSView) */ {

	BOOL					deviceConnected;
	
	IBOutlet NSTextField	*deviceTypeField;
	IBOutlet NSTextField	*deviceSerialField;
	
	IOHIDDeviceInterface122**	interface;

	NSTimer	*readTimer;
	
	NSString	*xAxis;
	NSString	*xAxisDegrees;
	NSString	*xAxisPercent;
	
	NSString	*yAxis;
	NSString	*yAxisDegrees;
	NSString	*yAxisPercent;
	
	NSString	*zAxis;
    
    int   ProductID;
    
    SInt16	lastX, lastY, lastZ;
    NSMutableArray *noisyX;
    NSMutableArray *noisyY;
    RecorderThread *recorderThread;
}

- (void) updateDeviceState;

- (BOOL) deviceConnected;
- (void) setDeviceConnected: (BOOL) flag;

- (double) calculateAxisDegrees:(SInt16) inAxisValue;
- (double) calculateAxisDegreesX: (double) x Y:(double) y;
- (double) caclculateAxisPercent:(SInt16) inAxisValue;

- (NSString *) xAxis;
- (void) setXAxis: (NSString *) inXAxis;

- (NSString *) xAxisDegrees;
- (void) setXAxisDegrees: (NSString *) inXAxisDegrees;

- (NSString *) xAxisPercent;
- (void) setXAxisPercent: (NSString *) inXAxisPercent;

- (NSString *) yAxis;
- (void) setYAxis: (NSString *) inYAxis;

- (NSString *) yAxisDegrees;
- (void) setYAxisDegrees: (NSString *) inYAxisDegrees;

- (NSString *) yAxisPercent;
- (void) setYAxisPercent: (NSString *) inYAxisPercent;

- (NSString *) zAxis;
- (void) setZAxis: (NSString *) inZAxis;

- (RecorderThread *) recorderThread;
- (void) setRecorderThread: (RecorderThread *) inRecorderThread;
- (void) rememberValuesForNoiseReductionX:(SInt16)x Y:(SInt16)y;

@end
