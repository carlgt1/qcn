#import "AppController.h"
#import "IOWarriorLib.h"
#import "DiscoverHIDInterface.h"
#import "HID_Utilities.h"
#import "Settings.h"

#define kLEDNone	-1
#define kLEDRed		0
#define kLEDYellow	1
#define kLEDGreen	2

void IOWarriorAddedOrRemoved (void *inRefcon)
{
	[[NSApp delegate] updateIOWarriorState];
}

void JoyWarriorAddedOrRemoved (void *refcon,io_iterator_t iterator )
{
	io_service_t            usbDevice;
    
    while (usbDevice = IOIteratorNext(iterator))
    {
        IOObjectRelease(usbDevice);
	}
	[[NSApp delegate] updateJoyWarriorStateWithIterator:iterator];
}


@implementation AppController

- (void) awakeFromNib
{
	[logDrawer setParentWindow:mainWindow];
	[logDrawer setPreferredEdge:NSMaxXEdge];
	[logDrawer open];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	IOWarriorInit();
	IOWarriorSetDeviceCallback(IOWarriorAddedOrRemoved, 0);
	[self updateIOWarriorState];
	
	[self setLastFileName:nil];

	// JoyWarrior 24F8
	AddUSBDeviceAddedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1113, JoyWarriorAddedOrRemoved);
	//MouseWarrior 24F6
	AddUSBDeviceAddedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1114, JoyWarriorAddedOrRemoved);
	// JoyWarrior 24F14
	AddUSBDeviceAddedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	AddUSBDevicRemovedCallback (0x07c0, 0x1116, JoyWarriorAddedOrRemoved);
	
	[self updateJoyWarriorStateWithIterator:0];
}

- (NSArray*) joyWarriorInterfaces
{
	CFMutableArrayRef	interfaces, interfaces2, interfaces3;
	NSArray				*result;

	
	// JoyWarrior 24F8
	interfaces = CreateDiscoverHIDInterfaces (0x07c0, 0x1113);
	// MouseWarrior24F6
	interfaces2 = CreateDiscoverHIDInterfaces (0x07c0, 0x1114);
	// JoyWarrior 24F14
	interfaces3 = CreateDiscoverHIDInterfaces (0x07c0, 0x1116);
	
	CFArrayAppendArray(interfaces, 
					   interfaces2,
					   CFRangeMake(0,CFArrayGetCount (interfaces2)));
	CFArrayAppendArray(interfaces, 
					   interfaces3,
					   CFRangeMake(0,CFArrayGetCount (interfaces3)));
	
	CFRelease (interfaces2);
	CFRelease (interfaces3);
	
	result = [NSArray arrayWithArray:(NSArray*) interfaces];
	CFRelease (interfaces);
	return result;
}

- (NSArray*) joyWarriorInterfaceProperties
{
	CFMutableArrayRef	interfaceProperties, interfaceProperties2, interfaceProperties3;
	NSArray				*result;
	
	// JoyWarrior 24F8
	interfaceProperties = CreateDiscoverHIDDeviceProperties (0x07c0, 0x1113);
	// MouseWarrior24F6
	interfaceProperties2 = CreateDiscoverHIDDeviceProperties (0x07c0, 0x1114);
	// JoyWarrior 24F14
	interfaceProperties3 = CreateDiscoverHIDDeviceProperties (0x07c0, 0x1116);
	
	CFArrayAppendArray(interfaceProperties, 
					   interfaceProperties2,
					   CFRangeMake(0,CFArrayGetCount (interfaceProperties2)));
	
	CFArrayAppendArray(interfaceProperties, 
					   interfaceProperties3,
					   CFRangeMake(0,CFArrayGetCount (interfaceProperties3)));
	
	CFRelease (interfaceProperties2);
	CFRelease (interfaceProperties3);

	result = [NSArray arrayWithArray:(NSArray*) interfaceProperties];
	CFRelease (interfaceProperties);
	return result;
}

- (void) updateJoyWarriorStateWithIterator:(io_iterator_t) iterator
{
	NSArray				*interfaceProperties;
	NSDictionary		*deviceProperties;
	
	[self lightIOWarriorLEDWithColor:kLEDNone];
	
	interfaceProperties = [self joyWarriorInterfaceProperties];

	[self setJoyWarriorConnected: ([interfaceProperties count] >= 2)];
	if (joyWarriorConnected)
	{
		deviceProperties = [interfaceProperties objectAtIndex:1];
		[self setJoyWarriorSerialNumber:[deviceProperties objectForKey:@"SerialNumber"]];
		[self logString:[NSString stringWithFormat:@"Found %@ %@", [deviceProperties objectForKey:@"Product"], [self joyWarriorSerialNumber]]];
	}
	else
	{
		[self setJoyWarriorSerialNumber:@"-"];
		[self setVersionTestState:@""];
		[self setHidTestState:@""];
		[self setSelfTestState:@""];
		[self setHidButtonTestResults:[NSArray array]];
	}
	
	if (joyWarriorConnected && ioWarriorConnected)
	{
		[self performTests];
	}
        
    // Release interfaceProperties (temporary fix for the interfaceProperties leak)
    CFIndex	i = 0;
	CFIndex limit = [interfaceProperties count];
	
	for (i = 0; i < limit; i++)
	{
		IOHIDDeviceInterface122		**interface1;
		NSNumber					*hidInterfaceRef1;
		
		hidInterfaceRef1 = [interfaceProperties objectAtIndex:i];
		CFNumberGetValue((CFNumberRef)hidInterfaceRef1,kCFNumberLongType,&interface1);
		(*interface1)->Release(interface1);
	}
}

- (void) updateIOWarriorState
{
	IOWarriorHIDDeviceInterface	**interface = IOWarriorFirstInterfaceOfType(kIOWarrior24Interface0);
	
	[self setIoWarriorConnected:(interface != nil)];
	if (ioWarriorConnected)
	{
		[self setIoWarriorStateString:@"IOWarrior24 found."];
	}
	else
	{
		[self setIoWarriorStateString:@"IOWarrior24 not found."];
	}
}

- (void) dealloc
{
    [self setIoWarriorStateString: nil];
	[self setJoyWarriorSerialNumber: nil];
    [self setAlVersion: nil];
    [self setMlVersion: nil];
	[self setVersionTestState: nil];
    [self setHidTestState: nil];
    [self setSelfTestState: nil];
	[self setHidButtonTestResults: nil];
	[self setLastFileName: nil];
	[self setWriteSettingsState: nil];

    [super dealloc];
}


- (NSString *) ioWarriorStateString
{
    return ioWarriorStateString; 
}

- (void) setIoWarriorStateString: (NSString *) inIoWarriorStateString
{
    if (ioWarriorStateString != inIoWarriorStateString) {
        [ioWarriorStateString autorelease];
        ioWarriorStateString = [inIoWarriorStateString retain];
    }
}

- (BOOL) ioWarriorConnected
{
    return ioWarriorConnected;
}

- (void) setIoWarriorConnected: (BOOL) flag
{
	ioWarriorConnected = flag;
}


- (BOOL) joyWarriorConnected
{
    return joyWarriorConnected;
}

- (void) setJoyWarriorConnected: (BOOL) flag
{
	joyWarriorConnected = flag;
}

- (NSString *) joyWarriorSerialNumber
{
    return joyWarriorSerialNumber; 
}

- (void) setJoyWarriorSerialNumber: (NSString *) inJoyWarriorSerialNumber
{
    if (joyWarriorSerialNumber != inJoyWarriorSerialNumber) {
        [joyWarriorSerialNumber autorelease];
        joyWarriorSerialNumber = [inJoyWarriorSerialNumber retain];
    }
}

- (void) performTests
{
	BOOL	sensorTest = NO;
	BOOL	hidTest = NO;
	BOOL	selfTest = NO;
	
	[self lightIOWarriorLEDWithColor:kLEDYellow];
	
	if ([self performSensorVersionTest])
	{
		sensorTest = NO;
		[self setVersionTestState:@"Sensor Version Test failed"];
		[self logErrorString:@"Sensor Version Test failed"];
	}
	else
	{
		sensorTest = YES;
		[self setVersionTestState:@"Sensor Version Test succeeded"];
	}
	
	if ([self performHIDTest])
	{
		hidTest = NO;
		[self setHidTestState:@"HID Buttons Test failed"];
		[self logErrorString:@"HID Buttons Test failed"];
	}
	else
	{
		hidTest = YES;
		[self setHidTestState:@"HID Buttons Test succeeded"];
	}
	
	// Check whether it is a JoyWarrior 24F14
	NSArray				*interfaceProperties;
	NSDictionary		*deviceProperties;
	interfaceProperties = [self joyWarriorInterfaceProperties];
	deviceProperties = [interfaceProperties objectAtIndex:1];
	if ([[deviceProperties objectForKey:@"ProductID"] intValue] == 0x1116)
	{
		if ( [self performSelfTestF14] )
			selfTest = YES;
		else
			selfTest = NO;
		 
	}
	else 
	{
		if ([self performSelfTest])
		{
			selfTest = NO;
			[self setSelfTestState:@"Sensor Self-Test failed"];
			[self logWarnString:@"Sensor Self-Test failed"];
		}
		else
		{
			selfTest = YES;
			[self setSelfTestState:@"Sensor Self-Test succeeded"];
		}
	}
    
    // Release interfaceProperties (temporary fix for the interfaceProperties leak)
    CFIndex	i = 0;
	CFIndex limit = [interfaceProperties count];
	
	for (i = 0; i < limit; i++)
	{
		IOHIDDeviceInterface122		**interface1;
		NSNumber					*hidInterfaceRef1;
		
		hidInterfaceRef1 = [interfaceProperties objectAtIndex:i];
		CFNumberGetValue((CFNumberRef)hidInterfaceRef1,kCFNumberLongType,&interface1);
		(*interface1)->Release(interface1);
	}
    
	if (selfTest && hidTest && sensorTest)
	{
		[self logSuccessString:@"All Tests passed"];
		if ([self currentSettings])
		{
			[self writeCurrentSettingsToEEPROM];
			[self setWriteSettingsState:@"Settings written"];
			[self logString:[NSString stringWithFormat:@"Wrote settings %@ to EEPROM", [self lastFileName]]];
		}
		[self lightIOWarriorLEDWithColor:kLEDGreen];
		NSBeep ();
	}
	else
	{
		int i;
		
		[self logErrorString:@"Test failed"];
		[self setWriteSettingsState:@"Settings not written"];
		for (i = 0; i < 3 ; i++)
		{
			NSBeep ();
			[NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.3]];
		}
		[self lightIOWarriorLEDWithColor:kLEDRed];
	}
}

- (int) performSensorVersionTest
{
	NSArray		*interfaces;
	int					err;
	
	[self setAlVersion:@""];
	[self setMlVersion:@""];
	
	interfaces = [self joyWarriorInterfaces];
	if ([interfaces count] >= 2)
	{
		NSNumber					*interface;
		IOHIDDeviceInterface122		**hidInterface;
		UInt8						temp;
		
		interface = [interfaces objectAtIndex:1];
		hidInterface = (IOHIDDeviceInterface122**) [interface longValue];
		
		// read al_version and ml_version
		err = JWReadByteFromAddress (hidInterface, 0x01, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read chip version", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return err;
		}
		[self setAlVersion:[NSString stringWithFormat:@"%d", temp >> 4]]; 
		[self setMlVersion:[NSString stringWithFormat:@"%d", (temp & 0x0F)]];
		if ([[self alVersion] isEqualToString:@"0"] ||
			[[self mlVersion] isEqualToString:@"0"])
		{
			[self logErrorString:[NSString stringWithFormat:@"Chip version is 0 - Communication error ?", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return -1;
		}
	}
	ReleaseInterfaces((CFArrayRef) interfaces);
	
	return 0;
}

- (int) performHIDTest
{
	pRecDevice		testDevice = NULL;
	pRecDevice		theDevice = NULL;
	NSMutableArray	*testResults = [NSMutableArray array];
	
	[self setHidButtonTestResults:[NSArray array]];
	
	HIDBuildDeviceList (kHIDPage_GenericDesktop, kHIDUsage_GD_Joystick);
	
	if (theDevice = HIDGetFirstDevice())
	{		
		do
		{
			if ((theDevice->vendorID == 1984) && (theDevice->productID == 0x1113))
			{
				testDevice = theDevice;
				break;
			}
			if ((theDevice->vendorID == 1984) && (theDevice->productID == 0x1116))
			{
				testDevice = theDevice;
				break;
			}
		}
		while (nil != (theDevice = HIDGetNextDevice (theDevice)));
	}
	if (NULL == testDevice)
	{
		HIDBuildDeviceList (kHIDPage_GenericDesktop, kHIDUsage_GD_Mouse);
		
		if (theDevice = HIDGetFirstDevice())
		{		
			do
			{
				if ((theDevice->vendorID == 1984) && (theDevice->productID == 0x1114))
				{
					testDevice = theDevice;
					break;
				}
			}
			while (nil != (theDevice = HIDGetNextDevice (theDevice)));
		}
	}
	
	if (NULL == testDevice)
	{
		[self logErrorString:@"Couldn't find HID device for testing"];
		return -1;
	}
	
	pRecElement theElement;
	BOOL		gotError = NO;
	
	theElement = HIDGetFirstDeviceElement(testDevice, kHIDElementTypeInput);
	while (theElement)
	{
		if (theElement->type == kIOHIDElementTypeInput_Button)
		{
			long							value;
			long							cookie = (long) theElement->cookie;
			char							buffer[2] = {0xFF, 0xFD};
			IOWarriorHIDDeviceInterface**	ioWarriorInterface = IOWarriorFirstInterfaceOfType(kIOWarrior24Interface0);
			BOOL							errorForThisButton = NO;

			IOWarriorWriteToInterface (ioWarriorInterface, 2, buffer);
			usleep (50000);
			value = HIDGetElementValue(testDevice,theElement);
			if (value != 0)
			{
				[self logErrorString:[NSString stringWithFormat:@"Button %d: Test failed.", cookie]];
				gotError = errorForThisButton = YES;
			}
			// turn off buffer bit for pin that's connected for this button
			buffer[0] = buffer[0] ^ (1 << (cookie - 3));
			
			IOWarriorWriteToInterface (ioWarriorInterface, 2, buffer);
			usleep (50000);
			value = HIDGetElementValue(testDevice,theElement);
			if (value != 1)
			{
				[self logErrorString:[NSString stringWithFormat:@"Button %d: Test failed.", cookie]];
				gotError = errorForThisButton = YES;
			}
			
			// test that all other buttons are actually turned off to catch short cuts
			pRecElement otherElement;
			
			otherElement = HIDGetFirstDeviceElement(testDevice, kHIDElementTypeInput);
			while (otherElement)
			{
				if ((otherElement->type == kIOHIDElementTypeInput_Button) && ((long) otherElement->cookie != cookie))
				{
					if (HIDGetElementValue(testDevice,otherElement) != 0)
					{
						[self logErrorString:[NSString stringWithFormat:@"Buttons %d and %d: Test failed.", cookie, (long) otherElement->cookie]];
						gotError = errorForThisButton = YES;
					}
				}
				otherElement = HIDGetNextDeviceElement(otherElement,kHIDElementTypeInput);
			}
			
			[testResults addObject:[NSDictionary dictionaryWithObjectsAndKeys:
				[NSString stringWithFormat:@"Button %d", cookie - 3], @"button", 
				(errorForThisButton ? @"NOT OK" : @"OK"), @"state", 
				nil]];
		}
		theElement = HIDGetNextDeviceElement(theElement,kHIDElementTypeInput);
	}
	[self setHidButtonTestResults:testResults];
	
	return (gotError ? -1 : 0);
}

- (int) performSelfTestF14
{
	NSArray*			interfaces;
	int					err;
	
	interfaces = [self joyWarriorInterfaces];
	if ([interfaces count] >= 2)
	{
		NSNumber					*interface;
		IOHIDDeviceInterface122		**hidInterface;
		UInt8						temp;
		
		interface = [interfaces objectAtIndex:1];
		hidInterface = (IOHIDDeviceInterface122**) [interface longValue];
				
		// read and verify chip_id
		err = JWReadByteFromAddress24F14(hidInterface, 0x00, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read chip id", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		// the chip id should be 011b (3)
		if ( (temp & 7) != 3 )
		{
			[self logErrorString:[NSString stringWithFormat:@"Chip id: %d (invalid)", temp & 7]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		[self logString:[NSString stringWithFormat:@"Chip id: %d", temp & 7]];
		
		// Set image writeable
		err = JWReadByteFromAddress24F14(hidInterface, 0x0D, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read ee_w (0Dh)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		temp &= 0xEF;
		temp |= 0x10;
		usleep(50000);
		err = JWWriteByteToAddress24F14(hidInterface, 0x0D, temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to write ee_w (0Dh)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		usleep(50000);
		
		// Set range to 2g...
		err = JWReadByteFromAddress24F14(hidInterface, 0x35, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read range (35h)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		[self logString:[NSString stringWithFormat:@"Old range was %d", (temp & 0xE)>>1]];
		temp &= 0xF1;
		temp |= 0x04;
		err = JWWriteByteToAddress24F14(hidInterface, 0x35, temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to write range (35h)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		usleep(10000);
		
		// ...and set bandwidth to 10hz
		err = JWReadByteFromAddress24F14(hidInterface, 0x20, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read bandwidth (20h)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		[self logString:[NSString stringWithFormat:@"Old bandwidth was %d", (temp & 0xF0)>>4]];
		temp &= 0x0F;
		err = JWWriteByteToAddress24F14(hidInterface, 0x20, temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to write bandwidth (20h)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		usleep(10000);
		
		[self logString:@"Writing changes to EEPROM..."];
		
		// Write changes to EEPROM
		err = JWWriteByteToAddress24F14(hidInterface, 0x55 & 0xFE, 0x00);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to write range (55h) to EEPROM", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		usleep(50000);
		
		err = JWWriteByteToAddress24F14(hidInterface, 0x40 & 0xFE, 0x00);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to write bandwidth (40h) to EEPROM", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		usleep(50000);
		
		// Soft-reset
		[self logString:@"Executing soft-reset"];
		err = JWWriteByteToAddress24F14(hidInterface, 0x10, 0xB6);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to write soft_reset (10h)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		
		usleep(50000);
		
		// Set image non-writeable
		err = JWReadByteFromAddress24F14(hidInterface, 0x0D, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read ee_w (0Dh)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		temp &= 0xEF;
		usleep(10000);
		err = JWWriteByteToAddress24F14(hidInterface, 0x0D, temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to write ee_w (0Dh)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		
		usleep(50000);
		
		// Verify range
		err = JWReadByteFromAddress24F14(hidInterface, 0x35, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read range (35h)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		[self logString:[NSString stringWithFormat:@"New range is %d", (temp & 0xE)>>1]];
		if ( (temp & 0xE)>>1 != 2 )
		{
			[self logErrorString:@"Range could not be saved"];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		
		// Verify bandwidth
		err = JWReadByteFromAddress24F14(hidInterface, 0x20, &temp);
		if (err)
		{
			[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to read bandwidth (20h)", err]];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		[self logString:[NSString stringWithFormat:@"New bandwidth is %d", (temp & 0xF0)>>4]];
		if ( (temp & 0xF0)>>4 != 0 )
		{
			[self logErrorString:@"Bandwidth could not be saved"];
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		/*
		// open the interface
		int ioReturnValue = (*hidInterface)->open (hidInterface, 0);
		if (ioReturnValue != kIOReturnSuccess)
		{
			CFShow (CFSTR ("couldn't open interface"));
			ReleaseInterfaces((CFArrayRef) interfaces);
			return 0;
		}
		// free cmd mode
		if (kIOReturnSuccess != ( JWDisableCommandMode24F14 (hidInterface)))
		{
			ReleaseInterfaces((CFArrayRef) interfaces);
            (*hidInterface)->close (hidInterface);
			return 0;
		}
		(*hidInterface)->close (hidInterface);
         */
	}
	ReleaseInterfaces((CFArrayRef) interfaces);
	return 1;
}

- (int) performSelfTest
{
	CFArrayRef	interfaces;
	int					err;
	UInt8				temp = 0;
	int selftest0result = -1;
	int vectortestresult = 0;
	
	interfaces = (CFArrayRef) [self joyWarriorInterfaces];
	if (CFArrayGetCount (interfaces) >= 2)
	{
		CFNumberRef					interfaceRef;
		IOHIDDeviceInterface122		**hidInterface;
		
		interfaceRef = CFArrayGetValueAtIndex(interfaces,1);
		CFNumberGetValue(interfaceRef,kCFNumberLongType,&hidInterface);
		
		
		// SELFTEST 0
		int counter;
		for ( counter = 0; counter < 16; counter++ )
		{
			// 4G and 1500Hz
			err = JWWriteByteToAddress( hidInterface, 0x14, (1 << 3) | (1<<2) | (1<<1));
			if (err)
			{
				[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to set range and bandwidth bits", err]];
				ReleaseInterfaces(interfaces);	
				return err;
			}
			// Set Selftest0 bit
			err = JWWriteByteToAddress( hidInterface, 0x0A, (1 << 2));
			if (err)
			{
				[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to set selftest_0 bit", err]];
				ReleaseInterfaces(interfaces);	
				return err;
			}
			
			usleep (5000);
			
			// Read result
			JWReadByteFromAddress (hidInterface, 0x09, &temp);
			if ( temp & (1 << 7) ) {
				[self logString:[NSString stringWithFormat:@"Self test 0 passed after %d tries.", counter+1]];
				selftest0result = 0;
				
				break;
		    }
			
			// Soft reset
			JWWriteByteToAddress( hidInterface, 0x0A, (1 << 1));
			
			usleep(1000);
		}
		
		if ( counter >= 16 ) {
			[self logWarnString:[NSString stringWithFormat:@"Self test 0 failed!"]];
			selftest0result = -1;
		}
		
		// VECTOR SELFTEST
		//if ( selftest0result == -1 )
		{
			// 4G and 25Hz
			err = JWWriteByteToAddress( hidInterface, 0x14, (1 << 3));
			if (err)
			{
				[self logErrorString:[NSString stringWithFormat:@"Received error %d when trying to set range and bandwidth bits", err]];
				ReleaseInterfaces(interfaces);	
				return err;
			}
			usleep(50000);
			
			// Read x, y and z
			UInt8						rawData[6];
			int							i;
			SInt16						x, y, z;
			int							vector;
			for (i = 0; i < 6; i++)
			{
				JWReadByteFromAddress (hidInterface, 0x02 + i, &rawData[i]);
			}
			
			x = JWMergeAxisBytes(rawData[0], rawData[1]);
			y = JWMergeAxisBytes(rawData[2], rawData[3]);
			z = JWMergeAxisBytes(rawData[4], rawData[5]);
			
			vector = (x*x) + (y*y) + (z*z);
			
			if ( sqrt(vector) >= 70.4 && sqrt(vector) <= 217.6 )
			{
				vectortestresult = 0;
				[self logString:[NSString stringWithFormat:@"Vector test passed (%f)", sqrt(vector)]];
			}
			else {
				vectortestresult = -1;
				[self logWarnString:[NSString stringWithFormat:@"Vector test failed (%f)!", sqrt(vector)]];
			}
		}
	}
	ReleaseInterfaces(interfaces);	
	
	int testresult = 0;
	if ( selftest0result == -1 && vectortestresult == 0 )
		testresult = 0; // Success
	else if ( selftest0result == 0 )
		testresult = 0; // Success
	else if ( selftest0result == -1 && vectortestresult == -1 )
		testresult = -1;
	
	return (testresult);
}

- (NSString *) alVersion
{
    return alVersion; 
}

- (void) setAlVersion: (NSString *) inAlVersion
{
    if (alVersion != inAlVersion) {
        [alVersion autorelease];
        alVersion = [inAlVersion retain];
    }
}


- (NSString *) mlVersion
{
    return mlVersion; 
}

- (void) setMlVersion: (NSString *) inMlVersion
{
    if (mlVersion != inMlVersion) {
        [mlVersion autorelease];
        mlVersion = [inMlVersion retain];
    }
}

- (void) logErrorString:(NSString*) inString
{
	[self addLogString:inString withColor:[NSColor redColor]];
}

- (void) logSuccessString:(NSString*) inString
{
	[self addLogString:inString withColor:[NSColor greenColor]];
}

- (void) logWarnString:(NSString*) inString
{
	[self addLogString:inString withColor:[NSColor colorWithDeviceRed:(float)1 green:(float)170.0/255.0 blue:(float)18.0/255.0 alpha:(float)1.0]];
}

- (void) logString:(NSString*) inString
{
	[self addLogString:inString withColor:[NSColor blackColor]];
}

- (NSString *) versionTestState
{
    return versionTestState; 
}

- (void) setVersionTestState: (NSString *) inVersionTestState
{
    if (versionTestState != inVersionTestState) {
        [versionTestState autorelease];
        versionTestState = [inVersionTestState retain];
    }
}


- (NSString *) hidTestState
{
    return hidTestState; 
}

- (void) setHidTestState: (NSString *) inHidTestState
{
    if (hidTestState != inHidTestState) {
        [hidTestState autorelease];
        hidTestState = [inHidTestState retain];
    }
}


- (NSString *) selfTestState
{
    return selfTestState; 
}

- (void) setSelfTestState: (NSString *) inSelfTestState
{
    if (selfTestState != inSelfTestState) {
        [selfTestState autorelease];
        selfTestState = [inSelfTestState retain];
    }
}

- (NSArray *) hidButtonTestResults
{
    return hidButtonTestResults; 
}

- (void) setHidButtonTestResults: (NSArray *) inHidButtonTestResults
{
    if (hidButtonTestResults != inHidButtonTestResults) {
        [hidButtonTestResults autorelease];
        hidButtonTestResults = [inHidButtonTestResults retain];
    }
}

- (NSString *) lastFileName
{
    return lastFileName; 
}

- (void) setLastFileName: (NSString *) inLastFileName
{
    if (lastFileName != inLastFileName) {
        [lastFileName autorelease];
        lastFileName = [inLastFileName retain];
    }
}


- (IBAction) chooseSettingsFile:(id) sender
{
	NSOpenPanel *openPanel= [NSOpenPanel openPanel];
	
	[openPanel setCanChooseDirectories:NO];
	[openPanel setCanChooseFiles:YES];
	if ([openPanel runModalForDirectory:nil
								   file:nil
								  types:[NSArray arrayWithObject:@"jwSettings"]])
	{
		[self loadSettingsFromFile:[openPanel filename]];
	}	
}

- (void) loadSettingsFromFile:(NSString*) inPath
{
	[self setCurrentSettings:[NSKeyedUnarchiver unarchiveObjectWithFile:inPath]];
	[self setLastFileName:[[NSFileManager defaultManager] displayNameAtPath:inPath]];
}

- (IBAction) clearSettingsFile:(id) sender
{
	[self setCurrentSettings:nil];
	[self setLastFileName:nil];
}

- (Settings *) currentSettings
{
    return currentSettings; 
}

- (void) setCurrentSettings: (Settings *) inCurrentSettings
{
    if (currentSettings != inCurrentSettings) {
        [currentSettings autorelease];
        currentSettings = [inCurrentSettings retain];
		[currentSettings setUseEEPROM:YES]; // we only write to EEPROM in this test tool
    }
}

- (int) writeCurrentSettingsToEEPROM
{
	UInt8						emptyData[11];
	CFNumberRef					hidInterfaceRef;
	IOHIDDeviceInterface122		**hidInterface;
	int							address;
	NSData						*reportData;
	UInt8*						reportDataBytes;
	CFArrayRef					interfaces;
	int							addressOffset = 0;
	
	interfaces = (CFArrayRef) [self joyWarriorInterfaces];
	hidInterfaceRef = CFArrayGetValueAtIndex(interfaces,1);
	CFNumberGetValue(hidInterfaceRef,kCFNumberLongType,&hidInterface);
	
	if ([currentSettings useEEPROM])
	{
		// force eeprom content to be written to image
		JWWriteByteToAddress (hidInterface, 0x0A, 0x20);
	}
	
	bzero (emptyData,sizeof(emptyData));
	// read byte at 0x14 to get value of reserved field
	JWReadByteFromAddress(hidInterface,0x14,&emptyData[9]);
	
	reportData = [[self currentSettings] reportDataWithReadData:[NSData dataWithBytes:emptyData
																			   length:11]];
	
	reportDataBytes =  (UInt8*)[reportData bytes];
	
	if ([currentSettings useEEPROM])
	{
		// unlock eeprom
		JWWriteByteToAddress (hidInterface, 0x0A, 0x10);
	}
	
	if ([currentSettings useEEPROM])
		addressOffset = 0x20;
	
	for (address = 0x0B; address < 0x16; address++)
	{
		
		JWWriteByteToAddress (hidInterface, address + addressOffset, reportDataBytes[address - 0x0B]);
		if ([currentSettings useEEPROM])
			usleep(10000);
	}
	
	if ([currentSettings useEEPROM])
	{
		// force eeprom content to be written to image
		JWWriteByteToAddress (hidInterface, 0x0A, 0x20);
	}
	
	ReleaseInterfaces (interfaces);
	CFRelease (interfaces);
	
	return 0;
}

- (IBAction) runTestAgain:(id) sender
{
	[self performTests];
}

- (NSString *) writeSettingsState
{
    return writeSettingsState; 
}

- (void) setWriteSettingsState: (NSString *) inWriteSettingsState
{
    if (writeSettingsState != inWriteSettingsState) {
        [writeSettingsState autorelease];
        writeSettingsState = [inWriteSettingsState retain];
    }
}

- (void) addLogString:(NSString*) inString withColor:(NSColor*) inColor
{
	inString = [inString stringByAppendingString:@"\n"];
	
	NSMutableAttributedString	*attributedString = [[[NSMutableAttributedString alloc] initWithString:inString] autorelease];
	
	[attributedString addAttributes:[NSDictionary dictionaryWithObject:inColor forKey:NSForegroundColorAttributeName]
							  range:NSMakeRange (0, [attributedString length])];
	[attributedString addAttributes:[NSDictionary dictionaryWithObject:[NSFont systemFontOfSize:12.0] forKey:NSFontAttributeName]
							  range:NSMakeRange (0, [attributedString length])];
	
	[[logTextView textStorage] appendAttributedString:attributedString];
	
	
	[logTextView scrollRangeToVisible:NSMakeRange ([[logTextView textStorage] length] -1, 0)];
}

- (void) lightIOWarriorLEDWithColor:(int) inLEDIdentifier
{
	IOWarriorHIDDeviceInterface**	ioWarriorInterface = IOWarriorFirstInterfaceOfType(kIOWarrior24Interface0);
	char							buffer[2] = {0xFF, 0xFF};

	if (ioWarriorInterface)
	{
		if (inLEDIdentifier != kLEDNone)
		{
			buffer[1] = 0xFF ^ (1 << inLEDIdentifier);
		}
		IOWarriorWriteToInterface (ioWarriorInterface, 2, buffer);
	}
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

@end
