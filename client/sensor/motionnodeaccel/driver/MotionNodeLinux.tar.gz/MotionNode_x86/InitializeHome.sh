#!/bin/sh
#
# Create a directory tree in the current user's HOME
# with the distribution data files. Prepare to run
# the MotionNodeDaemon with the data path set to
# $HOME/MotionNode.
#
# @file    InitializeHome.sh
# @author  Luke Tokheim, luke@motionnode.com
# @version 1.2
#

# Optional command line argument. Default to the HOME
# environment variable.
if [ $# -gt 0 ]; then
  TARGET=$1
elif [ "$MOTIONNODE_HOME" != "" ]; then
  TARGET=$MOTIONNODE_HOME
else
  TARGET=$HOME
fi

echo Creating MotionNode data folder in \"$TARGET\"

INSTALL=/usr/bin/install

$INSTALL -d $TARGET/MotionNode
$INSTALL -d $TARGET/MotionNode/default
$INSTALL -d $TARGET/MotionNode/take
if [ -f database.db-dist ]; then
  $INSTALL --mode=644 --backup database.db-dist $TARGET/MotionNode/default/database.db
fi
