--
-- By default, the MotionNode system runs this script at startup.
--
-- @file    bootstrap.lua
-- @author  Luke Tokheim, luke@motionnode.com
-- @version 1.0
--


--
-- Load the MotionNode public scripting interface Lua module.
--
require("node")

-- Replace the global print function with the
-- node module system.print function. Required.
print = node.system.print

-- Remove the manager instance from the global
-- namespace. All client script calls should go
-- through the node module interface.
manager = nil


--
-- Disable any standard Lua functionality that has general
-- read or write access to the local file system.
--
if true then
  -- Remove global functions that read from the local file
  -- system.
  dofile = nil
  loadfile = nil

  -- Remove global modules that read from the local file system.
  -- IO (Input and Output Facilities) module provides read and
  -- write file access.
  io = nil
  module = nil
  -- OS (Operating System Facilities) module provides file
  -- deletion and execute access.
  os = nil
  package = nil
  require = nil

  -- SQLite database file open.
  if sqlite then
    sqlite.open = nil
  end
end


--
-- Set the file search path. Continue
-- even if this step fails.
--
local search_path = "static"
if node._DEMO then
  search_path = search_path .. ";demo"
end
node.system.set_search_path(search_path)

-- Set the log file name, but do not care if it fails.
-- The initialization step should define the site specific
-- log name.
node.system.log("default/log.xml")


--
-- Execute the external initialization script. If it does not
-- exist, start up the HTTP console service so we can use the
-- web browser UI to create the initialization file.
--
if not node.system.initialize() then
  -- Load the default database file if it is present.
  if node.system.file_exists("default/database.db") then
    node.system.open_database("default/database.db")
  end

  local service = {["http"] = 32080}
  if not node.system.start_services(service) then
    node.system.quit()
  end
  
  -- Load the default location file if it is present.
  if node.system.file_exists("default/location.xml") then
    node.load_location("default/location.xml")
  end
  
  -- If we do not already have a valid location, make
  -- an initial guess based on our local IP address.
  preference = node.system.get_preference()
  if not(preference.valid_location == true) then
    node.system.geocode_address("")
  end
end

--
-- END bootstrap.lua
--
