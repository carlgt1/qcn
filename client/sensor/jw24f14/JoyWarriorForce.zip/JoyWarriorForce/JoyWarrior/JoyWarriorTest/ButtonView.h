//
//  ButtonView.h
//  JoyWarriorTest
//
//  Created by Guido K�rber on 17.09.04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define kButtonStateDisabled	-1
#define kButtonStateUntested	0
#define kButtonStateTested		1
#define kButtonStatePressed		2

@interface ButtonView : NSButton {
	int		buttonState;
	int		lastValue;
	
	IBOutlet NSTextField *lastValueField;
	
}

- (void) resetState;

- (int)buttonState;
- (void)setButtonState:(int)aButtonState;


- (int) lastValue;
- (void) setLastValue: (int) inLastValue;


@end
