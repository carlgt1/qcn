/**
  @file    javascript/RemoteProcedureCall.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/


/**
  Generic asynchronous remote procedure call object.

  Psuedocode class interface:
  \code
  class GLI_RemoteProcedureCall {
  public:
    // Constructor. Intialize XMLHttpRequest object.
    GLI_RemoteProcedureCall();
    // Execute an asynchronous remote procedure call.
    void command(arguments);
    // Execute an asynchronous remote procedure call,
    // send a string command to an interactive console.
    void command_chunk(chunk);
    // Read a remote XML file and call the callback
    // function when it arrives.
    void get_xml(location, xml_callback)
    // Display an error message for the user.
    void error(message);
  };
  \endcode
*/

/**
   Constructor. Initialize the underlying XMLHttpRequest object.
*/
function GLI_RemoteProcedureCall(notify, command_finished)
{
  this.request = null;
  this.id = null;
  this.notify = notify;
  this.callback = command_finished;
  
  if (window.XMLHttpRequest) {
    this.request = new XMLHttpRequest();
  } else if (window.ActiveXObject) {
    this.request = new ActiveXObject("Microsoft.XMLHttp");
  } else {
    throw "failed to instantiate XMLHttpRequest, missing implementation";
  }
}

/**
  Execute an asynchronous remote procedure call. Use the XML-RPC
  schema definition.

  Create the <methodCall> tree from the variable length list of
  arguments. The first argument must be the string valued function
  name, the <methodName> element.
  
  POST the <methodCall> tree to the path '/'. Read the response and
  check for the 'false' return value. If it is false, generate an
  alert box with the error message. Then reload the current document
  to refresh the state based on any command effects.
*/
GLI_RemoteProcedureCall.prototype.command = function(arguments)
{
  if ((null !== this.request) && (arguments.length > 0)) {
    var rpc = this;
    var arg = arguments;
    this.request.onreadystatechange = function()
    {
      if (4 === rpc.request.readyState) {
        if (200 === rpc.request.status) {
          var result = true;
          var message = '';
          {
            // Parse the result tree. This could be more robustly done
            // with a proper XML parser, but a regular expression will
            // get the job done.
            var expression = new RegExp(
              '<methodResponse>'
              + '<params>'
              + '<param><value><boolean>(false|0)</boolean></value></param>'
              + '<param><value><string>([^<]*)</string></value></param>'
              + '</params>'
              + '</methodResponse>');
            
            var matches = rpc.request.responseText.match(expression);
            if (matches) {
              result = false;
              message = matches[2];
            } else {
              expression = new RegExp(
                '<methodResponse><fault><value><struct>'
                + '<member><name>faultCode</name><value><int>([^<]*)</int></value></member>'
                + '<member><name>faultString</name><value><string>([^<]*)</string></value></member>'
                + '</struct></value></fault></methodResponse>');

              matches = rpc.request.responseText.match(expression);   
              if (matches) {
                result = false;
                message = matches[2];
              }
            }
          }
          
          if (rpc.notify) {
            rpc.notify(message);
          }
          
          if (false === result) {
            window.alert(arg[0] + '\n' + message);
          }
          
          if (rpc.callback) {
            rpc.callback(rpc.request.responseText);
          }
          GLI_Monitor.load_state();
          
        } else {
          if (rpc.callback) {
            rpc.callback(rpc.request.statusText);
          }
          rpc.error(rpc.request.statusText);
        }
      }
    }


    // Implements the XML structure of the procedure call.
    var xml = null;
    if (document.implementation && document.implementation.createDocument) {
      xml = document.implementation.createDocument('', '', null);
    } else if (window.ActiveXObject) {
      xml = new ActiveXObject('Microsoft.XMLDOM');
    } else {
      throw "failed to instantiate XMLDocument, missing implementation";
    }

    if (null !== xml) {
      var methodCall = xml.createElement('methodCall');
      xml.appendChild(methodCall);
      
      {
        var methodName = xml.createElement('methodName');
        methodCall.appendChild(methodName);
        {
          var text = xml.createTextNode(arguments[0].toString());
          methodName.appendChild(text);
        }
      } // </methodName>

      {
        var params = xml.createElement('params');
        methodCall.appendChild(params);
        
        for (var i=1; i<arguments.length; i++) {
          var param_type = typeof arguments[i];
          if (('string' == param_type) || ('number' == param_type)) {
            var param = xml.createElement('param');
            params.appendChild(param);
            {
              var value = xml.createElement('value');
              param.appendChild(value);
              {
                var type =  xml.createElement(param_type);
                value.appendChild(type);
                {                 
                  var text = xml.createTextNode(arguments[i].toString());
                  type.appendChild(text);
                }
              }
            }
          }
        }
      } // </params>


      // Now execute the actual remote procedure call. Use the POST method.
      this.request.open('POST', '/', true);
      this.request.send(xml);

      if (this.notify) {
        this.notify('Sending command...');
      } 
    }
  
  } else {
    if (this.callback) {
      this.callback("");
    } 
  }
}

/**
  Execute an asynchronous remote procedure call. Use the
  custom <lua_chunk> XML tree. Intended as a direct input
  to and output from the Lua scripting system. Models an
  interactive console over an asynchronous request.
*/
GLI_RemoteProcedureCall.prototype.command_chunk = function(chunk)
{
  if ((null !== this.request) && (chunk.length > 0)) {
    var rpc = this;
    var arg = arguments;
    this.request.onreadystatechange = function()
    {
      if (4 === rpc.request.readyState) {
        if (200 === rpc.request.status) {
          var result = false;
          var message = '';
          {
            // Parse the result tree. This could be more robustly done
            // with a proper XML parser, but a regular expression will
            // get the job done.
            var expression = new RegExp(
              '<lua_print result="([^<"]+)" version="1.0">([^<]*)</lua_print>');
            
            var matches = rpc.request.responseText.match(expression);
            if (matches) {
              result = true;
              message = matches[2];
            }
          }
          
          if (false === result) {
          }
          
          if (rpc.callback) {
            rpc.callback(message);
          }
          
        } else {
          if (rpc.callback) {
            rpc.callback(rpc.request.statusText);
          }
          rpc.error(rpc.request.statusText);
        }
      }
    }


    // Implements the XML structure of the procedure call.
    var xml = null;
    if (document.implementation && document.implementation.createDocument) {
      xml = document.implementation.createDocument('', '', null);
    } else if (window.ActiveXObject) {
      xml = new ActiveXObject('Microsoft.XMLDOM');
    } else {
      throw "failed to instantiate XMLDocument, missing implementation";
    }

    if (null !== xml) {
      var lua_chunk = xml.createElement('lua_chunk');
      lua_chunk.setAttribute('version', '1.0');
      xml.appendChild(lua_chunk);
      
      {
        var text = xml.createTextNode(chunk.toString());
        lua_chunk.appendChild(text);
      }

      // Now execute the actual remote procedure call. Use the POST method.
      this.request.open('POST', '/', true);
      this.request.send(xml);
      
      if (this.notify) {
        this.notify('Sending chunk...');
      }
    }
  
  } else {
    if (this.callback) {
      this.callback('');
    } 
  }
}

/**
  Execute an asynchronous XML file read. GET the requested location
  and call the input callback function 'xml_callback' with the string
  valued response, i.e. the XML file contents.
*/
GLI_RemoteProcedureCall.prototype.get_xml = function(location, xml_callback)
{
  if (null !== this.request) {
    var rpc = this; 
    this.request.onreadystatechange = function()
    {
      if (4 === rpc.request.readyState) {
        if (200 === rpc.request.status) {
          xml_callback(rpc.request.responseText, rpc.request.responseXML);
        } else {
          if (rpc.callback) {
            rpc.callback(rpc.request.statusText, rpc.request.responseXML);
          }
          rpc.error(rpc.request.statusText);
        }
      }
    }

    this.request.open('GET', location, true);
    this.request.send(null);
  } 
}

/**
  Display an error message for the user.
*/
GLI_RemoteProcedureCall.prototype.error = function(message)
{
  if (this.notify) {
    this.notify(message.toString());
  }
  
  if (null !== this.request) {
    this.request.abort();
    this.request = null;
  }
}

// END class GLI_RemoteProcedureCall
