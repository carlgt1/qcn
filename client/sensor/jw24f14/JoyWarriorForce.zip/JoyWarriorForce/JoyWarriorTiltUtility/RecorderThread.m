//
//  RecorderThread.m
//  JoyWarriorRecorder
//
//  Created by ilja on 02.08.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RecorderThread.h"

#include <IOKit/IOKitLib.h>
#include <IOKit/hid/IOHIDLib.h>
#include <IOKit/hid/IOHIDUsageTables.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>



@implementation RecorderThread

+ (id) startedRecorderThreadForInterface:(IOHIDDeviceInterface122**) interface 
							   productID:(int) inProductID 
								interval:(NSTimeInterval) inTimeInterval 
								document:(id) inDocument
								   range:(int) inRange
{
	RecorderThread *result;
	
	result = [[[RecorderThread alloc] init] autorelease];
	
	[result setDocument:inDocument];
	[result setInterval:inTimeInterval];
	[result setProductID:inProductID];
	[result setInterface:interface];
	[result setRange:inRange];
	
	[result startRecording];
	
	return result;
}

- (void) startRecording
{
	if (YES == recording)
	{
		return;
	}
	recording = YES;
	[NSThread detachNewThreadSelector:@selector(recordThreaded:)
							 toTarget:self
						   withObject:nil];
}

- (void) stopRecording
{
	recording = NO;
}

- (void) normalizeValuesX:(SInt16 *)x y:(SInt16 *)y z:(SInt16 *)z;
{
    [self normalizeValuesForProduct:productID x:x y:y z:z];
}

// was: - (void) normalizeValuesForProduct:(NSInteger)inProductID toRange:(NSRange)inRange x:(SInt16 *)x y:(SInt16 *)y z:(SInt16 *)z;
// range normalization now happens in MyDocument+CorePlot's method: -number:forProductID:normalizedForPlot:
- (void) normalizeValuesForProduct:(int)inProductID x:(SInt16 *)x y:(SInt16 *)y z:(SInt16 *)z;
{
    NSParameterAssert(inProductID);
    NSParameterAssert(x);
    NSParameterAssert(y);
    NSParameterAssert(z);

    short resolutionBits;
    switch (inProductID) {
        case 0x1116:		// JW24 F14
            resolutionBits = 14;
            break;
        case 0x1113:		// JW24 F8
            resolutionBits = 10;
            break;
        default:			// ?!
            NSLog(@"WARNING: unknown product -- productID: %i", productID);
            return;
            break;
    }
    
    int offset = (1 << (resolutionBits - 1)) - 1;
    *x -= offset;
    *y -= offset;
    *z -= offset;
}

- (void) recordThreaded:(id) ignored
{
	NSDate				*lastRecordTime = nil;
	NSAutoreleasePool	*pool = [[NSAutoreleasePool alloc] init];
	
	if (kIOReturnSuccess != (*interface)->open (interface, 0))
	{
		recording = NO;
		return;
	}
	[self readCookiesForCurrentInterface];
	while (recording)
	{
		IOHIDEventStruct	values;
		SInt16				x=0, y=0, z=0;
		NSDate				*currentDate;
		NSTimeInterval		nextInterval;
        NSDate              *nextDate;
		
        @try {
            if (kIOReturnSuccess == (*interface)->getElementValue(interface, (IOHIDElementCookie)x_axis_cookie, &values) )
            {
                x = values.value;
            }
            if (kIOReturnSuccess == (*interface)->getElementValue(interface, (IOHIDElementCookie)y_axis_cookie, &values) )
            {
                y = values.value;
            }
            if (kIOReturnSuccess == (*interface)->getElementValue(interface, (IOHIDElementCookie)z_axis_cookie, &values) )
            {
                z = values.value;
            }
            // NSLog(@" recording:  x: %i y: %i z: %i", x, y, z);
            [self normalizeValuesX:&x y:&y z:&z];
            // NSLog(@"normalized:  x: %i y: %i z: %i", x, y, z);
            
            [document addDataForX:x y:y z:z];
        }
        @catch (NSException * e) {
            NSLog(@"WARNING: got exception while reading data: %@", e);
        }
        @finally {
            currentDate = [NSDate date];
            nextInterval = interval;
            if (lastRecordTime)
            {
                nextInterval =  interval - [currentDate timeIntervalSinceDate:lastRecordTime];
                lastRecordTime = currentDate;
            }
            
            // [NSThread sleepForTimeInterval:nextInterval];
            nextDate = [[[NSDate alloc] initWithTimeInterval:nextInterval sinceDate:currentDate] autorelease];
            [NSThread sleepUntilDate:nextDate];
        }
	}
	[pool drain];
}

- (void) dealloc
{
    [self setDocument: nil];
    [self setInterface: nil];
	
    [super dealloc];
}



- (id) document
{
    return document; 
}

- (void) setDocument: (id) inDocument
{
    if (document != inDocument) {
        [document autorelease];
        document = [inDocument retain];
    }
}


- (IOHIDDeviceInterface122**) interface
{
    return interface; 
}

- (void) setInterface: (IOHIDDeviceInterface122**) inInterface
{
	interface = inInterface;
}


- (int) productID
{
    return productID;
}

- (void) setProductID: (int) inProductID
{
	productID = inProductID;
}


- (NSTimeInterval) interval
{
    return interval;
}

- (void) setInterval: (NSTimeInterval) inInterval
{
	interval = inInterval;
}

- (void) readCookiesForCurrentInterface
{
	CFArrayRef  elements;

	if ( kIOReturnSuccess == (*interface)->copyMatchingElements(interface, NULL, &elements) )
	{
		CFIndex i;
		
		for (i = 0; i < CFArrayGetCount(elements); i++) 
		{
			CFDictionaryRef element;
			CFTypeRef       object;
			long            number;
			long            cookie;
			long            usagePage;
			long            usage;
			
			element = CFArrayGetValueAtIndex(elements, i);
			
			object = (CFDictionaryGetValue(element, CFSTR(kIOHIDElementCookieKey)));
			if (object == 0 || CFGetTypeID(object) != CFNumberGetTypeID()) 
			{
				continue;
			}
			if (!CFNumberGetValue((CFNumberRef) object, kCFNumberLongType, &number)) 
			{
				continue;
			}
			cookie = number;
			
			object = (CFDictionaryGetValue(element, CFSTR(kIOHIDElementUsagePageKey)));
			if (object == 0 || CFGetTypeID(object) != CFNumberGetTypeID()) 
			{
				continue;
			}
			if (!CFNumberGetValue((CFNumberRef) object, kCFNumberLongType,&number)) 
			{
				continue;
			}
			usagePage = number;
			
			object = (CFDictionaryGetValue(element, CFSTR(kIOHIDElementUsageKey)));
			if (object == 0 || CFGetTypeID(object) != CFNumberGetTypeID()) 
			{
				continue;
			}
			if (!CFNumberGetValue((CFNumberRef) object, kCFNumberLongType,&number)) 
			{
				continue;
			}
			usage = number;
			
			if ( usagePage == kHIDPage_GenericDesktop )
			{
				if ( usage == kHIDUsage_GD_X ) 
				{
					x_axis_cookie = cookie;
				}
				else if ( usage == kHIDUsage_GD_Y ) 
				{
					y_axis_cookie = cookie;
				}
				else if ( usage == kHIDUsage_GD_Z ) 
				{
					z_axis_cookie = cookie;
				}
			}
		}
	}
}


- (int) range
{
    return range;
}

- (void) setRange: (int) inRange
{
	range = inRange;
}

@end
