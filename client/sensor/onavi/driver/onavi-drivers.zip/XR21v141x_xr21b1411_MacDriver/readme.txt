XR21v141x and XR21b1411 Mac river:

This driver has been tested on Mac OS X - Version 10.5.8.

Driver Installation:
Use an utility like �Kext Helper� to install ExarUSBCDCACM.kext or follow the manual steps given below.

Install 1: Use "Kext Helper"
http://cheetha.net/
Note: You do not have to restart the system.

Install 2: 
Manual Installation:
Copy �ExarUSBCDCACM.kext� to �/Syste/Library/Extensions� with root privileges
-        Open a terminal window and type
o        sudo cp �R /Users/yourusername/Desktop/ExarUSBCDCACM.kext /System/Library/Extensions
o        (Provide the root password in case it was not given earlier)


Once either one of the above driver installation is over, connect Exar�s USB eval board to any of the USB ports in the system.

The driver will automatically load and the ports will be enumerated. (For the device callout names, please check /dev folder. Exar ports will have �xrusbmodem****� string in them.) You can test the usb-uarts using any of the serial port testing applications.