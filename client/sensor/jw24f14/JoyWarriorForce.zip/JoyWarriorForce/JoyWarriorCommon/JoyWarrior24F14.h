/*
 *  JoyWarrior24F8.h
 *  JoyWarrior Programmingtool
 *
 *  Created by ilja on 03.11.07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <IOKit/hid/IOHIDLib.h>

int JWDisableCommandMode24F14 (IOHIDDeviceInterface122 **hidInterface);
int JWEnableCommandMode24F14 (IOHIDDeviceInterface122 **hidInterface);

int JWReadByteFromAddress24F14 (IOHIDDeviceInterface122 **hidInterface, UInt8 inAddress, UInt8 *result);
int JWWriteByteToAddress24F14 (IOHIDDeviceInterface122 **hidInterface, UInt8 inAddress, UInt8 inData);

SInt16 JWMergeAxisBytes24F14 (UInt8 inLSB, UInt8 inMSB);
SInt16 JWMergeOffsetBytes24F14 (UInt8 inLSB, UInt8 inMSB);

void JWDiffMsbLsb24F14 (UInt16 value, UInt8 *inLSB, UInt8 *inMSB);
