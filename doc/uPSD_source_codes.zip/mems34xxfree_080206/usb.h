/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Petr Pfeifer & Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// USB
//-----------------------------------------------------------------------------
#ifndef USB_H
#define USB_H

#include "upsd34xx.h"
#include "board.h"

//-----------------------------------------------------------------------------
// USB structures and types
//-----------------------------------------------------------------------------
// iword - Intel word structure
typedef struct
{
  u8 lo;
  u8 hi;
} iword;

//-----------------------------------------------------------------------------
// USB device descriptor

typedef struct
{
  uchar bLength;                             // Size of this Descriptor in Bytes
  uchar bDescriptorType;                     // Descriptor Type (=1)
  iword bcdUSB;                              // USB Spec Release Number in BCD
  uchar bDeviceClass;                        // Device Class Code
  uchar bDeviceSubClass;                     // Device Subclass Code
  uchar bDeviceProtocol;                     // Device Protocol Code
  uchar bMaxPacketSize0;                     // Maximum Packet Size for EP0
  iword idVendor;                            // Vendor ID
  iword idProduct;                           // Product ID
  iword bcdDevice;                           // Device Release Number in BCD
  uchar iManufacturer;                       // Index of String Desc for Manufacturer
  uchar iProduct;                            // Index of String Desc for Product
  uchar iSerialNumber;                       // Index of String Desc for SerNo
  uchar bNumConfigurations;                  // Number of possible Configurations
} t_device_descriptor;

//-----------------------------------------------------------------------------
// USB configuration descriptor

typedef struct
{
  uchar bLength;                             // Size of this Descriptor in Bytes
  uchar bDescriptorType;                     // Descriptor Type (=2)
  iword wTotalLength;                        // Total Length of Data for this Conf
  uchar bNumInterfaces;                      // No of Interfaces supported by this Conf
  uchar bConfigurationValue;                 // Designator Value for *this* Configuration
  uchar iConfiguration;                      // Index of String Desc for this Conf
  uchar bmAttributes;                        // Configuration Characteristics (see below)
  uchar bMaxPower;                           // Max. Power Consumption in this Conf (*2mA)
} t_configuration_descriptor;

//-----------------------------------------------------------------------------
// USB interface descriptor

typedef struct
{
  uchar bLength;                             // Size of this Descriptor in Bytes
  uchar bDescriptorType;                     // Descriptor Type (=4)
  uchar bInterfaceNumber;                    // Number of *this* Interface (0..)
  uchar bAlternateSetting;                   // Alternative for this Interface (if any)
  uchar bNumEndpoints;                       // No of EPs used by this IF (excl. EP0)
  uchar bInterfaceClass;                     // Interface Class Code
  uchar bInterfaceSubClass;                  // Interface Subclass Code
  uchar bInterfaceProtocol;                  // Interface Protocol Code
  uchar iInterface;                          // Index of String Desc for this Interface
} t_interface_descriptor;

//-----------------------------------------------------------------------------
// USB endpoint descriptor

typedef struct
{
  uchar bLength;                             // Size of this Descriptor in Bytes
  uchar bDescriptorType;                     // Descriptor Type (=5)
  uchar bEndpointAddress;                    // Endpoint Address (Number + Direction)
  uchar bmAttributes;                        // Endpoint Attributes (Transfer Type)
  iword wMaxPacketSize;                      // Max. Endpoint Packet Size
  uchar bInterval;                           // Polling Interval (Interrupt) in ms
} t_endpoint_descriptor;

//-----------------------------------------------------------------------------
// USB SETUP packet

typedef struct
{
  uchar bmRequestType;                       // Characteristics (Direction,Type,Recipient)
  uchar bRequest;                            // Standard Request Code
  iword wValue;                              // Value Field
  iword wIndex;                              // Index or Offset Field
  iword wLength;                             // Number of Bytes to transfer (Data Stage)
} t_setup_buffer;

//-----------------------------------------------------------------------------
// USB defines
//-----------------------------------------------------------------------------
// Your FIFO sizes
#define EP0_PKT_SIZE 64
#define EP1_PKT_SIZE 64
#define EP2_PKT_SIZE 64
#define EP3_PKT_SIZE 64

//-----------------------------------------------------------------------------
#define EP1_ADDR (0x81)

//-----------------------------------------------------------------------------
// USB Status Codes
#define US_ATTACHED       0x00
#define US_POWERED        0x01
#define US_DEFAULT        0x02
#define US_ADDRESSED      0x03
#define US_CONFIGURED     0x04
#define US_SUSPENDED      0x10

//-----------------------------------------------------------------------------
// EP state
#define US_EPDEFAULT      0x00
#define US_EPSTALL        0x01

//-----------------------------------------------------------------------------
// USB Standard Device Request Codes. [1] p. 251
#define GET_STATUS        0x00
#define CLEAR_FEATURE     0x01
#define SET_FEATURE       0x03
#define SET_ADDRESS       0x05
#define GET_DESCRIPTOR    0x06
#define SET_DESCRIPTOR    0x07               // optional
#define GET_CONFIGURATION 0x08
#define SET_CONFIGURATION 0x09
#define GET_INTERFACE     0x0A
#define SET_INTERFACE     0x0B
#define SYNCH_FRAME       0x0C               // optional

//-----------------------------------------------------------------------------
// SETUP packet request types
#define CLASS_INTERFACE_TO_DEVICE   0x21
#define CLASS_INTERFACE_TO_HOST     0xA1

//-----------------------------------------------------------------------------
// HID class specific requests
#define HID_GET_REPORT    0x01
#define HID_GET_IDLE      0x02
#define HID_SET_REPORT    0x09
#define HID_SET_IDLE      0x0A
#define REQUEST_COMPLETE  0xff                // not part of the Standard - just
                                              // a Flag to indicate that the recent
                                              // request has been finished

//-----------------------------------------------------------------------------
// Descriptor Types
#define DT_DEVICE        1
#define DT_CONFIGURATION 2
#define DT_STRING        3
#define DT_INTERFACE     4
#define DT_ENDPOINT      5
#define DT_HID_CLASS     0x21
#define DT_HID_REPORT    0x22
#define DT_HID_PHYSICALD 0x23

//-----------------------------------------------------------------------------
#define EP_ATTR_CONTROL     (0x0)
#define EP_ATTR_ISOCHRONOUS (0x1)
#define EP_ATTR_BULK        (0x2)
#define EP_ATTR_INTERRUPT   (0x3)

//-----------------------------------------------------------------------------
#define EnRemoteWakeup      (0x20)
#define DisRemoteWakeup     (0x00)

//-----------------------------------------------------------------------------
//PLLM & PLLD configuration
//-----------------------------------------------------------------------------
//40MHz, PLLM=22, PLLD=8
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0x68

//33MHz, PLLM=30, PLLD=9
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0xE9

//30MHz, PLLM=14, PLLD=3
//#define CCON0_VALUE 0x70
//#define CCON1_VALUE 0xE3

//24MHz, PLLM=18, PLLD=3
#define CCON0_VALUE 0xE0
#define CCON1_VALUE 0x23

//20MHz, PLLM=22, PLLD=3
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0x63

//16MHz, PLLM=28, PLLD=3
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0xC3

//12MHz, PLLM=18, PLLD=2
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0xE2

//6MHz, PLLM=18, PLLD=0
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0xE0

//3MHz, PLLM=18, PLLD=-1
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0xEF

//3MHz, PLLM=18, PLLD=-1
//#define CCON0_VALUE 0xE0
//#define CCON1_VALUE 0xEF

//-----------------------------------------------------------------------------
#define REQ_DATA0  10
#define REQ_DATA1  11
#define REQ_TOGGLE 12

//-----------------------------------------------------------------------------
//in_state
#define PCK_READY     11
#define PCK_SEND_DATA 22
#define PCK_SEND_ZP   33

//-----------------------------------------------------------------------------
//usb_mode
#define USB_INICIALIZATING 11
#define USB_INICIALIZED    22

//-----------------------------------------------------------------------------
// Provided USB functions
//-----------------------------------------------------------------------------
void OnUsbReset (void);
void UsbInitialize (void);
void OnUsbSuspend (void);
void OnUsbResume (void);
BOOL ReadSetupPacket (u8 *packet);
void OnSetupPacket (void);
void STALL_EPx (u8 your_ep);
void IN_EPx (u8 *tx_buffer, u8 tx_size, u8 your_ep, u8 req_data);
void OUT_EPx (u8 your_ep, u8 req_data);
void OnGetStatus (void);
void OnClearFeature (void);
void OnSetFeature (void);
void OnSetAddress (void);
void OnGetDescriptor (void);
void OnSetDescriptor (void);
void OnGetConfiguration (void);
void OnSetConfiguration (void);
void OnGetInterface (void);
void OnSetInterface (void);
void SetAddress (void);
void Set_EP0OUT_DATA0 (void);

void USB_Send_MEMS_Data (t_out16 *xyz);
void USB_Send_Frame1 (u16 sample_rate, t_mems_regs *mems_regs);
void USB_Send_Frame2 (t_mems_data *mems_data);

//-----------------------------------------------------------------------------
#endif
