
#import <Foundation/Foundation.h>


@interface CPDecimalNumberValueTransformer : NSValueTransformer {

}

@end
