/* AppController */

#import <Cocoa/Cocoa.h>

@class Settings;

@interface AppController : NSObject
{
	Settings				*currentSettings;
	
	NSAttributedString		*bitString;	
	
	IBOutlet NSWindow		*bitStringWindow;
	IBOutlet NSTextField	*deviceTypeField;
	IBOutlet NSTextField	*deviceSerialField;
	
	BOOL	deviceConnected;
	
	NSString	*lastFileName;
	
	NSArray	*registerCheckStati;
	
	// colors for device status bits
	NSColor	*selfTestColor;
	NSColor	*highGColor;
	NSColor *lowGColor;
	NSColor *hgLatchedColor;
	NSColor	*lgLatchedColor;
	NSColor *alertPhaseColor;
	
	BOOL colorWellEnabledState;
}

- (IBAction)readSettings:(id)sender;
- (IBAction)writeSettings:(id)sender;

- (IBAction) save:(id) sender;
- (IBAction) saveAs:(id) sender;
- (IBAction) open:(id) sender;

- (IBAction) anyMotionMatrixClicked:(id) sender;

- (BOOL) saveSettings;

- (Settings *) currentSettings;
- (void) setCurrentSettings: (Settings *) inCurrentSettings;

- (NSDictionary*) fieldsDictionary;

- (void) registerForSettingsKeyChange:(Settings*) inSettings;
- (void) unregisterForSettingsKeyChange:(Settings*) inSettings;

- (NSAttributedString *) bitString;
- (void) setBitString: (NSAttributedString *) inBitString;

- (BOOL) checkForJoyWarrior;

- (void) updateDeviceState;

- (BOOL) deviceConnected;
- (void) setDeviceConnected: (BOOL) flag;

- (NSString *) lastFileName;
- (void) setLastFileName: (NSString *) inLastFileName;

- (NSArray *) registerCheckStati;
- (void) setRegisterCheckStati: (NSArray *) inRegisterCheckStati;

- (void) updateRegisterStatiWithReadData:(NSData*) inReadData expectedData:(NSData*) inExpectedData;

- (NSColor *) selfTestColor;
- (void) setSelfTestColor: (NSColor *) inSelfTestColor;

- (NSColor *) highGColor;
- (void) setHighGColor: (NSColor *) inHighGColor;

- (NSColor *) lowGColor;
- (void) setLowGColor: (NSColor *) inLowGColor;

- (NSColor *) hgLatchedColor;
- (void) setHgLatchedColor: (NSColor *) inHgLatchedColor;

- (NSColor *) lgLatchedColor;
- (void) setLgLatchedColor: (NSColor *) inLgLatchedColor;

- (NSColor *) alertPhaseColor;
- (void) setAlertPhaseColor: (NSColor *) inAlertPhaseColor;

- (BOOL) colorWellEnabledState;
- (void) setColorWellEnabledState: (BOOL) flag;

- (void) resetColorWells;


@end
