#!/bin/sh

cd JoyWarriorRecorder
xcodebuild clean
xcodebuild build -target JoyWarriorRecorder -configuration Release
cd ..
cd JoyWarriorProgrammingTool24F14
xcodebuild clean
xcodebuild build -target JoyWarriorProgrammingTool24F14 -configuration Release
cd ..
cd JoyWarriorCalibrationTool
xcodebuild clean
xcodebuild build -configuration Release
cd ..
cd JoyWarriorTiltUtility
xcodebuild clean
xcodebuild build -configuration Release
cd ..


BUILD_DIR_NAME=JoyWarriorForceTools
BUILD_DIR_PATH=./$BUILD_DIR_NAME
rm -rf $BUILD_DIR_PATH
mkdir $BUILD_DIR_PATH
CpMac -r JoyWarriorRecorder/build/Release/JoyWarriorRecorder.app $BUILD_DIR_PATH/JoyWarriorRecorder.app
CpMac -r JoyWarriorProgrammingTool24F14/build/Release/JoyWarriorProgrammingTool24F14.app $BUILD_DIR_PATH/JoyWarriorProgrammingTool24F14.app
CpMac -r JoyWarriorCalibrationTool/build/Release/JoyWarrior\ Calibration\ Tool.app $BUILD_DIR_PATH/JoyWarriorCalibrationTool.app
CpMac -r JoyWarriorTiltUtility/build/Release/JoyWarrior\ Tilt\ Utility.app $BUILD_DIR_PATH/JoyWarriorTiltUtility.app


SOURCE_DIR=$BUILD_DIR_PATH/source
mkdir $SOURCE_DIR

CpMac -r JoyWarriorCommon $SOURCE_DIR

CpMac -r JoyWarriorTiltUtility $SOURCE_DIR
cd ${SOURCE_DIR}/JoyWarriorTiltUtility
rm -rf build/
cd -

zip -r ${BUILD_DIR_NAME}_`date "+%Y-%m-%d"`.zip $BUILD_DIR_NAME
