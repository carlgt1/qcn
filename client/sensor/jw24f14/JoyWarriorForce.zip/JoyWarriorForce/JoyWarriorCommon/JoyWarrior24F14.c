/*
 *  JoyWarrior24F8.c
 *  JoyWarrior Programmingtool
 *
 *  Created by ilja on 03.11.07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include "JoyWarrior24F14.h"


#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/hid/IOHIDLib.h>
#include <IOKit/IOCFPlugIn.h>
extern void NSLog(CFStringRef format, ...); 

int JWDisableCommandMode24F14 (IOHIDDeviceInterface122 **hidInterface)
{
	UInt8	writeBuffer[8];
	int     ioReturnValue;
	
    // open the interface
	ioReturnValue = (*hidInterface)->open (hidInterface, 0);
    if (ioReturnValue != kIOReturnSuccess)
	{
		CFShow (CFSTR ("couldn't open interface"));
		return ioReturnValue;
	}
    
	bzero (writeBuffer, sizeof (writeBuffer));
	writeBuffer[0] = 0x00;
    
	ioReturnValue = (*hidInterface)->setReport (hidInterface, kIOHIDReportTypeOutput, 0, writeBuffer, sizeof(writeBuffer), 50, NULL, NULL, NULL);
    if (ioReturnValue != kIOReturnSuccess)
    {
       	CFShow (CFSTR ("Could not write setReport on hid device interface"));
    }
    
    ioReturnValue = (*hidInterface)->close (hidInterface);
    
	return ioReturnValue;
}


int JWEnableCommandMode24F14 (IOHIDDeviceInterface122 **hidInterface)
{
	UInt8	writeBuffer[8];
	int     ioReturnValue;
	
    // open the interface
	ioReturnValue = (*hidInterface)->open (hidInterface, 0);
    if (ioReturnValue != kIOReturnSuccess)
	{
		CFShow (CFSTR ("couldn't open interface"));
		return ioReturnValue;
	}
    
	// enable Command mode
	bzero (writeBuffer, sizeof (writeBuffer));
	writeBuffer[0] = 0x80;
    
	
	ioReturnValue = (*hidInterface)->setReport (hidInterface, kIOHIDReportTypeOutput, 0, writeBuffer, sizeof(writeBuffer), 50, NULL, NULL, NULL);
    if (ioReturnValue != kIOReturnSuccess)
    {
       	CFShow (CFSTR ("Could not write setReport on hid device interface"));
    } 
    
    ioReturnValue = (*hidInterface)->close (hidInterface);
    
	return ioReturnValue;

}

int JWReadByteFromAddress24F14 (IOHIDDeviceInterface122 **hidInterface, UInt8 inAddress, UInt8 *result)
{
	UInt8	readBuffer[8];
	UInt8	writeBuffer[8];
	int     ioReturnValue;
	uint32_t		readDataSize;

	*result = 0;
	
	// open the interface
	ioReturnValue = (*hidInterface)->open (hidInterface, 0);
    if (ioReturnValue != kIOReturnSuccess)
	{
		CFShow (CFSTR ("couldn't open interface"));
		return ioReturnValue;
	}
	
	//if (kIOReturnSuccess != ( ioReturnValue = JWEnableCommandMode24F14 (hidInterface)))
	//	return ioReturnValue;
	
	// enable command mode
	bzero (writeBuffer, sizeof (writeBuffer));
	writeBuffer[0] = 0x82;
	writeBuffer[1] = 0x80 | inAddress;
	
	ioReturnValue = (*hidInterface)->setReport (hidInterface, kIOHIDReportTypeOutput, 0, writeBuffer, sizeof(writeBuffer), 50, NULL, NULL, NULL);
    if (ioReturnValue != kIOReturnSuccess)
    {
       	CFShow (CFSTR ("Could not write setReport on hid device interface"));
        return ioReturnValue;
    }  
	// read something from interface
	readDataSize = 8;
	ioReturnValue = (*hidInterface)->getReport (hidInterface, kIOHIDReportTypeInput,
											   0, readBuffer, &readDataSize, 100, NULL, NULL, NULL);
    if (ioReturnValue != kIOReturnSuccess)
    {
        CFShow (CFSTR ("Could not call getReport on hid device interface"));
        return ioReturnValue;
	}
	*result = readBuffer[2] ;
	
	// disable command mode
	//if (kIOReturnSuccess != ( ioReturnValue = JWDisableCommandMode24F14 (hidInterface)))
	//	return ioReturnValue;
	
	// close the interface
	ioReturnValue = (*hidInterface)->close (hidInterface);
	return ioReturnValue;
}

int JWWriteByteToAddress24F14 (IOHIDDeviceInterface122 **hidInterface, UInt8 inAddress, UInt8 inData)
{
	UInt8	writeBuffer[8];
	int     ioReturnValue;
		
	// open the interface
	ioReturnValue = (*hidInterface)->open (hidInterface, 0);
    if (ioReturnValue != kIOReturnSuccess)
	{
		CFShow (CFSTR ("couldn't open interface"));
		return ioReturnValue;
	}
	//if (kIOReturnSuccess != ( ioReturnValue = JWEnableCommandMode24F14 (hidInterface)))
	//	return ioReturnValue;
	
	// write data
	bzero (writeBuffer, sizeof (writeBuffer));
	writeBuffer[0] = 0x82;
	writeBuffer[1] = inAddress;
	writeBuffer[2] = inData;

	ioReturnValue = (*hidInterface)->setReport (hidInterface, kIOHIDReportTypeOutput, 0, writeBuffer, sizeof(writeBuffer), 50, NULL, NULL, NULL);
    if (ioReturnValue != kIOReturnSuccess)
    {
       	CFShow (CFSTR ("Could not write setReport on hid device interface"));
        return ioReturnValue;
    }  
	
	// disable command mode
	//if (kIOReturnSuccess != ( ioReturnValue = JWDisableCommandMode24F14 (hidInterface)))
	//	return ioReturnValue;
		
	// close the interface
	ioReturnValue = (*hidInterface)->close (hidInterface);
	return ioReturnValue;
}


SInt16 JWMergeAxisBytes24F14 (UInt8 inLSB, UInt8 inMSB)
{
	SInt16 result;
	SInt16 msb;
	SInt16 lsb;

	result = (inMSB & 0x80) << 8;  // move first bit of msb 8 bits to left
	
	if (result & 0x8000) // if first byte of result is set after the shift (e.g. its negative)
		result = result | 0x7C00; // enable bits 14 to 10 
	
	msb = inMSB << 2; // shift MSB two bytes to left ot make room for LSB data
	
	lsb = (inLSB & 0xC0) >> 6; // shift upper two bits of LSB to lower to bits
	
	return msb | lsb | result; // merge everything together
}

SInt16 JWMergeOffsetBytes24F14 (UInt8 inLSB, UInt8 inMSB)
{
	SInt16 msb;
	SInt16 lsb;
	
	msb = inMSB << 2; // shift MSB two bytes to left ot make room for LSB data
	
	lsb = (inLSB & 0xC0) >> 6; // shift upper two bits of LSB to lower to bits
	
	return msb | lsb ; // merge everything together
}


void JWDiffMsbLsb24F14 (UInt16 value, UInt8 *outLSB, UInt8 *outMSB)
{

	*outLSB = ((value & 0x003) << 6) & 0xC0;
	*outMSB = ((value & 0x3FC) >> 2) & 0xFF;
	
}
