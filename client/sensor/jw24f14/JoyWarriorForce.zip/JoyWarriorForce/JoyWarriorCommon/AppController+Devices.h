//
//  AppController+Devices.h
//  JoyWarrior Tilt Utility
//
//  Created by ilja on 19.02.08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "AppController.h"

@class IOHIDDeviceInterface122;

@interface AppController (Devices) 

- (NSArray*) discoverInterfacesWithDeviceID:(UInt16) inDeviceID;
- (NSArray*) discoverDevicePropertiesWithDeviceID:(UInt16) inDeviceID;
- (NSArray*) discoverInterfaces;
- (NSArray*) discoverDeviceProperties;


@end
