/**
  Define shared Javascript objects and functions for the
  MotionNode web browser based user interface.

  @file    javascript/common.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/


function init(monitor, load_state_after_command, keyboard_shortcut)
{
  GLI_EventListener.insert(null, 'unload', GLI_EventListener.clear);

  if (monitor > 0) {
    GLI_Monitor.set_rate(monitor * 1000);
    GLI_Monitor.check_content();
  }
  if (undefined !== load_state_after_command) {
    GLI_Monitor.set_load_state(load_state_after_command);
  }
  if (undefined !== keyboard_shortcut)  {
    GLI_Menu.make_keyboard_shortcut(keyboard_shortcut);
  }

  return true;
}

function this_uri()
{
  return window.location.pathname;
}
function text_content(element)
{
  var text = '';
  if (element) {
    if (element.textContent) {
      text = element.textContent;
    } else if (element.innerText) {
      text = element.innerText;
    } else if (element.innerHTML) {
      text = element.innerHTML;
    }
  }
  return text;
}
function get_elements_by_tag_name(element, name)
{
  if (element.all) {
    return element.all.tags(name);
  } else {
    return element.getElementsByTagName(name);
  }
}
function set_background_color(element, color)
{
  element.style.backgroundColor = color;
}
function set_border(element, border)
{
  element.style.border = border;
}
function send_console_chunk(element_id)
{
  var element = document.getElementById(element_id);
  if (element) {
    GLI_Command.send_chunk(element.value);
    element.value = '';
    element.focus();
  }
}

/*  Prototype JavaScript framework, version 1.4.0
 *  (c) 2005 Sam Stephenson <sam@conio.net>
 *
 *  Prototype is freely distributable under the terms of an MIT-style license.
 *  For details, see the Prototype web site: http://prototype.conio.net/
 *
/*--------------------------------------------------------------------------*/
Function.prototype.bind = function() {
  var __method = this, args = $A(arguments), object = args.shift();
  return function() {
    return __method.apply(object, args.concat($A(arguments)));
  }
}
var $A = Array.from = function(iterable) {
  if (!iterable) return [];
  if (iterable.toArray) {
    return iterable.toArray();
  } else {
    var results = [];
    for (var i = 0; i < iterable.length; i++)
      results.push(iterable[i]);
    return results;
  }
}
