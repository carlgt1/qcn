/* 
 * OnePoint is a single laptop accelerometer program designed to work with Apple
 * laptops. OnePoint was originally written by Jesse F. Lawrence. It uses
 * augmented subroutines from Christian Klein (Copyright included below). The
 * program also uses a visual interface that uses an augmented version of leolib
 * written by Paul Parker. The leolib subroutines are more easily accesed through
 * a set of subroutines czxplot that emulate ezxplot (a fortran set written by
 * Paul Parker.
 *
 * To compile on a MacBookPro: cd SRC: csh build_mac_int.csh
 *
 * As with all codes: "Beware of the bug!".
 *    10/25/07: Bug: Significance Filter gets less sensitive over time????
 *    10/25/07: Bug: Sometimes crashes when closing and opening laptop.
 *    10/25/07: Bug: Lots of warnings when compiling.
 * 
 ********************************************************************************
 * motion.c
 *
 * This code is augmented from the motion.c code developed by Christian Klein.
 *      You must include the Copyright info below if you want to use this code.
 *
 * To compile: cc -Wall -g framework IOKit motion.c -o motion
 *
 * This code creates two outputs:
 *      1) trigger.t: trigger times.
 *      2) macseis.tz: time series of the vertical component ~50 sps. 
 *
 *
 *
 *
 * a little program to display the coords returned by
 * the powerbook motion sensor
 *
 * A fine piece of c0de, brought to you by
 *
 *               ---===---
 * *** teenage mutant ninja hero coders ***
 *               ---===---
 *
 * All of the software included is copyrighted by Christian Klein <chris@5711.org>.
 *
 * Copyright 2005 Christian Klein. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by Christian Klein.
 * 4. The name of the author must not be used to endorse or promote
 *    products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <IOKit/IOKitLib.h>
#include <CoreFoundation/CoreFoundation.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <math.h>
#include <X11/Xlib.h>

#define MAXI 150001
#define FALSE 0
#define TRUE  1

struct pb_ib_data {
/*  Data structure for G4 Macs like iBook and PowerBooks */
    int8_t x;
    int8_t y;
    int8_t z;
    int8_t pad[57];
};

struct mbp_data {
/*  Data structure for intel Macs like: MacBook and MacBookPro */
    int16_t x;
    int16_t y;
    int16_t z;
    int8_t pad[34];
};



int init_mbp(int *iType, int *iKern, char **aServ, int *iStruct, io_connect_t  *aPort)
{
/*  Initiallizes the MacBookPro - or equivalent - Sudden Motion Sensor
 *    1) Sets up data structure for device
 *    2) Determines if port even exists
 *    3) Checks if the device is available
 *    4) Attempts to open the sensor
 *    5) Attempts to read the sensor
 */
      kern_return_t result;                    /* PORT KERNEL VARIABLES    */
      mach_port_t   masterPort;
      io_iterator_t iterator;
      io_object_t   aDevice;
      io_connect_t  dataPort;
      *iStruct = 1;                            /* PORT KERNEL VARIABLES    */
      *iKern   = 5;
      *aServ   = "SMCMotionSensor";

      IOItemCount structureInputSize;          /* DATA STRUCTURE SIZE      */
      IOByteCount structureOutputSize;

      struct mbp_data inputStructure;         /*  DATA STRUCTURE           */
      struct mbp_data outputStructure;

      result = IOMasterPort(MACH_PORT_NULL, &masterPort);
      CFMutableDictionaryRef matchingDictionary = IOServiceMatching(*aServ);
      result = IOServiceGetMatchingServices(masterPort, matchingDictionary, &iterator);
      if (result != KERN_SUCCESS) {
          return 0;
      };

      aDevice = IOIteratorNext(iterator);    /*CHECK THAT DEVISE IS AVAILABLE    */
      IOObjectRelease(iterator);
      if (aDevice == 0) {
          return 0;
      };
      
      result = IOServiceOpen(aDevice, mach_task_self(), 0, &dataPort);
      IOObjectRelease(aDevice);
      *aPort = dataPort;
      if(result != KERN_SUCCESS) {
         fputs("Could not open motion sensor device\n", stderr);
         return 0;
      };

      structureInputSize = sizeof(struct mbp_data);
      structureOutputSize = sizeof(struct mbp_data);

      memset(&inputStructure,*iStruct, sizeof(inputStructure));
      memset(&outputStructure,      0, sizeof(outputStructure));

      result = IOConnectMethodStructureIStructureO(
               dataPort,
               *iKern,			           /* index to kernel ,5,21,24*/
               structureInputSize,
               &structureOutputSize,
               &inputStructure,
               &outputStructure
      );                                           /* get original position   */

      if (result != KERN_SUCCESS) {                /* NO MASS POSITION SO RETURN*/
           printf("no coords");
           return 0;
      };
      return 4;
};


int init_pb_ib(int *iType, int *iKern, char **aServ, int *iStruct, io_connect_t  *aPort)
{
/*  Initiallizes the PowerBook & iBook Sudden Motion Sensors:
 *    1) Sets up data structure for device
 *    2) Determines if port even exists
 *    3) Checks if the device is available
 *    4) Attempts to open the sensor
 *    5) Attempts to read the sensor
 */
      kern_return_t result;                    /* time variables            */
      mach_port_t   masterPort;
      io_iterator_t iterator;
      io_object_t   aDevice;
      io_connect_t  dataPort;
      
      *iStruct = 0;
      if         (*iType == 1){
          *iKern = 21;
          *aServ = "IOI2CMotionSensor";
      }  else if (*iType == 2){
          *iKern = 21;
          *aServ = "IOI2CMotionSensor";
      }  else if (*iType == 3){
          *iKern = 21;
          *aServ = "PMUMotionSensor";
      };

      IOItemCount structureInputSize;          /*  */
      IOByteCount structureOutputSize;

      struct pb_ib_data inputStructure;              /*  */
      struct pb_ib_data outputStructure;

      result = IOMasterPort(MACH_PORT_NULL, &masterPort);
      CFMutableDictionaryRef matchingDictionary = IOServiceMatching(*aServ);
      result = IOServiceGetMatchingServices(masterPort, matchingDictionary, &iterator);
      if (result != KERN_SUCCESS) {
//          fputs("IOServiceGetMatchingServices returned error.\n", stderr);
          return 0;
      };


      aDevice = IOIteratorNext(iterator);   /*CHECK THAT DEVISE IS AVAILABLE    */
      IOObjectRelease(iterator);
      if (aDevice == 0) {
//          fputs("No motion sensor available\n", stderr);
          return 0;
      };
      
      result = IOServiceOpen(aDevice, mach_task_self(), 0, &dataPort);
      IOObjectRelease(aDevice);
      *aPort = dataPort;
            if(result != KERN_SUCCESS) {
         fputs("Could not open motion sensor device\n", stderr);
         return 0;
      };

      structureInputSize = sizeof(struct pb_ib_data);
      structureOutputSize = sizeof(struct pb_ib_data);
      memset(&inputStructure,*iStruct, sizeof(inputStructure));
      memset(&outputStructure,      0, sizeof(outputStructure));

      result = IOConnectMethodStructureIStructureO(
               dataPort,
               *iKern,			           /* index to kernel ,5,21,24*/
               structureInputSize,
               &structureOutputSize,
               &inputStructure,
               &outputStructure
      );                                           /* get original position   */
      if (result != KERN_SUCCESS) {                /* NO MASS POSITION SO RETURN*/
           printf("no coords");
           return 0;
      };  

      return *iType;
};




int init_sms(int *iType, int *iKern, char **aServ, int *iStruct, io_connect_t  *aPort)
{
/*  Initializes the sudden motion sensor by attempting to access each kind of 
 *  sensor, and thus figuring out which works.
 */
    int i;

    for ( i = 1; i < 4; i++ ) {
        *iType = init_pb_ib( &i, iKern, aServ, iStruct, aPort);
        if (*iType == i) {
            printf("SMS KERNEL: %d \n", *iKern);
            return 1;
        };
    };
    i=4;
    *iType = init_mbp( &i, iKern, aServ, iStruct, aPort);
     if (*iType == 4) {
         printf("SMS KERNEL: %d %s \n", *iKern, *aServ);
	 return 2;
     };
    return 0;
};


int read_xyz_pb_ib(int iKern, io_connect_t  aPort, float *x1,float *y1,float *z1, double *t1)
{
/*  Reads the sudden motion sensor one time for PowerBooks & iBooks */
      kern_return_t result;                    /* time variables            */
      IOItemCount structureInputSize;          /*  */
      IOByteCount structureOutputSize;
      struct pb_ib_data inputStructure;              /*  */
      struct pb_ib_data outputStructure;
      structureInputSize = sizeof(struct pb_ib_data);
      structureOutputSize = sizeof(struct pb_ib_data);
      
      struct timeval  tv;

      memset(&inputStructure,  0, sizeof(inputStructure));
      memset(&outputStructure, 0, sizeof(outputStructure));

      result = IOConnectMethodStructureIStructureO(
               aPort,
               iKern,			           /* index to kernel ,5,21,24*/
               structureInputSize,
               &structureOutputSize,
               &inputStructure,
               &outputStructure
      );                                           /* get original position   */
      gettimeofday(&tv,NULL);                      /* milliseconds              */
      *t1 = tv.tv_sec+tv.tv_usec*1e-6;
      *x1 = outputStructure.x;                     /* SIDE-TO-SIDE POSITION         */
      *y1 = outputStructure.y;                     /* FRONT-TO-BACK POSITION        */
      *z1 = outputStructure.z;                     /* VERTICAL POSITION  */
      return 1;
};


int read_xyz_mbp(int iKern, io_connect_t  aPort, float *x1,float *y1,float *z1, double *t1)
{
/*  Reads the sudden motion sensor one time for MacBookPros & similar */
      kern_return_t result;                    /* time variables            */
      IOItemCount structureInputSize;          /*  */
      IOByteCount structureOutputSize;
      struct mbp_data inputStructure;              /*  */
      struct mbp_data outputStructure;
      structureInputSize = sizeof(struct mbp_data);
      structureOutputSize = sizeof(struct mbp_data);
      
      struct timeval  tv;

      memset(&inputStructure,  1, sizeof(inputStructure));
      memset(&outputStructure, 0, sizeof(outputStructure));

      result = IOConnectMethodStructureIStructureO(
               aPort,
               iKern,			           /* index to kernel ,5,21,24*/
               structureInputSize,
               &structureOutputSize,
               &inputStructure,
               &outputStructure
      );                                           /* get original position   */
      gettimeofday(&tv,NULL);                      /* milliseconds              */
      *t1 = tv.tv_sec+tv.tv_usec*1e-6;
      *x1 = outputStructure.x;                     /* SIDE-TO-SIDE POSITION         */
      *y1 = outputStructure.y;                     /* FRONT-TO-BACK POSITION        */
      *z1 = outputStructure.z;                     /* VERTICAL POSITION  */
      return 1;
};

void get_t0(double *t1)
{
      struct timeval tv;
      
      gettimeofday(&tv,NULL);
      *t1 = tv.tv_sec+tv.tv_usec*1e-6;
}

float sqr(float fIn)
{
/* There must be an intrinsic math function for this but ... I'm not a good C
 *       programmer
 */
     float sqrf=fIn*fIn;return sqrf;
}

int iPlace(int iIn)
{
/*  A simple subroutine to loop through a vector so that x is always between
 *  zero and the maximum defined value (MAXI) even if negative
 */
    int iP=iIn, i;
    for (i = 0; i < 1000; i++) {
       if (iP<0){iP=iP+MAXI;};
       if(iP>MAXI){iP=iP-MAXI;};
       if ( (iP>=0)&&(iP<=MAXI) ) {return iP;};
    }
    return 0;
};

int mean_xyz(int iT, int iK, io_connect_t  aP, double t0, double dt,
      float *x2, float *y2, float *z2)
{
/* This subroutine finds the mean amplitude for x,y, & z of the sudden motion
 * sensor in a window dt from time t0.
 */
   float n2,x1,y1,z1;
   float dtime;
   int   d,isleep;
   double t1;
   
   n2=0.;
   *x2=0.;*y2=0.;*z2=0.;                           /*  ZERO SAMPLE AVERAGES            */
   dtime=0.;
   isleep = dt*10000;
   while (dtime < dt/4){
     if (iT < 4) {
       d = read_xyz_pb_ib(iK, aP, &x1, &y1, &z1, &t1);
     } else if (iT == 4) {
       d = read_xyz_mbp(iK, aP, &x1, &y1, &z1, &t1);
     }
     *x2=*x2+x1; *y2=*y2+y1; *z2=*z2+z1; n2=n2+1.;
     usleep(isleep);
     dtime = t1-t0;
     if (dtime < -2.*dt) {return -1;};           /*  IF TIME OFSET, RETURN ERROR    */
   };
   *x2=*x2/n2;*y2=*y2/n2;*z2=*z2/n2;               /*  STORE POSITIONS IN TIME SERIES  */
   return 0;
};


int sacio(int n1,int n2, float x0[MAXI], float y0[MAXI], float z0[MAXI], float s0[MAXI],double tb, double dt, char *sname, int nf)
{
/* This subroutine writes the data to a binary sac file (a common format used by
 * many seismologists). JFL needs to make an equivalent for reading these files.
 */
    int     npts, nerr, i,j;
    long    tru = TRUE;
    float   te2,tb2;                               /*  TIME OF LAST POINT              */
    char    fname[64];
    npts =  n2-n1-1;                               /*  NUMBER OF POINTS IN OUT FILE    */
    float   x[npts],y[npts],z[npts],s[npts];
    double  t[npts];
    float   delta;
    struct  tm * q;
    int     itime;
    time_t  rtime;
    q =   gmtime( &rtime );
    for (j = 0; j <= npts; j++) {
       i = iPlace(n1 + (j));
       t[j] = j*dt+tb;
       x[j] = x0[i];
       y[j] = y0[i];
       z[j] = z0[i];
       s[j] = s0[i];
    };
    tb2 = t[1];
    te2 = t[npts];
    delta = dt;
    printf("TIMES: %f %f %f %f %lo \n",x[npts],y[npts],z[npts],t[npts],tru);
    newhdr_();                                      /*  CREATE NEW SAC HEADER FILE      */
    setnhv_("npts"   , &  npts , &nerr, 4   );
    setlhv_("leven"  , &   tru , &nerr, 5   );
    setfhv_("delta"  , & delta , &nerr, 5   );
    setihv_("iztype" ,    "IO" , &nerr, 6, 2);
    setihv_("idep"   , "IDISP" , &nerr, 4, 5);      /*  SET HEADER TO TIME SERIES      */
    setihv_("iftype" , "ITIME" , &nerr, 6, 5);      /*  SET HEADER TO TIME SERIES      */
    setfhv_("b"      , &   tb2 , &nerr, 1   );
    setfhv_("e"      , &   te2 , &nerr, 1   );
    setnhv_("nzyear" , &q->tm_year, &nerr, 6 );        /*GET HEADER START YEAR           */
    setnhv_("nzjday" , &q->tm_yday, &nerr, 6 );        /*GET HEADER START JULIAN DAY     */
    setnhv_("nzhour" , &q->tm_hour, &nerr, 6 );        /*GET HEADER START HOUR           */
    setnhv_("nzmin"  , &q->tm_min, &nerr, 5 );        /*GET HEADER START MINUTE         */
    setnhv_("nzsec"  , &q->tm_sec, &nerr, 5 );        /*GET HEADER START SECOND         */
    itime=rtime;
    itime=(rtime-itime)*1000;
    setnhv_("nzmsec" , &itime  , &nerr, 6 );        /*GET HEADER START MILISECOND     */
    sprintf(fname,"%s.%3.3d.S.sac",sname,nf);
    wsac0_(fname, t,s,&nerr, strlen(fname));
    sprintf(fname,"%s.%3.3d.X.sac",sname,nf);
    wsac0_(fname, t,x,&nerr, strlen(fname));
    sprintf(fname,"%s.%3.3d.Y.sac",sname,nf);
    wsac0_(fname, t,y,&nerr, strlen(fname));
    sprintf(fname,"%s.%3.3d.Z.sac",sname,nf);
    wsac0_(fname, t,z,&nerr, strlen(fname));
    printf("fname: %s %d %d \n",fname,nerr,itime);
    return 0;

};


float mod(x1,y1)
float x1,y1;
{
/*  Determines the remainder of x1/y1 */
    float div11 = x1/y1;
    int   idiv1 = (int) div11;
    div11 = div11-(float)idiv1;
    return div11;
}



int main()
{
/*  This is the meet of the program OnePoint.
 *
 */
    int    iKern,iType,iStruct;                    /*  DEFIND SMS KERNEL VARIABLES    */
    char   *aServ;                                 /*  SENSOR MODEL */
    int    i,j,d,itl,itm,iout;                     /*  COUNTING VARIABLES */
    double t1,t0,dt=0.1,tcent,tb;                  /*  TIME & SAMPLING INTERVAL        */
    float  x0[MAXI],y0[MAXI],z0[MAXI];             /*  DECLARE TIME SERIES             */
    float  fmag[MAXI],amag[MAXI],f1;               /*  MAGNITUDE OF SIGNAL             */
    float  vari[MAXI],fsig[MAXI],sgmx;             /*  VARIANCE & STANDARD DEVIATION   */
    float  xa[MAXI],ya[MAXI],za[MAXI];             /*  AVERAGE VALUES OF x,y, &z*/
    float  twin = 60.*1.,twi=-twin/2.+dt,twim1=twi-dt;/*  TIME WINDOW IN SECONDS          */

    int    iWin,iB1,iB0,iM1,iM0;                   /*  POINT IN ARRAY BEGINNING&LAST   */
    char   hostname[64],fname[64];                 /*  COMPUTER NAME & FILE NAMES      */
    int    nf=0;                                   /*  COUNT OF NUMBER OF OUT FILES    */
    FILE   *fp1;                                   /*  OUTPUT FILES                    */
    io_connect_t  aPort;                           /*  PORT CONNECTION */
    int    n1,n2;                                  /*  START & STOP OF FILE WINDW*/
    float  tw[10000];                              /*  TIME OF POINT   */
    long   icol;                                   /*  INDEX FOR COLOR */
    char   amess[64];                              /*  MESSAGE TO SCREEN  */
    
    i = init_sms(&iType, &iKern, &aServ, &iStruct, &aPort); /*  Initiate SMS Sensor    */
    if (i == 0) {
       printf("NO KERNEL FOUND");
       return 0;
    } else {
       printf("SMS SENSOR INITIALIZED. \n \n");
    };
    usleep(20000);                                 /*  PUASE TO AVOID TYPING VIBRATIONS*/
    
    gethostname(hostname, sizeof(hostname));       /* get host name                    */
    sprintf(fname,"%s.trig",hostname);
    fp1 = fopen(fname,"w");                        /* open out file                    */
    fprintf(fp1,"%s \n", hostname);                /* output host name                 */
    

    long  fwidth  = 1100, fheight = 800;
    czxinit_(&fwidth,&fheight);

    OnePointLogo_();                               /*  CREATS THE OnePoint LOGO */
    

    fmag[0] = 0.;                                  /*  INITIAL ZERO POSITION           */
    amag[0] = 0.;                                  /*  INITIAL ZERO AVERAGE            */
    vari[0] = 0.;                                  /*  STANDARD DEVIATION              */
    t0      = t1+0.1;

    long  px1= 0.1*fwidth,px2=0.9*fwidth,py1=0.1*fheight,py2 = 0.9*fheight;
    float x1=-twin/2.,x2=twin/2.,y1=0.,y2=4.;       /*  PLOT AREA DIMENSIONS  */
    icol = 0; czxcol_(&icol);
    czxwind_(&px1,&px2,&py1,&py2,&x1,&x2,&y1,&y2);  /* SETS UP PLOT AREA */
    czxfram_(&x1,&x2,&y1,&y2);                      /* CREATES A BOX AROUND PLOT */

    float xm1 = x1-3.;
    char alab[4];

    for (i=0;i<=3;i++){                             /*  DRAW LINES BETWEEN x,y,&z*/
       y1 = (float) i;
       czxmove_(&x1,&y1);
       czxdraw_(&x2,&y1);
    }
    
    long nlorg = 5; laligntext_(&nlorg);           /*  LABEL EACH COMPONENT */
    for (i=0;i<=3;i++){
       y1 = (float) i +0.5;
       if (i == 0) {sprintf(alab,"X-Amp");icol=5;czxcol_(&icol);};
       if (i == 1) {sprintf(alab,"Y-Amp");icol=4;czxcol_(&icol);};
       if (i == 2) {sprintf(alab,"Z-Amp");icol=3;czxcol_(&icol);};
       if (i == 3) {sprintf(alab,"Sigma");icol=2;czxcol_(&icol);};
       czxlabxy_(&xm1,&y1,&alab);
    }
    
    y1 = 0.;                                       /*  LABEL X AXIS */
    icol = 0; czxcol_(&icol);
    nlorg = 2; laligntext_(&nlorg);
    sprintf(amess,"Time Window Length: %f Seconds \n",twin);xm1=0.;y1=-0.1;
    czxlabxy_(&xm1,&y1,&amess);    
    
    iWin = twin/dt;                                /*  TIME WINDOW IN POINTS           */
    for (i = 0; i<iWin; i++) {
       tw[i] = -twin/2.+i*dt;
    }
    
    if (iWin > MAXI) {
       printf("**ERROR: iWin > MAXI, RESET twin or MAXI: %d %d \n",iWin,MAXI);
       return 0;
    };
    
    float dx1=0.5,dy1=1.5,dz1=2.5,ds1=3.5;
    get_t0(&t0);                                   /*  GET TIME FROM CLOCK */
    i = 0.;
    d = mean_xyz(iType,iKern,aPort,t0,dt,&x0[i],&y0[i],&z0[i]);/* GET x,y,z */

    while (i > -1) {                               /*  CREATE BASELINE VALUES          */



      if (i==0) {       
/* In this section we sample the time sensor to provide a basis for the
 * triggering algorithm.
 *
 * Average:           xav(N) = sum(x(i))/N
 *        FASTER AS:  xav(N) = [ (N-1)*xav(N-1) + x(N)]/N
 * Variance:          vari(N) = sum (x(i)-xav(N))^2/N (SUMMED FOR x, y, & z)
 *        FASTER AS:  vari(N) = [ (N-1)*vari(N-1) + (x(N)-xav(N))^2 ]/N
 * Standard Deviation: stdev(N) = sqrt(vari(N))
 * Magnitude: fmag(N) = sqrt( (x(N)-xav(N))^2+(y(N)-yav(N))^2+(z(N)-zav(N))^2 )
 * Significance: fsig(N) = fmag(N)/stdev(N)
 *
 */
        sprintf(amess,"Initiallizing Window \n");czxmessc_(&amess);
	tcent = t0+60.*60.*24.;                    /*  SET CENTER TIME 24 HOURS FROM NOW*/
        printf("OBTAINING INITIAL WINDOW \n");

/* Get a stable initial mean value to start from */
        xa[i]  =0.; ya[i]=0. ;za[i]=0.;               /*  INITIAL MEAN IS INITIAL POINT   */
        for (j = 1; j < 10; j++) {
           d = mean_xyz(iType,iKern,aPort,t0,dt,&x0[i],&y0[i],&z0[i]);
           xa[i] = xa[i] + x0[i] / 10.;
           ya[i] = ya[i] + y0[i] / 10.;
           za[i] = za[i] + z0[i] / 10.;
        }
        sgmx = 0.;
        xa[i]  =x0[i];ya[i]=y0[i];za[i]=z0[i];      /*  INITIAL MEAN IS INITIAL POINT   */
        fmag[i]=sqrt(sqr(x0[i])+sqr(y0[i])+sqr(z0[i]));
        vari[i]=f1;

/* Measure baseline x, y, & z acceleration values for a 1 minute window */
	for (i = 1; i < iWin+1; i++) {             /*  CREATE BASELINE AVERAGES          */
          if (i > MAXI) i=0;
          iB1 =i-iWin; if (iB1<0){iB1 = iPlace(iB1);}; /*  PLACE OF LAST POINT IF LOOPED   */
          iB0 =iB1-1 ; if (iB0<0){iB0 = iPlace(iB0);}; /*  PLACE OF LAST POINT IF LOOPED   */
          iM1 =i-1;    if (iM1<0){iM1 = iPlace(iM1);}; /*  PLACE OF LAST POINT IF LOOPED   */
          iM0 =i-2;    if (iM0<0){iM0 = iPlace(iM0);}; /*  PLACE OF LAST POINT IF LOOPED   */
	  d = mean_xyz(iType,iKern,aPort,t0,dt,&x0[i],&y0[i],&z0[i]);
          xa[i]  = ((i)*xa[i-1]+x0[i])/(i+1);         /*  AVERAGE X    */
          ya[i]  = ((i)*ya[i-1]+y0[i])/(i+1);         /*  AVERAGE Y    */
          za[i]  = ((i)*za[i-1]+z0[i])/(i+1);         /*  AVERAGE Z    */
          fmag[i] = sqrt(sqr(x0[i]-xa[iM1])+sqr(y0[i]-ya[iM1])+sqr(z0[i]-za[iM1]));
         

/* Plot data to X11 window */
          t0=t0+dt;
	  float fii = i, fii2 = 1./dt, fii3 = mod(fii,fii2);
	  if (fii3 == 0.) {                           /*  CLEAR X11 WINDOW */
	     czxmessc_clr_();
	  };      
	  
	  fii = i; fii2 = 2./dt; fii3 = mod(fii,fii2);/*  BLINKING MESSAGE */
          if (fii3 == 0.) {                
             sprintf(amess,"Initiallizing Window \n");czxmessc_(&amess);
          }
	  
	  twi = twi + dt;                             /* TIMING VARIABLES */
	  if (twi > twin/2.) { twi = -twin/2.+dt;};
          twim1 = twi-dt;

          icol = 5; czxcol_(&icol);                   /* PLOT X ACCEL IN GREEN */
          czxmove_(&twim1,&dx1);
          dx1 = (x0[i]-xa[i])/10.+0.5;
          if (dx1 > 1.0) {dx1 = 1.0;};
          if (dx1 < 0.0) {dx1 = 0.0;};
          czxdraw_(&twi,&dx1);
          
          icol = 4; czxcol_(&icol);                   /* PLOT Y ACCEL IN YELLOW */
          czxmove_(&twim1,&dy1);
          dy1 = (y0[i]-ya[i])/10.+1.5;
          if (dy1 > 2.0) {dy1 = 2.0;};
          if (dy1 < 1.0) {dy1 = 1.0;};
          czxdraw_(&twi,&dy1);
          
          icol = 3; czxcol_(&icol);                   /* PLOT Z ACCEL IN BLUE */
          czxmove_(&twim1,&dz1);
          dz1 = (z0[i]-za[i])/10.+2.5;
          if (dz1 > 3.0) {dz1 = 3.0;};
          if (dz1 < 2.0) {dz1 = 2.0;};
          czxdraw_(&twi,&dz1);
          
          icol = 2; czxcol_(&icol);                   /* DON'T PLOT SIGNIFICANC*/
          czxmove_(&twim1,&ds1);
          ds1 = 3.5;
          if (ds1 > 4.0) {ds1 = 4.0;};
          if (ds1 < 3.0) {ds1 = 3.0;};
          czxdraw_(&twi,&ds1);
          
	  ldoit_();                                   /* FORCE TO PLOT */
        }

/* Determine base line values of variance & significance for first minute */
	for (i = 1; i < iWin+1; i++) {             /*  CREATE BASELINE SIGNIFICAN          */
          vari[i]= ( (i-1) * vari[i-1] + sqr(x0[i]-xa[i])
                                       + sqr(y0[i]-ya[i])
                                       + sqr(z0[i]-za[i]) ) / i;
          fsig[i]= fmag[i]/(sqrt(vari[iM1])+0.01); /* +0.01 SO NO DIVIDE BY ZERO*/

          if ( (fsig[i] > sgmx) && (i > 60) ) {   /*  LAST MAXIMUM SIG & PLACE       */
            sgmx = fsig[i];
            itl = iWin-i+1;
          };

        };

/* Print a status report to X11 window */
        printf("INITIAL MAX SIGMA: %d %f \n\n",itl,sgmx);
        sprintf(amess,"Monitoring Window \n");czxmessc_(&amess);
        i-=1;
      };                                           /*                                  */




/* Keep track of start of window relative to ith point */
      i  +=1;      if (i > MAXI) i=0;              /*  LOOP BACK THRU DATA SERIES      */
      iB1 =i-iWin; if (iB1<0){iB1 = iPlace(iB1);}; /*  PLACE OF LAST POINT IF LOOPED   */
      iB0 =iB1-1 ; if (iB0<0){iB0 = iPlace(iB0);}; /*  PLACE OF LAST POINT IF LOOPED   */
      iM1 =i-1;    if (iM1<0){iM1 = iPlace(iM1);}; /*  PLACE OF LAST POINT IF LOOPED   */
      iM0 =i-2;    if (iM0<0){iM0 = iPlace(iM0);}; /*  PLACE OF LAST POINT IF LOOPED   */
      itl+=1;                                      /*  # POINTS SINCE LAST LARGE SIG   */



/* Monitor Sensor: 
 * Note: Equations are different here because we have a full window already .
 *
 * Average:           xav(N) = sum(x(i))/N
 *        FASTER AS:  xav(N) = xav(N-1) + x(N)/N
 * Variance:          vari(N) = sum (x(i)-xav(N))^2/N (SUMMED FOR x, y, & z)
 *        FASTER AS:  vari(N) = vari(N-1) + [ (x(N)     -xav(N))^2      ]/N 
 *                                        - [ (x(N-iWin)-xav(N-iWin))^2 ]/N
 *
 */
      d   = mean_xyz(iType,iKern,aPort,t0,dt,&x0[i],&y0[i],&z0[i]);
      if (d < 0) i=0;

      xa[i]  = xa[iM1]+(x0[i]-x0[iB1])/iWin;         /*  AVERAGE Z    */
      ya[i]  = ya[iM1]+(y0[i]-y0[iB1])/iWin;         /*  AVERAGE Z    */
      za[i]  = za[iM1]+(z0[i]-z0[iB1])/iWin;         /*  AVERAGE Z    */
      vari[i]= vari[iM1] + ( sqr(x0[i]   - xa[i]   )
                           + sqr(y0[i]   - ya[i]   )
                           + sqr(z0[i]   - za[i]   ) ) / iWin;
			 - ( sqr(x0[iB1] - xa[iB1] )
                           + sqr(y0[iB1] - ya[iB1] )
                           + sqr(z0[iB1] - za[iB1] ) ) / iWin;
      fmag[i]= sqrt(sqr(x0[i]-xa[iM1])+sqr(y0[i]-ya[iM1])+sqr(z0[i]-za[iM1]));
      fsig[i]= fmag[i]/(sqrt(vari[iM1])+0.01);
      


/* Plot data to X11 window */
      twi = twi + dt;                               /* Determine time for plot */
      if (twi > twin/2.) {
         twi = -twin/2.+dt;
      };
      twim1 = twi-dt;
      float y3 = 4.;float y36=0.1;
      y2 = 0.;y3 = 4.;

      czxclrb_(&twi, &y3, &y36, &y3);               /* Clear a few seconds swath*/
      
      if (twi > -twin/2.) {
          float x11 = -twin/2., x21 = twin/2., y11 = 0., y21 = 4.;
          icol = 0; czxcol_(&icol);
	  czxfram_(&x11,&x21,&y11,&y21);           /* Re-frame plotting window */
          
          for (j=0;j<=3;j++){                      /* Plot lines divideing x,y,z */                  
             y11 = (float) j;
             czxmove_(&x11,&y11);
             czxdraw_(&x21,&y11);
          }    
          
	  icol = 5; czxcol_(&icol);                   /* PLOT X ACCEL IN GREEN */
          czxmove_(&twim1,&dx1);
          dx1 = (x0[i]-xa[i])/10.+0.5;
          if (dx1 > 1.0) {dx1 = 1.0;};
          if (dx1 < 0.0) {dx1 = 0.0;};
          czxdraw_(&twi,&dx1);
          
          icol = 4; czxcol_(&icol);                   /* PLOT Y ACCEL IN YELLOW */
          czxmove_(&twim1,&dy1);
          dy1 = (y0[i]-ya[i])/10.+1.5;
          if (dy1 > 2.0) {dy1 = 2.0;};
          if (dy1 < 1.0) {dy1 = 1.0;};
          czxdraw_(&twi,&dy1);
          
          icol = 3; czxcol_(&icol);                   /* PLOT Z ACCEL IN BLUE */
          czxmove_(&twim1,&dz1);
          dz1 = (z0[i]-za[i])/10.+2.5;
          if (dz1 > 3.0) {dz1 = 3.0;};
          if (dz1 < 2.0) {dz1 = 2.0;};
          czxdraw_(&twi,&dz1);
           
          icol = 2; czxcol_(&icol);                   /* PLOT SIGNIFICANCE RED */
          czxmove_(&twim1,&ds1);
          ds1 = (fsig[i]    )/10.+3.5;
          if (ds1 > 4.0) {ds1 = 4.0;};
          if (ds1 < 3.0) {ds1 = 3.0;};
          czxdraw_(&twi,&ds1);
       }
       ldoit_();                                    /* FORCE PLOTTING TO SCREEN*/
      


/* Determine if significance filter is large enough to warrant a trigger*/
       if (fsig[i]>1.33*sgmx){                      /* 33% larger than others */
         sgmx=fsig[i];itl=0;
         if ( (fsig[i]>2.1) && (fmag[i]>0.125) ) {  /* >2 sigma (90% Conf) */
           sprintf(amess,"Trigger Time: %f   Trigger Amp: %f \n",t0,fsig[i]);czxmessc_(&amess);
           itm = i+iWin;if (itm>MAXI)itm=itm-MAXI;
           iout= i+60/dt;                           /*  TIME STEP TO OUTPUT FILE    */

           float y11 = 0., y21 = 4.;                /* PLOT TIME FOR TRIGGER */
           long i22 = 7, i11 = 1;
           czxcol_(&i22);
           czxmove_(&twi, &y11);
           czxdraw_(&twi, &y21);
           czxcol_(&i11);

         };
      };


/* Find the largest significance in the time window */
      if (itl > iWin) {
        sgmx = 0.;
	for (j=i-iWin+1; j<i; j++) {
          if (fsig[iPlace(j)] > sgmx) {          /*  MAXIMUM SIGNIFICANCE             */
            sgmx = fsig[iPlace(j)];
            itl = i-j;
          };
        };
        printf("%d %d MAX:%d %f \n",i,iWin,itl,sgmx);
      };
      
/* Output 2 minute data file if a trigger occured 1 minute ago */
      if (i == itm) {
         nf = nf + 1;                                 /*  COUNT # OF TRIGGERED FILES  */
         gethostname(hostname, sizeof(hostname));     /*  GET HOST NAME               */
         sprintf(fname,"%s.%d.xyz",hostname,nf);      /*  CREATE FILE NAME            */
         n1 = i - iWin - (60/dt);                     /*  STARTING POINT OF FILE      */
         n2 = n1+(120/dt);                            /*  ENDING POINT OF FILE        */
	 tb = -60e0;                                  /*  FILE STARTING TIME          */
         sacio(n1,n2,x0,y0,z0,fsig,tb,dt,hostname,nf);     /* OUTPUT SAC FILE OF TRIG DAT  */
      };

      t0=t0+dt;                                       /*  STEP FORWARD IN TIME
      if (t0 > tcent) i = 0;                          /*  RE-CENTER EVERY 24 HOURS   */

    };

    IOServiceClose(aPort);                            /*  CLOSE WINDOW  */
    czxquit_();
    return 0;
};
