To enable the MotionNode tracker in your VRPN server, make the following changes
to the source files.

vrpn_Generic_server_object.h:

#include "vrpn_Tracker_MotionNode.h"

int setup_Tracker_MotionNode (char * & pch, char * line, FILE * config_file);

vrpn_Generic_server_object.C:
...
} else if (isit("vrpn_Tracker_NULL")) {
  CHECK(setup_Tracker_NULL);
} else if (isit("vrpn_Tracker_MotionNode")) {
  CHECK(setup_Tracker_MotionNode);
}
...

int vrpn_Generic_Server_Object::setup_Tracker_MotionNode(char * & pch, char * line, FILE * config_file)
{
  char name[LINESIZE];
  unsigned num_sensors = 0;
  char address[LINESIZE];
  unsigned port = 0;

  next();
  // Get the arguments (class, tracker_name, sensors, rate)
  if (4 != sscanf(pch,"%511s%u%511s%u", name, &num_sensors, address, &port)) {
    fprintf(stderr, "Bad vrpn_Tracker_MotionNode line: %s\n", line);
    return -1;
  }

  // Make sure there's room for a new tracker
  if (num_trackers >= VRPN_GSO_MAX_TRACKERS) {
    fprintf(stderr,"Too many trackers in config file");
    return -1;
  }

  // Open the tracker
  if (verbose) {
    printf(
      "Opening vrpn_Tracker_MotionNode: %s with %u sensors, address %s, port %u\n",
      name, num_sensors, address, port);
  }

  trackers[num_trackers] = new vrpn_Tracker_MotionNode(name, connection, num_sensors, address, port);

  if (NULL == trackers[num_trackers]) {
    fprintf(stderr, "Failed to create new vrpn_Tracker_MotionNode\n");
    return -1;
  } else {
    num_trackers++;
  }

  return 0;
}
