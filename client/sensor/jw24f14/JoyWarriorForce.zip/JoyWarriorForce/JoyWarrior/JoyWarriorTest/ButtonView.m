//
//  ButtonView.m
//  JoyWarriorTest
//
//  Created by Guido K�rber on 17.09.04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import "ButtonView.h"


@implementation ButtonView

- (void) awakeFromNib
{
	[self resetState];
}

- (void) resetState
{
	[self setLastValue:0];
	[self setButtonState:kButtonStateUntested];
}

- (void)drawRect:(NSRect)rect{

	switch (buttonState)
	{
		case kButtonStateDisabled:
			[[NSColor grayColor] set];
			break;
			
		case kButtonStateUntested:
			[[NSColor redColor] set];
			break;
			
		case kButtonStateTested:
			[[NSColor greenColor] set];
			break;
			
		case kButtonStatePressed:
			[[NSColor yellowColor] set];
			break;
	}
    // Drawing code here.
	NSRect myRect = NSInsetRect (rect, 2, 2);
	
	NSBezierPath *path = [NSBezierPath bezierPathWithOvalInRect:myRect];
	
	[path fill];
	[path setLineWidth:2];
	[[NSColor blackColor] set];
	[path stroke];
}


- (int) buttonState { return buttonState; }
- (void) setButtonState: (int) inButtonState
{
        buttonState = inButtonState;
	[self setNeedsDisplay];
}

- (int) lastValue { return lastValue; }
- (void) setLastValue: (int) inLastValue
{
	lastValue = inLastValue;
	[lastValueField setIntValue:lastValue];
}


@end
