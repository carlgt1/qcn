//
//  Settings.m
//  JoyWarrior Programmingtool
//
//  Created by ilja on 26.10.07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import "Settings.h"


@implementation Settings

+ (int) intFromHexString:(NSString*) inString
{
	if (nil == inString)
		return 0;
	
	NSScanner	*theScanner = [NSScanner scannerWithString:inString];
	unsigned	int	result;
	
	if ([theScanner scanHexInt: &result])
	{
		return result;
	}
	return 0;
}

+ (NSString*) hexStringFromInt:(int) inValue
{
	return [NSString stringWithFormat:@"%02X", inValue];
}

- (NSData*) reportDataWithReadData:(NSData*) readData;
{
	unsigned char result[11];
	unsigned char *readBytes = (unsigned char*) [readData bytes];
	
	bzero (result, sizeof (result));
	
	// Address 0b
	result[0] = counterHG;
	result[0] |= (enableHG ? 0x02 : 0x00);
	result[0] |= counterLG;
	result[0] |= (enableLG ? 0x01 : 0x00);
	result[0] |= (alert ? 0x80 : 0x00);
	result[0] |= (enableAnyMotion ? 0x40 : 0x00);
	
	result[1] = [Settings intFromHexString:thresholdLG];
	result[2] = [Settings intFromHexString:durationLG];
	result[3] = [Settings intFromHexString:thresholdHG];
	result[4] = [Settings intFromHexString:durationHG];
	result[5] = [Settings intFromHexString:anyMotionThreshold];
	
	// Address 11
	result[6] = hystLG | hystHG | anyMotionDuration ;
	
	result[7] = [Settings intFromHexString:customByte1];
	result[8] = [Settings intFromHexString:customByte2];
	
	// Address 14
	result[9] = range | bandwidth | (readBytes[9] & 0xE0); 
	
	// Address 15
	result[10] = (shadowDis ? 0x08 : 0x00);
	result[10] |= (latchInt ? 0x10 : 0x00);
	result[10] |= (newDataInt ? 0x20 : 0x00);
	result[10] |= (advInt? 0x40 : 0x00);
	
	result[10] |= 0x80;

	return [NSData dataWithBytes:result length:sizeof (result)];
}

- (id) initWithReportData:(NSData*) inData fieldDescriptions:(NSDictionary*) inFieldDescriptions
{
	UInt8*	reportBytes = (UInt8*) [inData bytes];
	
	self = [super init];
	if (self)
	{
		NSEnumerator	*e = [[inFieldDescriptions allKeys] objectEnumerator];
		NSString		*theKey;
		
		while (nil != (theKey = [e nextObject]))
		{
			NSDictionary *fieldDescription = [inFieldDescriptions objectForKey:theKey];
			
			int			byteIndex = [[fieldDescription objectForKey:@"byte"] intValue] ;
			int			startBit = [[fieldDescription objectForKey:@"startBit"] intValue] ;
			int			length = [[fieldDescription objectForKey:@"length"] intValue] ;
			BOOL		needsShift = [[fieldDescription objectForKey:@"needsShift"] boolValue];
			NSString	*type = [fieldDescription objectForKey:@"type"];
			UInt8		byte = reportBytes[byteIndex];
			UInt8		mask = 0;
			UInt8		fieldData;
			int			i;
			
			// construct mask
			for (i = 0; i < 8; i++)
			{
				if (i >= startBit && i < startBit + length)
				{
					mask |= 1 << i;
				}
			}
			// get data
			fieldData = byte & mask;
			// shift if necessary 
			if (needsShift)
			{
				fieldData = fieldData >> startBit;
			}
			if ([type isEqualToString:@"hexString"])
			{
				[self setValue:[Settings hexStringFromInt:fieldData]
						forKey:theKey];
			}
			else
			{
				[self setValue:[NSNumber numberWithUnsignedInt: (UInt32) fieldData]
						forKey:theKey];
			}
		}
	}
	return self;
}


- (void) dealloc
{
    [self setDurationLG: nil];
    [self setThresholdLG: nil];
    [self setDurationHG: nil];
    [self setThresholdHG: nil];
    [self setAnyMotionThreshold: nil];
    [self setCustomByte1: nil];
    [self setCustomByte2: nil];
	
    [super dealloc];
}



- (int) range
{
	
    return range;
}

- (void) setRange: (int) inRange
{
	range = inRange;
}


- (int) bandwidth
{
	
    return bandwidth;
}

- (void) setBandwidth: (int) inBandwidth
{
	bandwidth = inBandwidth;
}


- (int) counterLG
{
	
    return counterLG;
}

- (void) setCounterLG: (int) inCounterLG
{
	counterLG = inCounterLG;
}


- (BOOL) enableLG
{
	
    return enableLG;
}

- (void) setEnableLG: (BOOL) flag
{
	enableLG = flag;
}


- (int) hystLG
{
	
    return hystLG;
}

- (void) setHystLG: (int) inHystLG
{
	hystLG = inHystLG;
}


- (NSString *) durationLG
{
    return durationLG; 
}

- (void) setDurationLG: (NSString *) inDurationLG
{
    if (durationLG != inDurationLG) {
        [durationLG autorelease];
        durationLG = [inDurationLG retain];
    }
}


- (NSString *) thresholdLG
{
    return thresholdLG; 
}

- (void) setThresholdLG: (NSString *) inThresholdLG
{
    if (thresholdLG != inThresholdLG) {
        [thresholdLG autorelease];
        thresholdLG = [inThresholdLG retain];
    }
}


- (BOOL) enableHG
{
	
    return enableHG;
}

- (void) setEnableHG: (BOOL) flag
{
	enableHG = flag;
}


- (int) counterHG
{
	
    return counterHG;
}

- (void) setCounterHG: (int) inCounterHG
{
	counterHG = inCounterHG;
}


- (int) hystHG
{
	
    return hystHG;
}

- (void) setHystHG: (int) inHystHG
{
	hystHG = inHystHG;
}


- (NSString *) durationHG
{
    return durationHG; 
}

- (void) setDurationHG: (NSString *) inDurationHG
{
    if (durationHG != inDurationHG) {
        [durationHG autorelease];
        durationHG = [inDurationHG retain];
    }
}


- (NSString *) thresholdHG
{
    return thresholdHG; 
}

- (void) setThresholdHG: (NSString *) inThresholdHG
{
    if (thresholdHG != inThresholdHG) {
        [thresholdHG autorelease];
        thresholdHG = [inThresholdHG retain];
    }
}


- (BOOL) enableAnyMotion
{
	
    return enableAnyMotion;
}

- (void) setEnableAnyMotion: (BOOL) flag
{
	enableAnyMotion = flag;
}


- (int) anyMotionDuration
{
	
    return anyMotionDuration;
}

- (void) setAnyMotionDuration: (int) inAnyMotionDuration
{
	anyMotionDuration = inAnyMotionDuration;
}


- (NSString *) anyMotionThreshold
{
    return anyMotionThreshold; 
}

- (void) setAnyMotionThreshold: (NSString *) inAnyMotionThreshold
{
    if (anyMotionThreshold != inAnyMotionThreshold) {
        [anyMotionThreshold autorelease];
        anyMotionThreshold = [inAnyMotionThreshold retain];
    }
}


- (BOOL) latchInt
{
	
    return latchInt;
}

- (void) setLatchInt: (BOOL) flag
{
	latchInt = flag;
}


- (BOOL) newDataInt
{
	
    return newDataInt;
}

- (void) setNewDataInt: (BOOL) flag
{
	newDataInt = flag;
}


- (BOOL) advInt
{
	
    return advInt;
}

- (void) setAdvInt: (BOOL) flag
{
	advInt = flag;
}


- (BOOL) alert
{
	
    return alert;
}

- (void) setAlert: (BOOL) flag
{
	alert = flag;
}


- (BOOL) shadowDis
{
	
    return shadowDis;
}

- (void) setShadowDis: (BOOL) flag
{
	shadowDis = flag;
}


- (NSString *) customByte1
{
    return customByte1; 
}

- (void) setCustomByte1: (NSString *) inCustomByte1
{
    if (customByte1 != inCustomByte1) {
        [customByte1 autorelease];
        customByte1 = [inCustomByte1 retain];
    }
}


- (NSString *) customByte2
{
    return customByte2; 
}

- (void) setCustomByte2: (NSString *) inCustomByte2
{
    if (customByte2 != inCustomByte2) {
        [customByte2 autorelease];
        customByte2 = [inCustomByte2 retain];
    }
}

- (BOOL) useEEPROM
{
	
    return useEEPROM;
}

- (void) setUseEEPROM: (BOOL) flag
{
	useEEPROM = flag;
}


- (void) encodeWithCoder: (NSCoder *)coder 
{
	[coder encodeInt: range forKey: @"range"];
	[coder encodeInt: bandwidth forKey: @"bandwidth"];
	[coder encodeInt: counterLG forKey: @"counterLG"];
	[coder encodeBool: enableLG forKey: @"enableLG"];
	[coder encodeInt: hystLG forKey: @"hystLG"];
	[coder encodeObject: durationLG forKey: @"durationLG"];
	[coder encodeObject: thresholdLG forKey: @"thresholdLG"];
	[coder encodeBool: enableHG forKey: @"enableHG"];
	[coder encodeInt: counterHG forKey: @"counterHG"];
	[coder encodeInt: hystHG forKey: @"hystHG"];
	[coder encodeObject: durationHG forKey: @"durationHG"];
	[coder encodeObject: thresholdHG forKey: @"thresholdHG"];
	[coder encodeBool: enableAnyMotion forKey: @"enableAnyMotion"];
	[coder encodeInt: anyMotionDuration forKey: @"anyMotionDuration"];
	[coder encodeObject: anyMotionThreshold forKey: @"anyMotionThreshold"];
	[coder encodeBool: latchInt forKey: @"latchInt"];
	[coder encodeBool: newDataInt forKey: @"newDataInt"];
	[coder encodeBool: advInt forKey: @"advInt"];
	[coder encodeBool: alert forKey: @"alert"];
	[coder encodeBool: shadowDis forKey: @"shadowDis"];
	[coder encodeObject: customByte1 forKey: @"customByte1"];
	[coder encodeObject: customByte2 forKey: @"customByte2"];
	[coder encodeBool: useEEPROM forKey: @"useEEPROM"];
}

- (id) initWithCoder: (NSCoder *)coder 
{
    if ([super init]) {
        range = [coder decodeIntForKey: @"range"];
        bandwidth = [coder decodeIntForKey: @"bandwidth"];
        counterLG = [coder decodeIntForKey: @"counterLG"];
        enableLG = [coder decodeBoolForKey: @"enableLG"];
        hystLG = [coder decodeIntForKey: @"hystLG"];
        durationLG = [[coder decodeObjectForKey: @"durationLG"] retain];
        thresholdLG = [[coder decodeObjectForKey: @"thresholdLG"] retain];
        enableHG = [coder decodeBoolForKey: @"enableHG"];
        counterHG = [coder decodeIntForKey: @"counterHG"];
        hystHG = [coder decodeIntForKey: @"hystHG"];
        durationHG = [[coder decodeObjectForKey: @"durationHG"] retain];
        thresholdHG = [[coder decodeObjectForKey: @"thresholdHG"] retain];
        enableAnyMotion = [coder decodeBoolForKey: @"enableAnyMotion"];
        anyMotionDuration = [coder decodeIntForKey: @"anyMotionDuration"];
        anyMotionThreshold = [[coder decodeObjectForKey: @"anyMotionThreshold"] retain];
        latchInt = [coder decodeBoolForKey: @"latchInt"];
        newDataInt = [coder decodeBoolForKey: @"newDataInt"];
        advInt = [coder decodeBoolForKey: @"advInt"];
        alert = [coder decodeBoolForKey: @"alert"];
        shadowDis = [coder decodeBoolForKey: @"shadowDis"];
        customByte1 = [[coder decodeObjectForKey: @"customByte1"] retain];
        customByte2 = [[coder decodeObjectForKey: @"customByte2"] retain];
		useEEPROM = [coder decodeBoolForKey: @"useEEPROM"];
    }
    return self;
}

@end
