//
//  AppController+JWConfig.h
//  JoyWarrior Common
//
//  Created by stefan on 2010-08-30.
//  Copyright 2010 Iwascoding GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "AppController.h"

@class IOHIDDeviceInterface122;

@interface AppController (JWConfig) 

- (BOOL) switchJoyWarriorAtInterface:(IOHIDDeviceInterface122 **)inInterface withProductID:(int)inProductID toRange:(int)inRange andBandwidth:(int)inBandwidth;

@end
