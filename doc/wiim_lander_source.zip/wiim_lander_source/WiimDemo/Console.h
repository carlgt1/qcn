// Wiim API �2006 Eric B.
// http://digitalretrograde.com/projects/wiim/

// May be used and modified freely as long as this message is left intact

// This whole mechanism needs to be replaced

#include <windows.h>
#include <stdio.h>

void odprintf(const char *format, ...);


