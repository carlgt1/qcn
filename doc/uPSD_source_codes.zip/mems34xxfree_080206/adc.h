/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          03/06/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// ADC
//-----------------------------------------------------------------------------
#ifndef ADC_H
#define ADC_H

#include "upsd34xx.h"

//-----------------------------------------------------------------------------
#define ADCPS_VALUE   (u8)(0x01)

//---channel pins---for ADC_Init---
#define ADC_PIN_CH0 0x01
#define ADC_PIN_CH1 0x02
#define ADC_PIN_CH2 0x04
#define ADC_PIN_CH3 0x08
#define ADC_PIN_CH4 0x10
#define ADC_PIN_CH5 0x20
#define ADC_PIN_CH6 0x40
#define ADC_PIN_CH7 0x80

//---channel---for ADC_Read---
#define ADC_CH0 0
#define ADC_CH1 1
#define ADC_CH2 2
#define ADC_CH3 3
#define ADC_CH4 4
#define ADC_CH5 5
#define ADC_CH6 6
#define ADC_CH7 7
  
//-----------------------------------------------------------------------------
void ADC_Init   (u8 channels);
u16  ADC_Read16 (u8 channel);
void ADC_Read   (u8 channel,u8 *dato_hi,u8 *dato_lo);
void ADC_middle (u8 *dato_hi,u8 *dato_lo);

//-----------------------------------------------------------------------------
#endif
