/**
  Simple test program for the C++ MotionNode SDK.

  @file    tools/sdk/cpp/test/test.cpp
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.1

  (C) Copyright GLI Interactive LLC 2007. All rights reserved.

  The coded instructions, statements, computer programs, and/or related
  material (collectively the "Data") in these files contain unpublished
  information proprietary to GLI Interactive LLC, which is protected by
  US federal copyright law and by international treaties.

  The Data may not be disclosed or distributed to third parties, in whole
  or in part, without the prior written consent of GLI Interactive LLC.

  The Data is provided "as is" without express or implied warranty, and
  with no claim as to its suitability for any purpose.
*/
#include <Client.hpp>
#include <LuaConsole.hpp>
#include <File.hpp>
#include <Format.hpp>

#include <fstream>
#include <iostream>
#include <stdexcept>


// Defaults to "127.0.0.1"
const std::string Host = "";
// Port of the Preview data service.
// Use 32078 for sensor data service
// Use 32077 for raw data service.
const unsigned Port = 32079;


int test_Client()
{
  try {
    using MotionNode::SDK::Client;
    using MotionNode::SDK::Format;

    // Open connection to the data server.
    Client client(Host, Port);
    std::cout << "Connected to " << Host << ":" << Port << std::endl;

    if (client.waitForData()) {
      std::size_t sample_count = 0;

      // Read data samples in a loop. This is a blocking call so
      // we can simply wait on an open connection until a data
      // sample comes in.
      Client::data_type data;
      while ((sample_count++ < 100) && client.readData(data)) {
        std::cout << "data(" << data.size() << ") = ";
        //std::copy(
        //  data.begin(), data.end(), std::ostream_iterator<Client::data_type::value_type>(std::cout, " "));

        Format::preview_service_type preview = Format::Preview(data.begin(), data.end());
        if (!preview.empty()) {
          std::cout << Format::PreviewElement::Name << ": " << preview.size();
          for (Format::preview_service_type::iterator itr=preview.begin(); itr!=preview.end(); ++itr) {
            std::cout << " id=" << itr->first;
            Format::PreviewElement::data_type matrix = itr->second.getMatrix(true);
            std::cout << " " << matrix.size();
          }
        }


        Format::sensor_service_type sensor = Format::Sensor(data.begin(), data.end());
        if (!sensor.empty()) {
          std::cout << Format::SensorElement::Name << ": " << sensor.size();

          for (Format::sensor_service_type::iterator itr=sensor.begin(); itr!=sensor.end(); ++itr) {
            //Format::data_type acc = itr->second.getAccelerometer();
            //std::cout << " a=" << acc[0] << " " << acc[1] << " " << acc[2];

            Format::SensorElement::data_type mag = itr->second.getMagnetometer();
            std::cout << " m(" << itr->first << ") = (" << mag[0] << ", " << mag[1] << ", " << mag[2] << ")";
          }
        }


        Format::raw_service_type raw = Format::Raw(data.begin(), data.end());
        if (!raw.empty()) {
          std::cout << Format::RawElement::Name << ": "<< sensor.size();

          for (Format::raw_service_type::iterator itr=raw.begin(); itr!=raw.end(); ++itr) {
            //Format::data_type acc = itr->second.getAccelerometer();
            //std::cout << " a=" << acc[0] << " " << acc[1] << " " << acc[2];

            Format::RawElement::data_type mag = itr->second.getMagnetometer();
            std::cout << " m(" << itr->first << ") = (" << mag[0] << ", " << mag[1] << ", " << mag[2] << ")";

            Format::RawElement e = itr->second;
          }
        }

        std::cout << std::endl;
      }
    } else {
      std::cout << "No current data available, giving up" << std::endl;
    }

  } catch (std::runtime_error & e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }

  return 0;
}

int test_LuaConsole()
{
  try {
    using MotionNode::SDK::Client;
    using MotionNode::SDK::LuaConsole;

    // Connect to the Console data service.
    Client client("", 32075);

    LuaConsole::result_type result = LuaConsole::SendChunk(client, std::string("node.scan() node.start()"));
    if (LuaConsole::Success == result.first) {
      std::cout << result.second;
    } else if (LuaConsole::Continue == result.first) {
      std::cerr << "incomplete Lua chunk: " << result.second << std::endl;
    } else {
      std::cerr << "command failed: " << result.second << std::endl;
    }
  } catch (std::exception & e) {
    std::cerr << e.what() << std::endl;
    return 1;
  }

  return 0;
}

int test_File()
{
  int result = 0;

  try {
    using MotionNode::SDK::File;
    using MotionNode::SDK::Format;

    File file("../../test_data/raw.bin");
    
    Format::RawElement::data_type data(Format::RawElement::Length);
    while (file.readData(data)) {
      // Access the data directly.
      std::copy(
        data.begin(), data.end(),
        std::ostream_iterator<short>(std::cout, " "));
      std::cout << std::endl;


      // Or wrap the data in the associated Format class.
      Format::RawElement element(data);

      // Read the three vector of magnetometer data.
      Format::RawElement::data_type magnetometer = 
        element.getMagnetometer();
    }

  } catch (std::runtime_error & e) {
    std::cerr << e.what() << std::endl;
    result = 1;
  }

  try {
    using MotionNode::SDK::File;
    using MotionNode::SDK::Format;

    File file("../../test_data/sensor.bin");
    
    Format::SensorElement::data_type data(Format::SensorElement::Length);
    while (file.readData(data)) {
      // Access the data directly.
      std::copy(
        data.begin(), data.end(),
        std::ostream_iterator<float>(std::cout, " "));
      std::cout << std::endl;


      // Or wrap the data in the associated Format class.
      Format::SensorElement element(data);

      // Read the three vector of magnetometer data.
      Format::SensorElement::data_type magnetometer = 
        element.getMagnetometer();
    }

  } catch (std::runtime_error & e) {
    std::cerr << e.what() << std::endl;
    result = 1;
  }

  return result;
}

int main(int argc, char * argv[])
{
  test_LuaConsole();
  test_Client();
  test_File();

  return 0;
}
