/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          14/11/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
MICRO:         uPSD34xx
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// MAIN for MEMS
//-----------------------------------------------------------------------------
#include "upsd34xx.h"
#include "board.h"
#include "adc.h"
#include "flash.h"
#include "i2c.h"
#include "lis.h"
#include "timer0.h"
#include "timer1.h"
#include "uart0.h"
#include "usb.h"

//-----------------------------------------------------------------------------
#if (COMPILER == KEIL)
  //#pragma optimize(8,size)
  //#pragma SYMBOLS
  #pragma NOAREGS
  xdata PSD_REGS PSD8xx_reg _at_ PSD_REG_ADDR;
#endif

#if (COMPILER == SDCC)
  xdata at PSD_REG_ADDR PSD_REGS PSD8xx_reg;
#endif

//-----------------------------------------------------------------------------
//---your sampling rate---
#define YOUR_FREQ_ON_LINE    40
#define YOUR_FREQ_OFF_LINE   40

//---type---
#define TYPE_UNDEFINED      0x11
#define TYPE_DIGITAL_MEMS   0x22
#define TYPE_ANALOG_MEMS    0x33
#define TYPE_TEST_VALUES    0x44

//---onff_state---
#define STATE_ON            0x11
#define STATE_OFF           0x22

//-----------------------------------------------------------------------------
extern xdata u8 usb_mode;
xdata t_mems_data mems_data = {0,0,0,0,0,0};
xdata t_mems_regs mems_regs = {0,0,0,0,0,0,0,0};
xdata u8  onoff_state = STATE_OFF;
xdata u32 fsx_index = 0;
xdata u32 fsx_lin_max = 0;
xdata u8 type = TYPE_UNDEFINED;

//-----------------------------------------------------------------------------
void MEMS_TestValues (t_mems_data *mems_data)
{
  extern t_fs fs;

  mems_data->outx_h = 0;
  mems_data->outx_l = (u8) TIMER0_Read_Rtc ();
  mems_data->outy_h = 0;
  mems_data->outy_l = (u8)(fsx_index / (u32)FSx_SIZE);
  mems_data->outz_h = 0;
  mems_data->outz_l = (u8)(fsx_index);
  LEDx_toggle (LED5,5);
}

//-----------------------------------------------------------------------------
void MEMS_Digital_On_Line (void)
{
  UsbInitialize();
  while (usb_mode == USB_INICIALIZATING);
  Time_Delay (DELAY_250MS);
  I2C_Init ();
  LIS_Init ();
  TIMER0_Init_Mode1 (FREQ_TIMERS/YOUR_FREQ_ON_LINE,1);
  LEDs_Off();

  while (1)
  {
    //---wait---
    while (!TIMER0_Read_Flag());
    LEDx_toggle (LED0,1);
    LEDx_toggle (LED7,10);

    if (BUT7)
    {
      //---mems_regs---
      (void) i2c_read_reg (kLIS3L02DQ_SLAVE_ADDR, OFFSET_X+REPETIR, 12);    
       LIS_Read_Out_Regs (&mems_regs);
       USB_Send_Frame1 (YOUR_FREQ_ON_LINE,&mems_regs);
    } else {
      //---mems_data---
      (void) i2c_read_reg (kLIS3L02DQ_SLAVE_ADDR, OUTX_L+REPETIR, 6);          
      LIS_Read_Out_Data (&mems_data);
      USB_Send_Frame2 (&mems_data);
    }

  } //end of while
}

//-----------------------------------------------------------------------------
void MEMS_Analog_On_Line (void)
{
  UsbInitialize();
  while (usb_mode == USB_INICIALIZATING);
  Time_Delay (DELAY_250MS);
  LIS_Init_Analog ();
  ADC_Init (ADC_PIN_CH2|ADC_PIN_CH3|ADC_PIN_CH4);
  TIMER0_Init_Mode1 (FREQ_TIMERS/YOUR_FREQ_ON_LINE,1);
  LEDs_Off();

  while (1)
  {
    //---wait---
    while (!TIMER0_Read_Flag());
    LEDx_toggle (LED0,1);
    LEDx_toggle (LED7,10);

    //---mems_data---
    ADC_Read (ADC_CH2,&(mems_data.outx_h),&(mems_data.outx_l));
    ADC_Read (ADC_CH3,&(mems_data.outy_h),&(mems_data.outy_l));
    ADC_Read (ADC_CH4,&(mems_data.outz_h),&(mems_data.outz_l));
    ADC_middle (&(mems_data.outx_h),&(mems_data.outx_l));
    ADC_middle (&(mems_data.outy_h),&(mems_data.outy_l));
    ADC_middle (&(mems_data.outz_h),&(mems_data.outz_l));
    USB_Send_Frame2 (&mems_data);

  } //end of while
}

//-----------------------------------------------------------------------------
void MEMS_Off_Line (void)
{
  xdata u16 your_freq_off_line = YOUR_FREQ_OFF_LINE;

  fsx_index   = 0;
  onoff_state = STATE_OFF;

  if (type == TYPE_DIGITAL_MEMS)
  {
    I2C_Init ();
    LIS_Init ();
  }

  if (type == TYPE_ANALOG_MEMS)
  {
    LIS_Init_Analog ();
    ADC_Init (ADC_PIN_CH2|ADC_PIN_CH3|ADC_PIN_CH4);
  }

  Flash_Erase_Pages ();
  TIMER0_Init_Mode1 (FREQ_TIMERS/YOUR_FREQ_OFF_LINE,1);
  LEDs_Off();

  while (1)
  {
    //---wait---
    while (!TIMER0_Read_Flag())
      SetBit(PCON,IDLE);
    LEDx_toggle (LED0,1);
    LEDx_toggle (LED7,10);

    //---START MEASURE???---
    if (BUT6)
    {
      onoff_state = STATE_ON;
      continue;
    }

    //---STOP MEASURE???---
    if (BUT5 || (fsx_index >= fsx_lin_max))
    {
      onoff_state = STATE_OFF;
      LEDx_Off(LED5);
      continue;
    }

    //---CHANGE TIMER FREQUENCY???---
    if (BUT7 && (onoff_state == STATE_OFF))
    {
      your_freq_off_line *= 4;

      if (your_freq_off_line > (4*YOUR_FREQ_OFF_LINE))
        your_freq_off_line = YOUR_FREQ_OFF_LINE;

      TIMER0_Init_Mode1 ((u16)((u32)FREQ_TIMERS/(u32)your_freq_off_line),1);
      while (BUT7);
    }

    //---DO MEASUREMENT???---
    if (onoff_state == STATE_ON)
    {

      //---DIGITAL???---
      if (type == TYPE_DIGITAL_MEMS)
      {
        (void) i2c_read_reg (kLIS3L02DQ_SLAVE_ADDR, OUTX_L+REPETIR, 6);          
        LIS_Read_Out_Data (&mems_data);
      }

      //---ANALOG???---
      if (type == TYPE_ANALOG_MEMS)
      {
        ADC_Read (ADC_CH2,&(mems_data.outx_h),&(mems_data.outx_l));
        ADC_Read (ADC_CH3,&(mems_data.outy_h),&(mems_data.outy_l));
        ADC_Read (ADC_CH4,&(mems_data.outz_h),&(mems_data.outz_l));
        ADC_middle (&(mems_data.outx_h),&(mems_data.outx_l));
        ADC_middle (&(mems_data.outy_h),&(mems_data.outy_l));
        ADC_middle (&(mems_data.outz_h),&(mems_data.outz_l));
      }

      //---USE TEST VALUES---
      if (type == TYPE_TEST_VALUES)
        MEMS_TestValues (&mems_data);

      //---FLASH MEMS DATA---
      if (fsx_index < fsx_lin_max)
      {
        FLASH_Write_Byte (fsx_index++, mems_data.outx_l);
        FLASH_Write_Byte (fsx_index++, mems_data.outx_h);
        FLASH_Write_Byte (fsx_index++, mems_data.outy_l);
        FLASH_Write_Byte (fsx_index++, mems_data.outy_h);
        FLASH_Write_Byte (fsx_index++, mems_data.outz_l);
        FLASH_Write_Byte (fsx_index++, mems_data.outz_h);
      }
    }

  } //end of while
} 

//-----------------------------------------------------------------------------
void MEMS_Read_Out (void)
{
  fsx_index   = 0;
  onoff_state = STATE_OFF;
  UsbInitialize();
  while (usb_mode == USB_INICIALIZATING);
  Time_Delay (DELAY_250MS);
  TIMER0_Init_Mode1 (FREQ_TIMERS/YOUR_FREQ_ON_LINE,1);
  LEDs_Off();

  while (1)
  {
    //---wait---
    while (!TIMER0_Read_Flag());
    LEDx_toggle (LED0,1);
    LEDx_toggle (LED7,10);

    //---START SEND DATA???---
    if (BUT5)
    {
      onoff_state = STATE_ON;
      continue;
    }

    //---STOP MEASURE???---
    /*
    if (BUT6)
    {
      onoff_state = STATE_OFF;
      LEDx_Off(LED6); //USB off
      continue;
    }
    */

    //---READ-OUT DATA???---
    if (onoff_state == STATE_ON)
    {
      if (BUT7)
      {
        //---mems_regs---
         USB_Send_Frame1 (YOUR_FREQ_OFF_LINE,&mems_regs);
      } else {
        //---mems_data---
        if (fsx_index < fsx_lin_max)
        {
          FLASH_Read_Byte (fsx_index++, &mems_data.outx_l);
          FLASH_Read_Byte (fsx_index++, &mems_data.outx_h);
          FLASH_Read_Byte (fsx_index++, &mems_data.outy_l);
          FLASH_Read_Byte (fsx_index++, &mems_data.outy_h);
          FLASH_Read_Byte (fsx_index++, &mems_data.outz_l);
          FLASH_Read_Byte (fsx_index++, &mems_data.outz_h);
        } else {
          mems_data.outx_l = 0xFF;
          mems_data.outx_h = 0xFF;
          mems_data.outy_l = 0xFF;
          mems_data.outy_h = 0xFF;
          mems_data.outz_l = 0xFF;
          mems_data.outz_h = 0xFF;
        }
        USB_Send_Frame2 (&mems_data);
      } //end of Button7
    }

  } //end of while
}

//-----------------------------------------------------------------------------
void main (void)
{
  uPSD_Init ();
  LEDs_On();
//fsx_lin_max = FLASH_Space (0x8000, 0xBFFF, 8); //uPSD3433, 128kB
  fsx_lin_max = FLASH_Space (0x8000, 0xFFFF, 8); //uPSD3434, 256kB

  //---CHECK MEMS TYPE---
  P3_3 = 1; Time_Delay (15);
  if (P3_3 == 1)
    type = TYPE_DIGITAL_MEMS;
  else
    type = TYPE_ANALOG_MEMS;

  //---ON-LINE MEASUREMENT---
  if (!BUT5 && !BUT6 && !BUT7 && (type == TYPE_DIGITAL_MEMS))
    MEMS_Digital_On_Line ();

  if (!BUT5 && !BUT6 && !BUT7 && (type == TYPE_ANALOG_MEMS))
    MEMS_Analog_On_Line ();

  //---OFF-LINE MEASUREMENT---
  if(BUT5 && !BUT6 && !BUT7)
    MEMS_Off_Line ();

  //---OFF-LINE MEASUREMENT---
  if(BUT5 && !BUT6 && BUT7)
  {
    type = TYPE_TEST_VALUES;
    MEMS_Off_Line ();
  }

  //---READ-OUT DATA---
  if(!BUT5 && BUT6 && !BUT7)
    MEMS_Read_Out ();

  //---TEST BOARD---
  if(!BUT5 && !BUT6 && BUT7)
    TestBoard1 ();

}

//-----------------------------------------------------------------------------
