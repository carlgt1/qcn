/* MyController */

#import <Cocoa/Cocoa.h>
#import "HID_Utilities_External.h"

#define kDeviceTypeNone 0
#define kDeviceTypeJoyWarriorA8	1
#define kDeviceTypeJoyWarriorA16 2
#define kDeviceTypeJoyWarriorF8 3
#define kDeviceTypeMouseWarrior24J8	4

@interface MyController : NSObject
{
	pRecDevice	device;
	int			currentDeviceType;
	BOOL		currentDeviceGood;
	
	NSTimer		*eventTimer;
	
	IBOutlet NSView *mainWindowContentView;
	IBOutlet NSTextField *statusField;
}

- (OSStatus) armNotificationsForVendor:(int) inVendorID device:(int) inDeviceID usingPort:(mach_port_t) inPort;

- (IBAction)resetAction:(id)sender;
- (IBAction) resetDeviceCounterAction:(id) sender;

- (void) toggleButtonVisibilities;

- (void) updateStatusField;
- (void) discoverDevice;
- (void) reset;
- (int) armUSBNotifications;


- (NSView*) buttonViewWithTag:(int) inTag;
- (BOOL) currentDevicePassedTest;

- (void) setDevice:(pRecDevice) inDevice ofType:(int) inDeviceType;

- (void) eventReceived:(IOHIDEventStruct*) inEvent;

/*" Device Counter Management "*/
- (void) incrementDeviceCounter;
- (void) resetDeviceCounter;

@end
