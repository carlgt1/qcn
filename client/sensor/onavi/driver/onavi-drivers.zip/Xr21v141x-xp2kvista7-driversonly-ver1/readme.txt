11/23/2010	

This driver is for the XR21x141x USB UART product family.  This driver has been WHQL certified for XP/2K/Vista/7 and is version 1.6.0.0.  

This zip file includes both 32-bit and 64-bit drivers. 

The "x64" folder contains the 64-bit driver for 64-bit systems.
The "x86" folder contains the 32-bit driver for 32-bit systems.

For driver source code, please send an e-mail request to uarttechsupport@exar.com.  The Software License Agreement (SLA) will be sent to you 
for review.  Once the SLA is complete, the driver source code will be sent to you. 


Revision History (Rev. 1.5 to 1.6):
 - Creating Symbolic link has been updated. This makes sure the Com is opened without any failure 
   even after the device is unplugged and plugged back.
 - Surprise removal portion is updated to avoid some potential issues when the port is closed 
   after the device is unplugged.

Revision History (Rev. 1.4 to 1.5):

 - Support for custom VID/PID - If OEMs want to use xrusbser.sys as is, they need to make sure
   XR21v1410/1412/1414 has even DID and XR21B1411 has odd DID. Otherwise different registers
   are programmed and the operation can not be guaranteed.

 - Fixed the bug that would have crashed the system if the driver is loaded for a phantom device 
   that was not uninstalled/installed properly.

 - IOCTL_SERIAL_GET_MODEMSTATUS now returns the live status of GPIO (reverted back to 1.2 logic). 


Revision History (Rev. 1.3 to 1.4):

 - Support for XR21B1411.

 - WriteTimeout is implemented.

Revision History (Rev. 1.2 to 1.3):

- Improved data throughput to approximately 9Mbps

- Fixed default state of RTS# and DTR# pins

- Fix the usb 2.0 hub issue	

- Changes in calculating serialstate in interrupt endpoint.