/*
	File:		main.c
				HID Explorer

	Contains:	Source file for Hid Explorer
    
	DRI: George Warner

	Copyright:	Copyright � 2002 Apple Computer, Inc., All Rights Reserved

	Disclaimer:	IMPORTANT:  This Apple software is supplied to you by Apple Computer, Inc.
				("Apple") in consideration of your agreement to the following terms, and your
				use, installation, modification or redistribution of this Apple software
				constitutes acceptance of these terms.  If you do not agree with these terms,
				please do not use, install, modify or redistribute this Apple software.

				In consideration of your agreement to abide by the following terms, and subject
				to these terms, Apple grants you a personal, non-exclusive license, under Apple�s
				copyrights in this original Apple software (the "Apple Software"), to use,
				reproduce, modify and redistribute the Apple Software, with or without
				modifications, in source and/or binary forms; provided that if you redistribute
				the Apple Software in its entirety and without modifications, you must retain
				this notice and the following text and disclaimers in all such redistributions of
				the Apple Software.  Neither the name, trademarks, service marks or logos of
				Apple Computer, Inc. may be used to endorse or promote products derived from the
				Apple Software without specific prior written permission from Apple.  Except as
				expressly stated in this notice, no other rights or licenses, express or implied,
				are granted by Apple herein, including but not limited to any patent rights that
				may be infringed by your derivative works or by other works in which the Apple
				Software may be incorporated.

				The Apple Software is provided by Apple on an "AS IS" basis.  APPLE MAKES NO
				WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
				WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
				PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
				COMBINATION WITH YOUR PRODUCTS.

				IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
				CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
				GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
				ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION
				OF THE APPLE SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF CONTRACT, TORT
				(INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF APPLE HAS BEEN
				ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifdef __APPLE_CC__
	#include <Carbon/Carbon.h>
	#include <IOKit/HID/IOHIDKeys.h>

	#include "HID_Utilities_External.h"
#else
	#include <CarbonEvents.h>
	#include <Controls.h>
	#include <string.h>

	#include "HID_Utilities_CFM.h" // includes HID_Utilities_External.h
#endif

// ==================================

// local function declarations

static void SetElementTypeText (WindowRef window, SInt32 id, pRecElement pElement);
static void SetDeviceUsageText (WindowRef window, SInt32 id, pRecDevice pDevice);
static void SetElementUsageText (WindowRef window, SInt32 id, pRecElement pElement);
static void SetDeviceText (WindowRef window, SInt32 id, pRecDevice pDevice);
static void SetControlText (WindowRef window, SInt32 id, char * text);
static void SetControlTextFromValue (WindowRef window, SInt32 id, long value);
static void SetControlCheck (WindowRef window, SInt32 id, Boolean value);
static long GetCurrentDeviceNum (WindowRef window);
static pRecDevice GetSetCurrentDevice (WindowPtr window);
static pRecElement GetSetCurrentElement (WindowPtr window);
static void ReplaceControlMenu (WindowRef window, SInt32 id, MenuRef refMenu);
static void BuildControlMenu (WindowRef window, SInt32 id, Str255 textList[], short numItems);
static void BuildDeviceMenu (WindowRef window);
static long CountSiblings (pRecElement pElement);
static void GetElementName (pRecElement pElement, StringPtr pstrElementName);
static pRecElement GetParent (pRecElement pElementChild);
static void SetElementTitle (WindowPtr window);
static MenuRef BuildElementMenuLevel (WindowRef window, pRecElement pElement, ConstStr255Param menuTitle);
static void BuildElementMenu (WindowRef window);
static void HandleWindowUpdate (WindowRef window);
static void BuildAppDeviceList (WindowRef window);
static void DrawScaleGraphic (Rect * prectControl, SInt32 value, SInt32 min, SInt32 max, pRecElement pElement, Boolean showMinMax);
static void DisplayCurrentDeviceElementValue (void);
static pascal void IdleTimer (EventLoopTimerRef inTimer, void* userData);
static EventLoopTimerUPP GetTimerUPP (void);
static pascal OSStatus myWinEvtHndlr(EventHandlerCallRef myHandler, EventRef event, void* userData);

// ==================================

EventHandlerUPP gAppCommandProcess;  	// Command-process event handler
EventHandlerUPP gWinEvtHandler;		// window event handler

WindowRef gWindow = NULL; // single application window

long gDeviceNum = 1; // current device chosen in menu
void * gElementCookie = NULL; // current element chosen in menu

EventLoopTimerRef gTimer = NULL; // timer for element data updates 

MenuRef gRestoreMenu = NULL;

// ==================================

enum { // control enums from nib 
    kCntlPopUpDevice = 1,
    kCntlBoxDevice,
    kCntlTextTransportDevice,
    kCntlTextVendorIDDevice,
    kCntlTextProductIDDevice,
    kCntlTextVersionDevice,
    kCntlTextManufacturerDevice,
    kCntlTextProductDevice,
    kCntlTextSerialDevice,
    kCntlTextLocationIDDevice,
    kCntlTextUsageDevice,
    
    kCntlPopUpElement,
    kCntlTextTypeElement,
    kCntlTextUsageElement,
    kCntlTextCookieElement,
    kCntlTextRangeElement,
    kCntlTextScaledRangeElement,
    kCntlTextSizeElement,
    kCntlCheckRelativeElement,
    kCntlCheckWrappingElement,
    kCntlCheckNonLinearElement,
    kCntlCheckPreferredStateElement,
    kCntlCheckNullStateElement,
    kCntlTextVendorSpecificElement,
    kCntlTextUnitsElement,
    kCntlTextNameElement,
    
    kCntlTextRawValueElement,
    kCntlUserRawValueGraphicElement,

    kCntlCheckCalibrateElement,
    kCntlTextCalibrateValueElement,
    kCntlUserCalibrateValueGraphicElement,

    kCntlCheckScaleElement,
    kCntlTextScaleValueElement,
    kCntlUserScaleValueGraphicElement,
	kCntlBoxElement,
    
    kNumControlsPlus1
};

// ==================================

// sets control text for specific type of element

static void SetElementTypeText (WindowRef window, SInt32 id, pRecElement pElement)
{
    ControlID idControl;
    ControlRef control;
    char cstrElementName [256];
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    GetControlByID (window, &idControl, &control);
	
	HIDGetTypeName (pElement->type, cstrElementName);
	sprintf(cstrElementName, "%s (0x%lx)", cstrElementName, pElement->type); // add number to end
    SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (cstrElementName), cstrElementName);
}

// ---------------------------------
// sets control text for device usage from usage page and usage

static void SetDeviceUsageText (WindowRef window, SInt32 id, pRecDevice pDevice)
{
    ControlID idControl;
    ControlRef control;
    char cstrDeviceName [256];
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    GetControlByID (window, &idControl, &control);
    // set element text
    HIDGetUsageName (pDevice->usagePage, pDevice->usage, cstrDeviceName);
    sprintf (cstrDeviceName, "%s (0x%lx, 0x%lx)", cstrDeviceName, pDevice->usagePage, pDevice->usage);
    SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (cstrDeviceName), cstrDeviceName);
}

// ---------------------------------
// sets control text for element usage from usage page and usage

static void SetElementUsageText (WindowRef window, SInt32 id, pRecElement pElement)
{
    ControlID idControl;
    ControlRef control;
    char cstrElementName [256];
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    GetControlByID (window, &idControl, &control);
    // set element text
    HIDGetUsageName (pElement->usagePage, pElement->usage, cstrElementName);
    sprintf (cstrElementName, "%s (0x%lx, 0x%lx)", cstrElementName, pElement->usagePage, pElement->usage);
    SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (cstrElementName), cstrElementName);
}

// ---------------------------------
// sets control text for general device type and count of elements
// sets the box title as needed for particular device

static void SetDeviceText (WindowRef window, SInt32 id, pRecDevice pDevice)
{
    ControlID idControl;
    ControlRef control;
    char cstrDeviceName [256] = "No Device";
	Str255 pstrDeviceName;
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    GetControlByID (window, &idControl, &control);
    // set device text
	if (pDevice)
	{
		HIDGetUsageName (pDevice->usagePage, pDevice->usage, cstrDeviceName);
		if (pDevice->axis == 1)
			sprintf (cstrDeviceName, "%s, %ld Axis", cstrDeviceName, pDevice->axis);
			
		if (pDevice->buttons == 1)
			sprintf (cstrDeviceName, "%s, %ld Button", cstrDeviceName, pDevice->buttons);
		else if (pDevice->buttons > 1)
			sprintf (cstrDeviceName, "%s, %ld Buttons", cstrDeviceName, pDevice->buttons);
			
		if (pDevice->hats)
			sprintf (cstrDeviceName, "%s, %ld Hat", cstrDeviceName, pDevice->hats);
		else if (pDevice->hats > 1)
			sprintf (cstrDeviceName, "%s, %ld Hats", cstrDeviceName, pDevice->hats);
			
		if (pDevice->sliders)
			sprintf (cstrDeviceName, "%s, %ld Slider", cstrDeviceName, pDevice->sliders);
		else if (pDevice->sliders > 1)
			sprintf (cstrDeviceName, "%s, %ld Sliders", cstrDeviceName, pDevice->sliders);
			
		if (pDevice->dials)
			sprintf (cstrDeviceName, "%s, %ld Dial", cstrDeviceName, pDevice->dials);
		else if (pDevice->dials > 1)
			sprintf (cstrDeviceName, "%s, %ld Dials", cstrDeviceName, pDevice->dials);
			
		if (pDevice->wheels)
			sprintf (cstrDeviceName, "%s, %ld Wheel", cstrDeviceName, pDevice->wheels);
		else if (pDevice->wheels > 1)
			sprintf (cstrDeviceName, "%s, %ld Wheels", cstrDeviceName, pDevice->wheels);
	}
	CopyCStringToPascal (cstrDeviceName, pstrDeviceName);
	SetControlTitle (control, pstrDeviceName);
}

// ---------------------------------
// sets static text control of id to text

static void SetControlText (WindowRef window, SInt32 id, char * text)
{
    ControlID idControl;
    ControlRef control;
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    GetControlByID (window, &idControl, &control);
    SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
}

// ---------------------------------
// sets static text control of id to string representation of value

static void SetControlTextFromValue (WindowRef window, SInt32 id, long value)
{
    ControlID idControl;
    ControlRef control;
    char text [256];
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    GetControlByID (window, &idControl, &control);
    sprintf (text, "%ld", value);
    SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
}

// ---------------------------------
// sets a check box control of id based on value

static void SetControlCheck (WindowRef window, SInt32 id, Boolean value)
{
    ControlID idControl;
    ControlRef control;
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    GetControlByID (window, &idControl, &control);
    SetControlValue (control, value);
}

// ---------------------------------
// gets current device number based on control value (which menu item is selected)

static long GetCurrentDeviceNum (WindowRef window)
{
    ControlID idControl;
    ControlRef control;
    idControl.signature = 'hidm';
    idControl.id = kCntlPopUpDevice; 
    GetControlByID (window, &idControl, &control);
    return GetControlValue (control);
}

// ---------------------------------
// gets current device pointer
// side effect is that if the curretn device number is not in the list then it slects the first device
// still can return NULL if no devices are plugged

static pRecDevice GetSetCurrentDevice (WindowPtr window)
{
	short i;
    pRecDevice pCurrentHIDDevice = HIDGetFirstDevice ();
	gDeviceNum = GetCurrentDeviceNum (window);		
    for (i = 1; i < gDeviceNum; i++)
        pCurrentHIDDevice = HIDGetNextDevice (pCurrentHIDDevice);
	if (NULL == pCurrentHIDDevice)
		pCurrentHIDDevice = HIDGetFirstDevice ();
	return pCurrentHIDDevice;
}

// ---------------------------------
// returns a pointer to the element currently selected by the user
// it also validates this and has the side effect of reseting the curretn element if invalid (like a device changed out from under us)

static pRecElement GetSetCurrentElement (WindowPtr window)
{
    pRecDevice pCurrentHIDDevice = GetSetCurrentDevice (window);
    pRecElement pCurrentHIDElement = NULL;
    
    if (NULL == pCurrentHIDDevice) // if there are no devices
    {
		gElementCookie = NULL;
        return NULL;
    }
	pCurrentHIDElement =  HIDGetFirstDeviceElement (pCurrentHIDDevice, kHIDElementTypeIO);
	// use gElementCookie to find current element
    while (pCurrentHIDElement && (pCurrentHIDElement->cookie != gElementCookie))
        pCurrentHIDElement = HIDGetNextDeviceElement (pCurrentHIDElement, kHIDElementTypeAll);
	if (pCurrentHIDElement == NULL)
	{
		pCurrentHIDElement = HIDGetFirstDeviceElement (pCurrentHIDDevice, kHIDElementTypeIO); // get first non-collection
		gElementCookie = pCurrentHIDElement->cookie;
	}
	return pCurrentHIDElement;
}

// ---------------------------------
// replaces current control menu
// if the one being replaced is the first then it stores it for later replacement
// otherwise it deletes the menu since it was something had previously been used to replace the menu

static void ReplaceControlMenu (WindowRef window, SInt32 id, MenuRef refMenu)
{
    MenuHandle hMenu;
    Size tempSize;
    // get menu
    ControlID idControl;
    ControlRef control;
    OSStatus err = noErr;
	Rect bounds;
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    err = GetControlByID (window, &idControl, &control);
	err = GetControlData (control, kControlMenuPart, kControlPopupButtonMenuHandleTag, sizeof (MenuHandle), &hMenu, &tempSize);
	err = SetControlData (control, kControlMenuPart, kControlPopupButtonMenuHandleTag, sizeof (MenuHandle), &refMenu);
 	if (gRestoreMenu)
		DisposeMenu (hMenu);
	else 
		gRestoreMenu  = hMenu; // save orginal menu
    // force update of menu extents
    SetControlMaximum (control, CountMenuItems (refMenu));
	SetControlValue (control, 1);               
	InvalWindowRect (window, GetWindowPortBounds (window, &bounds)); // ensure window is redrawn correctly with menu change
}

// ---------------------------------
// builds menu of id, based on text list of numitems number of strings

static void BuildControlMenu (WindowRef window, SInt32 id, Str255 textList[], short numItems)
{
    MenuHandle hMenu;
    Size tempSize;
    // get menu
    ControlID idControl;
    ControlRef control;
    short i;
    OSStatus err = noErr;
	Rect bounds;
    
    idControl.signature = 'hidm';
    idControl.id = id; 
    err = GetControlByID (window, &idControl, &control);
    err = GetControlData (control, kControlMenuPart, kControlPopupButtonMenuHandleTag, sizeof (MenuHandle), &hMenu, &tempSize);
    // remove all items
    err = DeleteMenuItems (hMenu, 1, CountMenuItems (hMenu));
    // add new items
    for (i = 0; i < numItems; i++)
        AppendMenu (hMenu, textList[i]);
    // force update of menu extents
    SetControlMaximum (control, numItems);
    if (id == kCntlPopUpDevice)
    {
        if (gDeviceNum > numItems)
            gDeviceNum = 1;
        SetControlValue (control, gDeviceNum);               
    }
    else if (id == kCntlPopUpElement) // can reach here on errors
         SetControlValue (control, 1);               
	InvalWindowRect (window, GetWindowPortBounds (window, &bounds)); // ensure window is redrawn correctly with menu change
}

// ---------------------------------
// builds menu of devices

static void BuildDeviceMenu (WindowRef window)
{
    pRecDevice pHIDDevice = HIDGetFirstDevice ();
	char cstr[256];
	if (NULL != pHIDDevice)
	{
		short j;
		Str255 * apstrtextMenu = (Str255 *) NewPtr (sizeof (Str255) * HIDCountDevices ());
		for (j = 1; j <= HIDCountDevices (); j++)
		{
			if (*(pHIDDevice->product))
			{
				BlockMoveData (pHIDDevice->product, cstr, 256);
				CopyCStringToPascal (cstr, apstrtextMenu [j - 1]);
			}
			else
			{
				HIDGetUsageName (pHIDDevice->usagePage, pHIDDevice->usage, (char *) apstrtextMenu [j - 1]); // use pascal string array as temp c string buffer
				if (*(apstrtextMenu [j - 1])) // if usage
				{
					sprintf (cstr, "%s %d", apstrtextMenu [j - 1], j);
					CopyCStringToPascal (cstr, apstrtextMenu [j - 1]);
				}
				else // no usage
				{
					sprintf (cstr, "Device %d", j);
					CopyCStringToPascal (cstr, apstrtextMenu [j - 1]);
				}
			}
			pHIDDevice = HIDGetNextDevice (pHIDDevice);
		}
		BuildControlMenu (window, kCntlPopUpDevice, apstrtextMenu, HIDCountDevices ());
		DisposePtr ((Ptr) apstrtextMenu);
	}
	else
	{
		Str255 strTextMenu = "\pNo HID Devices Found";
		BuildControlMenu (window, kCntlPopUpDevice, &strTextMenu, 1);
	}
}

// ---------------------------------
// counts number of siblings down stream from current element
// does not count current element and does not count elements above curretn element

static long CountSiblings (pRecElement pElement)
{
	long numSibs = 0;
	while (pElement)	
	{
		pElement = pElement->pSibling;
		numSibs++;
	}
	return numSibs - 1;
}

// ---------------------------------
// Forms the nice name of an element

static void GetElementName (pRecElement pElement, StringPtr pstrElementName)
{
	char cstr[256];
	// get name first
	if (*(pElement->name)) {
		BlockMoveData (pElement->name, cstr, 256);
		CopyCStringToPascal (cstr, pstrElementName);
	}	
	else // if no name
	{
		HIDGetUsageName (pElement->usagePage, pElement->usage, cstr);
		if (!*cstr) // if not usage
			sprintf (cstr, "Unnamed Element");
		CopyCStringToPascal (cstr, pstrElementName);
	}
}

// ---------------------------------
// finds the actual parent of the element (the previous element that has a child that is a sibling of this element
// also will only return elements that have siblings to eliminate collection with no siblings on their level

static pRecElement GetParent (pRecElement pElementChild)
{
	pRecElement pElementParent = pElementChild->pPrevious;
	// while there are elements preceeding the element of interest
	while (pElementParent)
	{
		if ((pElementParent->pChild == pElementChild) && 
			((pElementParent->pSibling) || 
			((pElementParent->pPrevious) && (pElementParent->pPrevious->pSibling)))) // if this is really the parent and the parent has siblings
			return pElementParent;
		// get previous element
		pElementChild = pElementParent; 
		pElementParent = pElementChild->pPrevious;
	}
	return NULL;
}

// ---------------------------------
// set the "full path" title for the element box

static void SetElementTitle (WindowPtr window)
{
	ControlID idControl;
    ControlRef control;
    OSStatus err = noErr;
	Rect bounds;
  	Str255 strName = "\pNo element";
	char cstrComposite[256] = "", cstrName[256] = "", cstrPrevious[256] = "";
	Boolean flag = false;
	
    pRecElement pChild = NULL, pCurrentHIDElement = GetSetCurrentElement (window);
    
	// get our current element name
    if (NULL != pCurrentHIDElement)
    {
        GetElementName (pCurrentHIDElement, strName);
        CopyPascalStringToC (strName, cstrPrevious);
        pChild = pCurrentHIDElement; // the previous element (used for menu positioning below)
        pCurrentHIDElement = GetParent (pCurrentHIDElement);
        
        // get full path string for current element
        while (pCurrentHIDElement)
        {
            GetElementName (pCurrentHIDElement, strName);
            CopyPascalStringToC (strName, cstrName);
            sprintf (cstrComposite, "%s/%s", cstrName, cstrPrevious);
            sprintf (cstrPrevious, "%s", cstrComposite);
            pChild = pCurrentHIDElement; // the previous element (used for menu positioning below)
            pCurrentHIDElement = GetParent (pCurrentHIDElement);
        }
        CopyCStringToPascal (cstrPrevious, strName);
	}
    
	// set control title
    idControl.signature = 'hidm';
    idControl.id = kCntlBoxElement; 
    err = GetControlByID (window, &idControl, &control);
	if (noErr == err)
		SetControlTitle(control, strName);
		
	// reset menu to first option and no check
	
    idControl.id = kCntlPopUpElement; 
    err = GetControlByID (window, &idControl, &control);
	if (noErr == err)
	{
		long menuNum = 1;
		pRecElement pListHIDElement = HIDGetFirstDeviceElement (GetSetCurrentDevice (window), kHIDElementTypeAll);
		while (pListHIDElement && (!pListHIDElement->pSibling))
			pListHIDElement = pListHIDElement->pChild;
		// use gElementCookie to find current element
		while (pListHIDElement && (pListHIDElement->cookie != pChild->cookie))
		{
			pListHIDElement = pListHIDElement->pSibling;
			menuNum++;
		}
		SetControlValue (control, menuNum);
	}
	flag = false;
	SetControlData (control, kControlMenuPart, kControlPopupButtonCheckCurrentTag, sizeof (flag), &flag);

 	InvalWindowRect (window, GetWindowPortBounds (window, &bounds)); // ensure window is redrawn correctly with menu change
}

// ---------------------------------
// builds a single level of element menu (using all siblings or element passed in)

static MenuRef BuildElementMenuLevel (WindowRef window, pRecElement pElement, ConstStr255Param menuTitle)
{
	short j;
	Str255 strtextMenu;
	short numElements = CountSiblings (pElement) + 1;
	pRecElement pFirstElement = pElement;
	MenuRef refMenu;
	
	if (pElement)
	{
		refMenu = NewMenu (0, menuTitle);
		for (j = 1; j <= numElements; j++)
		{
			GetElementName (pElement, strtextMenu);
			AppendMenu (refMenu, strtextMenu);
			// set commnd id
			SetMenuItemCommandID (refMenu, j, (UInt32) (pElement->cookie));
			pElement = pElement->pSibling;
		}
		// if there are collection then recusively process colelctions
		pElement = pFirstElement;
		for (j = 1; j <= numElements; j++)
		{
			if (pElement->pChild)
			{
				MenuRef refChildMenu;
				GetElementName (pElement, strtextMenu);
				refChildMenu = BuildElementMenuLevel (window, pElement->pChild, strtextMenu);
				SetMenuItemHierarchicalMenu (refMenu, j, refChildMenu);
			}
			pElement = pElement->pSibling;
		}
	}
	else
	{
		Str255 strTextMenu = "\pBad Element List";
		BuildControlMenu (window, kCntlPopUpElement, &strTextMenu, 1);
	}	
	return refMenu;
}

// ---------------------------------
// builds mneu of elements of current device

static void BuildElementMenu (WindowRef window)
{
	char cstr[256];
	pRecDevice pCurrentHIDDevice = GetSetCurrentDevice (window);
	
	if (NULL != pCurrentHIDDevice)
	{
		pRecElement pElement;
		Str255 strtextMenu;
		
		// get device name for menu name
		if (*(pCurrentHIDDevice->product))
		{
			BlockMoveData (pCurrentHIDDevice->product, cstr, 256);
			CopyCStringToPascal (cstr, strtextMenu);
		}
		else
		{
			HIDGetUsageName (pCurrentHIDDevice->usagePage, pCurrentHIDDevice->usage, cstr);
			if (cstr) // if usage
			{
				//sprintf (cstr, "%s", cstr);
				CopyCStringToPascal (cstr, strtextMenu);
			}
			else // no usage
			{
				sprintf (cstr, "Unnamed Device");
				CopyCStringToPascal (cstr, strtextMenu);
			}
		}
			
		// eliminate top level collections
		pElement = HIDGetFirstDeviceElement (pCurrentHIDDevice, kHIDElementTypeAll);
		while (pElement && !CountSiblings (pElement))
		{
			GetElementName (pElement, strtextMenu);
			pElement = pElement->pChild;
		}
		
		if (pElement)
		{
			MenuRef menu = BuildElementMenuLevel (window, pElement, (ConstStr255Param) &strtextMenu);
			ReplaceControlMenu (window, kCntlPopUpElement, menu);
		}
		else
		{
			Str255 strTextMenu = "\pBad Element List";
			BuildControlMenu (window, kCntlPopUpElement, &strTextMenu, 1);
		}	
	}
	else
	{
		Str255 strTextMenu = "\pNo HID Device";
		BuildControlMenu (window, kCntlPopUpElement, &strTextMenu, 1);
	}
}

// ---------------------------------
// updates window contents by setting control values, erasing and redrawing all controls

static void HandleWindowUpdate(WindowRef window)
{
    Rect bounds;
    short i;
    pRecDevice pCurrentHIDDevice = GetSetCurrentDevice (window);
    pRecElement pCurrentHIDElement = GetSetCurrentElement (window);
     
	// will have NULL for device and element if not device list at this point
    for (i = 1; i < kCntlTextRawValueElement; i++)
    {
        switch (i)
        {
            case kCntlPopUpDevice:
                break;
            case kCntlPopUpElement:
                break;
            case kCntlTextTransportDevice:
                if (pCurrentHIDDevice && pCurrentHIDDevice->transport)
                    SetControlText (window, i, pCurrentHIDDevice->transport);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextVendorIDDevice:
                if (pCurrentHIDDevice && pCurrentHIDDevice->vendorID)
                    SetControlTextFromValue (window, i, pCurrentHIDDevice->vendorID);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextProductIDDevice:
                if (pCurrentHIDDevice && pCurrentHIDDevice->productID)
                    SetControlTextFromValue (window, i, pCurrentHIDDevice->productID);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextVersionDevice:
                if (pCurrentHIDDevice && pCurrentHIDDevice->version)
                    SetControlTextFromValue (window, i, pCurrentHIDDevice->version);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextManufacturerDevice:
                if (pCurrentHIDDevice && *(pCurrentHIDDevice->manufacturer))
                    SetControlText (window, i, pCurrentHIDDevice->manufacturer);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextProductDevice:
                if (pCurrentHIDDevice && *(pCurrentHIDDevice->product))
                    SetControlText (window, i, pCurrentHIDDevice->product);
                else
                    SetControlText (window, i, "---");
                break;
             case kCntlTextSerialDevice:
                if (pCurrentHIDDevice && *(pCurrentHIDDevice->serial))
                    SetControlText (window, i, pCurrentHIDDevice->serial);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextLocationIDDevice:
                if (pCurrentHIDDevice && pCurrentHIDDevice->locID)
                    SetControlTextFromValue (window, i, pCurrentHIDDevice->locID);
                else
                    SetControlText (window, i, "---");
                break;
           case kCntlBoxDevice:
				SetDeviceText (window, i, pCurrentHIDDevice);
                 break;
            case kCntlTextUsageDevice:
                if (pCurrentHIDDevice)
                    SetDeviceUsageText (window, i, pCurrentHIDDevice);
                else
                    SetControlText (window, i, "---");
                break;

            case kCntlTextTypeElement:
                if (pCurrentHIDElement)
                    SetElementTypeText (window, i, pCurrentHIDElement);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextUsageElement:
                if (pCurrentHIDElement)
                    SetElementUsageText (window, i, pCurrentHIDElement);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextCookieElement:
                if (pCurrentHIDElement && pCurrentHIDElement->cookie)
                    SetControlTextFromValue (window, i, (long) pCurrentHIDElement->cookie);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextRangeElement:
                if (pCurrentHIDElement && (pCurrentHIDElement->min || pCurrentHIDElement->max))
                {
                    char cstr [256];
                    sprintf (cstr, "%ld to %ld", pCurrentHIDElement->min, pCurrentHIDElement->max);
                    SetControlText (window, i, cstr);
                }
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextScaledRangeElement:
                if (pCurrentHIDElement && (pCurrentHIDElement->scaledMin ||  pCurrentHIDElement->scaledMax))
                {
                    char cstr [256];
                    sprintf (cstr, "%ld to %ld", pCurrentHIDElement->scaledMin, pCurrentHIDElement->scaledMax);
                    SetControlText (window, i, cstr);
                }
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlTextSizeElement:
                if (pCurrentHIDElement && pCurrentHIDElement->size)
                    SetControlTextFromValue (window, i, pCurrentHIDElement->size);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlCheckRelativeElement:
                if (pCurrentHIDElement)
                    SetControlCheck (window, i, pCurrentHIDElement->relative);
                else
                    SetControlText (window, i, "---");
                break;
            case kCntlCheckWrappingElement:
                if (pCurrentHIDElement)
                    SetControlCheck (window, i, pCurrentHIDElement->wrapping);
                else
                    SetControlCheck (window, i, false);                    
                break;
            case kCntlCheckNonLinearElement:
                if (pCurrentHIDElement)
                    SetControlCheck (window, i, pCurrentHIDElement->nonLinear);
                else
                    SetControlCheck (window, i, false);                    
                break;
            case kCntlCheckPreferredStateElement:
                if (pCurrentHIDElement)
                    SetControlCheck (window, i, pCurrentHIDElement->preferredState);
                 else
                    SetControlCheck (window, i, false);                    
               break;
            case kCntlCheckNullStateElement:
                if (pCurrentHIDElement)
                    SetControlCheck (window, i, pCurrentHIDElement->nullState);
                else
                    SetControlCheck (window, i, false);                    
                break;
            case kCntlTextUnitsElement:
                if (pCurrentHIDElement && (pCurrentHIDElement->units || pCurrentHIDElement->unitExp))
                {
                    char cstr [256];
                    sprintf (cstr, "%ld x 10^%ld", pCurrentHIDElement->units, pCurrentHIDElement->unitExp);
                    SetControlText (window, i, cstr);
                }
                else
                    SetControlText (window, i, "---");
               break;
            case kCntlTextNameElement:
                if (pCurrentHIDElement && *(pCurrentHIDElement->name))
                    SetControlText (window, i, pCurrentHIDElement->name);
                else
                    SetControlText (window, i, "---");
                break;
            default:
                SetControlText (window, i, "---");
                break;
        }
     }
    SetPortWindowPort(window);
    EraseRect(GetWindowPortBounds(window, &bounds));
    DrawControls (window);
 }

// ---------------------------------
// builds device list and rebuilds menus representing this list

static void BuildAppDeviceList (WindowRef window)
{
//	HIDBuildDeviceList (kHIDPage_GenericDesktop,kHIDUsage_GD_GamePad); // returns false if no device found (ignored in this case)
	HIDBuildDeviceList (NULL, NULL);
	BuildDeviceMenu (window);
	BuildElementMenu (window);
}

// ---------------------------------
// draws graphic to represent control value

static void DrawScaleGraphic (Rect * prectControl, SInt32 value, SInt32 min, SInt32 max, pRecElement pElement, Boolean showMinMax)
{
    enum { kBubbleSize = 4 };
    RGBColor colorSave, color;
    short height = prectControl->bottom - prectControl->top, width = prectControl->right - prectControl->left, xPos;
    Rect circle;
    float elementRange = max - min;
    float graphicRange = width;

    GetForeColor (&colorSave);     
                 
    InsetRect (prectControl, -kBubbleSize, -kBubbleSize);
    EraseRect (prectControl);
    InsetRect (prectControl, kBubbleSize, kBubbleSize);
    
    if (!((value >= min) && (value <= max))) // out of range
    {
        // draw bad scale
        color.red = 0xFFFF;
        color.green = 0xB000;
        color.blue = 0xB000;
        RGBForeColor (&color);
        PaintRect (prectControl);
        RGBForeColor (&colorSave);
    }
    else if (showMinMax) // min max rect
    {
        Rect rectRange;
        short left, right;
        if (pElement->calMin > min)
            left = ((float) (pElement->calMin - min) / elementRange) * graphicRange + prectControl->left;
        else
            left = prectControl->left;
        if (pElement->calMin < max)
            right = ((float) (pElement->calMax - min) / elementRange) * graphicRange + prectControl->left;
        else
            right = prectControl->right;
        SetRect (&rectRange, left, prectControl->top + height / 2 - kBubbleSize + 1,
                             right, prectControl->top + height / 2 + kBubbleSize - 1); // l, t, r, b
        color.red = 0xC000;
        color.green = 0xC000;
        color.blue = 0xFFFF;
        RGBForeColor (&color);
        PaintRect (&rectRange);
        RGBForeColor (&colorSave);
    }

    
    // draw scale
    MoveTo (prectControl->left, prectControl->top);
    LineTo (prectControl->left, prectControl->bottom);
    MoveTo (prectControl->right, prectControl->top);
    LineTo (prectControl->right, prectControl->bottom);
    MoveTo (prectControl->left, prectControl->top + height / 2);
    LineTo (prectControl->right, prectControl->top + height / 2);
    MoveTo (prectControl->left + width / 2, prectControl->top + height / 4);
    LineTo (prectControl->left + width / 2, prectControl->bottom - height / 4);
    

    if ((value >= min) && (value <= max)) // in range
    {
        // display current value
        color.red = 0xC000;
        color.green = 0x0000;
        color.blue = 0x0000;
        RGBForeColor (&color);
        xPos = ((float) (value - min) / elementRange) * graphicRange + prectControl->left;
        SetRect (&circle, xPos - kBubbleSize, prectControl->top + height / 2 - kBubbleSize,
                        xPos + kBubbleSize, prectControl->top + height / 2 + kBubbleSize); // l t r b
        PaintOval (&circle);
    
        if (showMinMax)
        {
            // display min and max device reports
            color.red = 0x0000;
            color.green = 0x0000;
            color.blue = 0xF000;
            RGBForeColor (&color);
            if (pElement->calMin > min)
                xPos = ((float) (pElement->calMin - min) / elementRange) * graphicRange + prectControl->left;
            else
                xPos = prectControl->left;
            SetRect (&circle, xPos - kBubbleSize / 2, prectControl->top + height / 2 - kBubbleSize / 2,
                            xPos + kBubbleSize / 2, prectControl->top + height / 2 + kBubbleSize / 2); // l t r b
            PaintOval (&circle);
            
            if (pElement->calMin < max)
                xPos = ((float) (pElement->calMax - min) / elementRange) * graphicRange + prectControl->left;
            else
                xPos = prectControl->right;
            SetRect (&circle, xPos - kBubbleSize / 2, prectControl->top + height / 2 - kBubbleSize / 2,
                            xPos + kBubbleSize / 2, prectControl->top + height / 2 + kBubbleSize / 2); // l t r b
            PaintOval (&circle);
        }
    }
    RGBForeColor (&colorSave);
}

// ---------------------------------
// displays element value (raw, calibrated and scaled) including graphic

void DisplayCurrentDeviceElementValue (void)
{
    pRecDevice pCurrentHIDDevice = GetSetCurrentDevice (gWindow);
    pRecElement pCurrentHIDElement = GetSetCurrentElement (gWindow);

	// if we have a good device and element which is not a collecion
    if (pCurrentHIDDevice && pCurrentHIDElement && (pCurrentHIDElement->type != kIOHIDElementTypeCollection))
    {
        CGrafPtr portSave = NULL;
        ControlID idControl;
        ControlRef control;
        Rect rectControl;
        char text [256];
        
        SInt32 value = HIDGetElementValue (pCurrentHIDDevice, pCurrentHIDElement);
        SInt32 valueCal = HIDCalibrateValue (value, pCurrentHIDElement);
        SInt32 valueScale = HIDScaleValue (valueCal, pCurrentHIDElement);
        
        // output raw text
        idControl.signature = 'hidm';
        idControl.id = kCntlTextRawValueElement; 
        GetControlByID (gWindow, &idControl, &control);
        sprintf (text, "%3ld", value);
        SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
        Draw1Control (control);
        
        // output calibrated text
        idControl.id = kCntlTextCalibrateValueElement; 
        GetControlByID (gWindow, &idControl, &control);
        sprintf (text, "%3ld", valueCal);
        SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
        Draw1Control (control);
        
        // output scaled text
        idControl.id = kCntlTextScaleValueElement; 
        GetControlByID (gWindow, &idControl, &control);
        sprintf (text, "%3ld", valueScale);
        SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
        Draw1Control (control);
        
        // draw graphic
        GetPort (&portSave);
        SetPortWindowPort (gWindow);

        idControl.id = kCntlUserRawValueGraphicElement; 
        GetControlByID (gWindow, &idControl, &control);
        GetControlBounds (control, &rectControl);
        DrawScaleGraphic (&rectControl, value, pCurrentHIDElement->min, pCurrentHIDElement->max, pCurrentHIDElement, true);

        idControl.id = kCntlUserCalibrateValueGraphicElement; 
        GetControlByID (gWindow, &idControl, &control);
        GetControlBounds (control, &rectControl);
        DrawScaleGraphic (&rectControl, valueCal, pCurrentHIDElement->min, pCurrentHIDElement->max, pCurrentHIDElement, false);

        idControl.id = kCntlUserScaleValueGraphicElement; 
        GetControlByID (gWindow, &idControl, &control);
        GetControlBounds (control, &rectControl);
        DrawScaleGraphic (&rectControl, valueScale, pCurrentHIDElement->userMin, pCurrentHIDElement->userMax, pCurrentHIDElement, false);

        SetPort (portSave);
    }
	else
	{
        ControlID idControl;
        ControlRef control;
        char text [256];
        
        // output raw text
        idControl.signature = 'hidm';
        idControl.id = kCntlTextRawValueElement; 
        GetControlByID (gWindow, &idControl, &control);
        sprintf (text, "---");
        SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
        Draw1Control (control);
        
        // output calibrated text
        idControl.id = kCntlTextCalibrateValueElement; 
        GetControlByID (gWindow, &idControl, &control);
        sprintf (text, "---");
        SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
        Draw1Control (control);
        
        // output scaled text
        idControl.id = kCntlTextScaleValueElement; 
        GetControlByID (gWindow, &idControl, &control);
        sprintf (text, "---");
        SetControlData (control, kControlNoPart, kControlStaticTextTextTag, strlen (text), text);
        Draw1Control (control);
	}
}

// ---------------------------------
// timer handling function to update value of currently displayed element

static pascal void IdleTimer (EventLoopTimerRef inTimer, void* userData)
{
	#pragma unused (inTimer, userData)
	DisplayCurrentDeviceElementValue ();
}

// ---------------------------------
// timer UPP retrieval

static EventLoopTimerUPP GetTimerUPP (void)
{
	static EventLoopTimerUPP	sTimerUPP = NULL;
	
	if (sTimerUPP == NULL)
		sTimerUPP = NewEventLoopTimerUPP (IdleTimer);
	
	return sTimerUPP;
}

// ---------------------------------
// main window event handling

static pascal OSStatus myWinEvtHndlr(EventHandlerCallRef myHandler, EventRef event, void* userData)
{
#pragma unused (myHandler, userData)
    WindowRef			window;
    OSStatus			result = eventNotHandledErr;


    if (GetEventKind(event) == kEventWindowDrawContent)
    {
		GetEventParameter(event, kEventParamDirectObject, typeWindowRef, NULL, sizeof(window), NULL, &window);
        HandleWindowUpdate(window);
        result = noErr;
    }
    else if (GetEventKind(event) == kEventWindowClose)
    {
		MenuHandle hMenu;
		Size tempSize;
		ControlID idControl;
		ControlRef control;
		OSStatus err = noErr;
		// restore original menu prior to exit
		GetEventParameter(event, kEventParamDirectObject, typeWindowRef, NULL, sizeof(window), NULL, &window);
		idControl.signature = 'hidm';
		idControl.id = kCntlPopUpElement; 
		err = GetControlByID (window, &idControl, &control);
		err = GetControlData (control, kControlMenuPart, kControlPopupButtonMenuHandleTag, sizeof (MenuHandle), &hMenu, &tempSize);
		if (gRestoreMenu)
			DisposeMenu (hMenu);
		else 
			err = SetControlData (control, kControlMenuPart, kControlPopupButtonMenuHandleTag, sizeof (MenuHandle), &gRestoreMenu);
		gRestoreMenu = NULL;
    	DisposeEventHandlerUPP (gWinEvtHandler);
        DisposeWindow (window);
        result = noErr;
    }
    else if (GetEventKind(event) == kEventControlClick)
    {
		long originalDevice = gDeviceNum;
        ControlRef control;
        GetEventParameter (event, kEventParamDirectObject, typeControlRef, NULL, sizeof(control), NULL, &control);
        window = GetControlOwner (control);
        // Now propagate the event to the next handler (in this case the default)
        result = CallNextEventHandler (myHandler, event);
		// update my window if menu values changed
		gDeviceNum = GetCurrentDeviceNum (gWindow);
		if ((gDeviceNum != originalDevice))
		{
			// reset elements and update window
			gElementCookie = NULL; // reset cookie to NULL
			GetSetCurrentElement (gWindow);
			BuildElementMenu (gWindow);
			SetElementTitle (gWindow);
			HandleWindowUpdate (gWindow);
		}
    }
    else if (GetEventKind(event) == kEventProcessCommand)
    {
        HICommand command;
		void * originalElement = gElementCookie;
         GetEventParameter (event, kEventParamDirectObject, kEventParamHICommand, NULL, sizeof(command), NULL, &command);
        if (command.commandID == 'bhdl')
		{
            BuildAppDeviceList (gWindow);
			
			GetSetCurrentElement  (gWindow); // will clean up current element if required
			BuildElementMenu (gWindow);
			SetElementTitle (gWindow);
			HandleWindowUpdate (gWindow);
		}
		else // menu command: command ID is cookie
		{
			gElementCookie = (void *) command.commandID;
			if (gElementCookie != originalElement)
			{
				SetElementTitle (gWindow);
				HandleWindowUpdate (gWindow);
			}
		}
    }
    return result;
}

// ==================================

int main(int argc, char* argv[])
{
#pragma unused ( argc, argv)

    IBNibRef 		nibRef;
    OSStatus		err;
    EventHandlerRef	ref;
    EventTypeSpec	list[] = {   { kEventClassWindow, kEventWindowClose },
                                 { kEventClassWindow, kEventWindowDrawContent },
                                 { kEventClassControl, kEventControlClick },
                                 { kEventClassCommand,  kEventProcessCommand } };

    // Create a Nib reference passing the name of the nib file (without the .nib extension)
    // CreateNibReference only searches into the application bundle.
    err = CreateNibReference(CFSTR("main"), &nibRef);
    require_noerr( err, CantGetNibRef );
    
    // Once the nib reference is created, set the menu bar. "MainMenu" is the name of the menu bar
    // object. This name is set in InterfaceBuilder when the nib is created.
    err = SetMenuBarFromNib(nibRef, CFSTR ("MainMenu"));
    require_noerr( err, CantSetMenuBar );
        
    // Then create a window. "MainWindow" is the name of the window object. This name is set in 
    // InterfaceBuilder when the nib is created.
    err = CreateWindowFromNib (nibRef, CFSTR ("MainWindow"), &gWindow);
    require_noerr ( err, CantCreateWindow );
    
    // setup HID CFm links (if required) and build device list
#ifndef __APPLE_CC__
	err = SetupHIDCFM ();
#endif
    require_noerr ( err, CantSetupHID );
    BuildAppDeviceList (gWindow);

    gWinEvtHandler = NewEventHandlerUPP(myWinEvtHndlr);
    InstallWindowEventHandler (gWindow, gWinEvtHandler, GetEventTypeCount (list), list, 0, &ref);

    // We don't need the nib reference anymore.
    DisposeNibReference (nibRef);
     
    // The window was created hidden so show it.
    ShowWindow (gWindow);
    
    if (NULL == gTimer)
        InstallEventLoopTimer (GetCurrentEventLoop(), 0, 0.1, GetTimerUPP (), 0, &gTimer);

	// reset elements and update window
	gElementCookie = NULL; // reset cookie to NULL
	GetSetCurrentElement (gWindow);
	BuildElementMenu (gWindow);
	SetElementTitle (gWindow);
	HandleWindowUpdate (gWindow);
    
    // Call the event loop
    RunApplicationEventLoop ();

    if (gTimer)
        RemoveEventLoopTimer(gTimer);
	gTimer = NULL;

    HIDReleaseDeviceList ();

CantCreateWindow:
CantSetupHID:
CantSetMenuBar:
CantGetNibRef:

#ifndef __APPLE_CC__
	TearDownHIDCFM ();
#endif

	return err;
}

