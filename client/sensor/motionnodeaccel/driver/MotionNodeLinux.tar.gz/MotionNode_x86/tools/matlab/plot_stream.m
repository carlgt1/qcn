%
% Plot a MotionNode stream data file. This will either be a
% "raw" data file or a "sensor" data file. The data_type
% input parameter should either be 'float32' or 'int16'.
%
% Returns the MxN matrix of sample data. Each row is a single
% sample of stream data.
% [accelerometer [magnetometer gyroscope] [temperature]] =
%   [ax ay az [mx my mz gx gy gz] [t]]
%
% Detect accelerometer only streams at run time and remove
% zero data in the magnetometer and gyroscope channels.
%
% Note that temperature output is not available on all
% versions of the data.
%
% @file    tools/matlab/plot_stream.m
% @author  Luke Tokheim, luke@motionnode.com
% @version 1.2
%

function [data] = plot_stream(filename, data_type)
  nchannel = [9,10];

  data = import_binary(filename, data_type, nchannel);

  % Detect data files with temperature output if the
  % number of elements in ambiguous.
  n_element = prod(size(data));
  if (mod(n_element, 10) == 0),
    if (mod(n_element, 9) == 0),
      if (size(data,2) == 10) && (data(1,10) ~= 0),
        data = reshape(data', 9, n_element / 9)';
      elseif (size(data,2) == 9) && (data(2,1) == 0),      
        data = reshape(data', 10, n_element / 10)';
      end
    end
    
    % Duplicate the second temperature sample in the logged
    % data. The first sample is zero to allow for file
    % detection.
    if (size(data,2) == 10) && (data(1,10) == 0),
      data(1,10) = data(2,10);
    end
  end 
  
  clf;
  nplot = 3;
  
  % Detect accelerometer only data stream. Remove
  % zero data in the magnetometer and gyroscope
  % channels.
  if (size(data,1) > 0) && (sum(data(1,[4:9])) == 0),
    data(:,[4:9]) = [];
    nplot = 1;
  end
  
  % Accelerometer.
  subplot(nplot,1,1);
  plot(data(:,[1:3]));
  
  if size(data,2) >= 6,
    % Magnetometer.
    subplot(nplot,1,2);
    plot(data(:,[4:6]));
  end
  
  if size(data,2) >= 9,
    % Gyroscope.
    subplot(nplot,1,3);
    plot(data(:,[7:9]));
  end
end
% function [data] = plot_stream(filename, data_type)
