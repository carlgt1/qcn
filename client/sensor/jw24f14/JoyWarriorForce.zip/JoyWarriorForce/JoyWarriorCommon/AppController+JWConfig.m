//
//  AppController+JWConfig.m
//  JoyWarrior Common
//
//  Created by stefan on 2010-08-30.
//  Copyright 2010 Iwascoding GmbH. All rights reserved.
//

#import "AppController+Devices.h"
#import "DiscoverHIDInterface.h"

@implementation AppController (JWConfig)

- (BOOL) switchJoyWarriorAtInterface:(IOHIDDeviceInterface122 **)inInterface withProductID:(int)inProductID toRange:(int)inRange andBandwidth:(int)inBandwidth;
{
    UInt8 temp;

    if ( inProductID == 0x1116 )
    {
        // F14
        JWEnableCommandMode24F14(interface);
        
        // Open 
        JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
        usleep(50000);
        temp &= 0xEF;
        temp |= 0x10;
        JWWriteByteToAddress24F14 (interface, 0x0D, temp);
        usleep(50000);
        
        // Write Bandwidth & Compensation
        JWReadByteFromAddress24F14 (interface, 0x20, &temp);
        usleep(50000);
        temp &= 0x0F;
        temp |= (inBandwidth<<4);
        JWWriteByteToAddress24F14 (interface, 0x20, temp);
        usleep(50000);
        
        // Write Range
        JWReadByteFromAddress24F14 (interface, 0x35, &temp);
        usleep(50000);
        temp &= 0xF1;
        temp |= (inRange<<1);
        JWWriteByteToAddress24F14 (interface, 0x35, temp);
        usleep(50000);
        
        // Close Image
        JWReadByteFromAddress24F14 (interface, 0x0D, &temp);
        usleep(50000);
        temp &= 0xEF;
        JWWriteByteToAddress24F14 (interface, 0x0D, temp);
        usleep(50000);
        
        JWDisableCommandMode24F14(interface);
    } else if (inProductID == 0x1113) {
        // F8
        JWReadByteFromAddress(interface, 0x14, &temp);
        usleep(50000);
        temp &= 0xE0;
        temp |= (inRange<<3);
        temp |= inBandwidth;
        JWWriteByteToAddress (interface, 0x14, temp);
    } else {
        NSLog(@"ERROR: unknown productID: %i", inProductID);
        return NO;
    }

    return YES;
}

@end
