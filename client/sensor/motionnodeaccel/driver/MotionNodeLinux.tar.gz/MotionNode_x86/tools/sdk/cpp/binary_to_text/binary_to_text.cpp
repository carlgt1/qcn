/**
  Read MotionNode binary take stream files and output a plain text file.
  The intended purpose is to provide raw and sensor data export to
  programs like Excel.

  @file    tools/sdk/cpp/binary_to_text/binary_to_text.cpp
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.0

  (C) Copyright GLI Interactive LLC 2007. All rights reserved.

  The coded instructions, statements, computer programs, and/or related
  material (collectively the "Data") in these files contain unpublished
  information proprietary to GLI Interactive LLC, which is protected by
  US federal copyright law and by international treaties.

  The Data may not be disclosed or distributed to third parties, in whole
  or in part, without the prior written consent of GLI Interactive LLC.

  The Data is provided "as is" without express or implied warranty, and
  with no claim as to its suitability for any purpose.
*/
#include <File.hpp>
#include <Format.hpp>

#include <iostream>
#include <stdexcept>

//#if !defined(_USE_MATH_DEFINES)
//#  define _USE_MATH_DEFINES
//#endif
//#include <cmath>

const std::size_t MaxOptionLength = 1024;
const std::string ChannelName[9] = {
  "ax", "ay", "az",
  "mx", "my", "mz",
  "gx", "gy", "gz"
};

template <typename ElementT>
bool binary_to_text(const std::string & pathname,
                    std::ostream & out,
                    bool degree_format,
                    bool show_channel_names,
                    const std::string & separator)
{
  bool result = true;

  try {
    using MotionNode::SDK::File;
    using MotionNode::SDK::Format;

    File file(pathname);

    if (show_channel_names) {
      std::copy(
        ChannelName, ChannelName + 8,
        std::ostream_iterator<std::string>(out, separator.c_str()));
      out
        << *(ChannelName + 8)
        << std::endl;
    }

    typename ElementT::data_type data(ElementT::Length);
    while (file.readData(data)) {
      if (!data.empty()) {
        // Access the data directly.
        //if (degree_format) {
        //  std::transform(
        //    data.begin() + 6, data.end(),
        //    data.begin() + 6,
        //    std::bind1st(std::multiplies<typename ElementT::data_type::value_type>(), (180.0/M_PI)));
        //}

        std::copy(
          data.begin(), data.begin() + data.size() - 1,
          std::ostream_iterator<typename ElementT::data_type::value_type>(out, separator.c_str()));

        out
          << data.back()
          << std::endl;
      }

      // Or wrap the data in the associated Format class.
      //ElementT element(data);

      // Read the three vector of magnetometer data.
      //typename ElementT::data_type magnetometer = 
      //  element.getMagnetometer();
    }

  } catch (std::runtime_error & e) {
    std::cerr << e.what() << std::endl;
    result = false;
  }

  return result;
}

bool binary_to_text(const std::string & input_file,
                    std::ostream & out,
                    bool degree_format,
                    bool raw_format,
                    bool show_channel_names,
                    const std::string & separator)
{
  using MotionNode::SDK::Format;

  bool result = false;
  if (raw_format) {
    if (binary_to_text<Format::RawElement>(input_file, out, false, show_channel_names, separator)) {
      result = true;
    }
  } else {
    if (binary_to_text<Format::SensorElement>(input_file, out, degree_format, show_channel_names, separator)) {
      result = true;
    }
  }

  return result;
}

void print_usage(const std::string & name, std::ostream & out)
{
  // Print usage.
  out
    << "Usage: " << name << " [OPTION]... FILENAME[...]" << std::endl
    << "Read a MotionNode binary sensor or raw stream file and output a plain text, comma separated version." << std::endl
    << std::endl
    << "Options" << std::endl
    //<< "-d, --degree              output angular data in degrees, defaults to radians" << std::endl
    << "-f, --file FILENAME       output results to a file, defaults to standard output" << std::endl
    << "-h, --help                prints this message" << std::endl
    << "-r, --raw                 input files are raw format data files, default is sensor format" << std::endl
    << "-n, --nonames             do not print the channel name headers" << std::endl
    << "-s, --separator STRING    element delimiter string, default is \", \" (CSV)" << std::endl
    << std::endl;
}

// Entry point. Parse arguments and call worker function
// for the intended input and output data formats.
int main(int argc, char * argv[])
{
  int result = 1;

  // Initialize all options.
  std::string name;
  if (argc > 0) {
    name.assign(argv[0], strnlen(argv[0], MaxOptionLength));
  }

  std::vector<std::string> input_file;
  std::string separator = ", ";
  bool degree_format = false;
  bool raw_format = false;
  bool show_channel_names = true;
  std::string output_file;

  // Parse command line options. Override the defaults we
  // just set above.
  bool valid_command_line = true;
  for (int i=1; i<argc; i++) {
    const std::size_t length = strnlen(argv[i], MaxOptionLength);

    // Look for an option of the form:
    // /option, --option, -option, or -o
    if ((length > 1) && (('-' == *argv[i]) || ('/' == *argv[i]))) {
      std::string option(argv[i] + 1, length-1);
      std::transform(
        option.begin(), option.end(),
        option.begin(),
        tolower);

      // Remove a leading '-' character if it exists.
      if (!option.empty() && ('-' == option[0])) {
        option = option.substr(1);
      }

      // Do the actual option handling and assign
      // local flags.
      if ("file" == option || "f" == option) {
        if (argc >= i) {
          i++;
          output_file.assign(argv[i], strnlen(argv[i], MaxOptionLength));
        } else {
          std::cerr
            << "invalid option, missing argument: " << std::string(argv[i], length) << std::endl;
          valid_command_line = false;
        }
      } else if ("separator" == option || "s" == option) {
        if (argc >= i) {
          i++;
          separator.assign(argv[i], strnlen(argv[i], MaxOptionLength));
        } else {
          std::cerr
            << "invalid option, missing argument: " << std::string(argv[i], length) << std::endl;
          valid_command_line = false;
        }
      //} else if ("degree" == option || "d" == option) {
      //  degree_format = true;
      } else if ("raw" == option || "r" == option) {
        raw_format = true;
      } else if ("nonames" == option || "n" == option) {
        show_channel_names = false;
      } else if ("help" == option || "h" == option) {
        valid_command_line = false;
      } else {
        std::cerr
          << "unknown option: " << std::string(argv[i], length) << std::endl;
        valid_command_line = false;
      }

    } else if (length > 0) {
      // Anything no captured by an option is considered to be a file name.
      input_file.push_back(std::string(argv[i], length));
    }
  }

  // If we have valid options and at least one input file, run the conversion loop.
  // Otherwise, print out the usage information.
  if (valid_command_line && !input_file.empty()) {

    std::ofstream * fout = NULL;
    if (!output_file.empty()) {
      fout = new std::ofstream(output_file.c_str(), std::ios_base::binary | std::ios_base::out);
      if (!fout->is_open()) {
        delete fout;
        fout = NULL;
      
        std::cerr
          << "failed to open output file, \"" << output_file << "\""
          << std::endl;
      }
    }

    result = 0;
    for (std::vector<std::string>::const_iterator itr=input_file.begin(); itr!=input_file.end(); ++itr) {
      if (!binary_to_text(*itr, (NULL != fout) ? *fout : std::cout, degree_format, raw_format, show_channel_names, separator)) {
        result = 1;
      }
    }

    if (NULL != fout) {
      fout->close();
      delete fout;
      fout = NULL;
    }

  } else {
    print_usage(name, std::cerr);
  }

  return result;
}

