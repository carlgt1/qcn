--
-- node.lua
--   Pure Lua library functions for the MotionNode system. Implements
--   higher level functions in terms of the Manager class interface.
--   Intended as the public scripting interface to the MotionNode system.
--
--   See the "manual/Scripting API Reference.pdf" for detailed reference.
--


--
-- Declare module and import dependencies.
--
local base = _G
local manager = base.manager
local math = require("math")
local string = require("string")
local table = require("table")
local _initialize_filename = "default/initialize.lua"
local _location_filename = "default/location.xml"
local _initialized = false
local _history = {}
local _super = false

-- Package declaration. All following declarations are
-- in this module table.
module("node")

_COPYRIGHT = "Copyright 2008 GLI Interactive LLC"
_NAME = "Node"
_DESCRIPTION = "Public scripting interface to the MotionNode system."
_VERSION = manager.version
_DEMO = manager.version_demo

-- Table of Bluetooth device related functions.
bluetooth = {}
-- Table of Emulated device related functions.
emulate = {}
-- Table of Plugin device related functions.
plugin = {}
-- Table of USB device related functions.
usb = {}
-- Table of MotionNode system initialization, configuration, and state functions. 
system = {}
-- Table of XML string processing related functions.
xml = {}


--
-- Begin public function definitions.
--

function close(id)
  -- Only enforce is_connected(id) for single Node close.
  if id then
    if not is_connected(id) then
      return false, "failed precondition, \"is_connected(\"" .. id .. "\") == true\""
    end
  end

  -- Stop take.
  if is_taking() then
    local result, message = stop_take()
    if not result then
      return result, message
    end
  end

  -- Stop reading.
  if is_reading(id) then
    local result, message = stop(id)
    if not result then
      return result, message
    end
  end

  if id then
    if not manager:close(id) then
      return false, "failed to close connection to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    -- Do not call close if the configuration is empty.
    if not is_configured() then
      return false, "no configured " .. _NAME .. "s"
    end

    -- Do not call close if the connection list is empty.
    if not connected() then
      return false, "no connected " .. _NAME .. "s"
    end

    if not manager:close() then
      return false, "failed to close at least one open connection"
    end
  end

  return true, ""
end

function configuration()
  return manager:configuration()
end

function configuration_tree()
  return manager:configuration_tree()
end

function connect(id)
  if not is_configured(id) then
    if id then
      return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition \"is_configured() == true\""
    end
  end
  if is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end
  
  
  if id then
    if not manager:connect(id) then
      return false, "failed to connect to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    if not manager:connect() then
      return false, "failed to connect to at least one " .. _NAME .. " in configuration"
    end
  end
  
  return true, ""
end

function connected()
  return manager:connected()
end

function define_identity_pose()
  if not is_reading() then
    return false, "failed precondition, \"is_reading() == true\""
  end
  if is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end 
  
  if not manager:define_identity_pose() then
    return false, "failed to define identity pose"
  end
  
  return true, ""
end

function delay_to_sample_rate(value)
  -- Use default sample rate.
  if not value then
    value = 0
  end

  if value > 1 then
    value = 1
  elseif value < 0 then
    value = 0
  end
  
  local rate = 6
  if value > 0 then
    rate = (1.625 - value) * 8
  end

  return math.floor(rate) * 10
end


function erase(id)
  if not is_configured(id) then
    if id then
      return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition \"is_configured() == true\""
    end
  end
  if is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if id then
    if not manager:erase(id) then
      return false, "failed to erase " .. _NAME .. " configuration with id \"" .. id .. "\""
    end
  else
    if not manager:erase() then
      return false, "failed to erase " .. _NAME .. " configuration"
    end
  end
  
  return true, ""
end

function export(filename, option, type)
  if not filename then
    filename = ""
  end

  _history["export"] = filename

  if not system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end
  if not have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end
  if not system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end

  if not type or string.len(type) == 0 then
    _, _, type = string.find(filename, "%.([^%.]+)$")
  end
  
  if not type then
    type = ""
  end

  local valid_type = system.export_type()
  if not valid_type[type] then
    return false, "invalid export type \"" .. base.tostring(type) .. "\" for file \"" .. filename .. "\""
  else
    if not string.find(filename, "%." .. type .. "$") then
      filename = filename .. "." .. type
    end
  end
  
  -- Create a list of the default options for this file type. Every type inherits
  -- the same base set of options.
  if not option then
    option =
      "continuous_curve=1,prepend_rest=0,post_filter=0,post_filter_a=1,post_filter_b=1.5"
    if valid_type[type]["option"] and (string.len(valid_type[type]["option"]) > 0) then
      option = option .. "," .. valid_type[type]["option"]
    end
  end

  _history["export_type"] = type
  _history["export_option"] = option

  if not manager:export(filename, option, type) then
    return false, "failed to export take to file \"" .. filename .. "\""
  end

  return true, ""
end

function export_stream(filename, option)
  if not filename then
    filename = ""
  end

  _history["export_stream"] = filename

  if not system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end
  if not have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end
  if not system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end
  
  -- Create a list of the default options.
  if not option then
    -- 1. Export the output orientation stream, output=1
    -- 2. Use default precision for float to string conversion, precision=0
    -- 3. CSV only, print a channel header, header=1 
    -- 4. CSV only, do not use space separator, default to comma, space=0
    -- 5. CSV only, print a per node time step channel, time_step=1
    -- 6. SVG only, generate axis labels, show_label=1
    -- 7. SVG only, generate a grid of axis value ticks, show_grid=1
    -- 8. Select SVG by file extension, svg=0 or set svg=1 to always export SVG
    option = "output=1,precision=0,header=1,space=0,time_step=1,show_label=1,show_grid=1,svg=0"
  end

  if not manager:export_stream(filename, option) then
    return false, "failed to export take stream to file \"" .. filename .. "\""
  end

  return true, ""
end

function get_node(key, value, compare)
  if not compare then
    compare = function(lhs, rhs) return lhs == rhs end
  end

  local container = configuration()

  if container then
    local configured_node
    for _,configured_node in base.pairs(container:list()) do
      if compare(value, configured_node[key]) then
        return configured_node
      end
    end
  end

  return nil
end

function get_node_by_id(id)
  return get_node('id', id)
end

function get_node_by_key(key)
  return get_node('key', key)
end

function get_preview()
  return manager:get_preview()
end

function get_raw()
  return manager:get_raw()
end

function get_sensor()
  return manager:get_sensor()
end

function have_take()
  return manager:have_take()
end

function insert(id)
  _history["insert"] = id

  if not is_id(id) then
    if not id then
      id = ""
    end
    return false, "failed precondition \"is_id(\"" .. id .. "\") == true\""
  end
  local result, id = system.unique_id(id)
  if not result then
    return false, "failed precondition \"system.unique_id(\"" .. id .. "\") == true\""
  end  
  if is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == false\""
  end  
  if is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end

  if not manager:insert(id) then
    return false, "failed to insert " .. _NAME .. " configuration with id \"" .. id .. "\""
  end

  return true, id
end

function is_configured(id)
  if id then
    return manager:is_configured(id)
  else
    return manager:is_configured()
  end
end

function is_connected(id)
  if id then
    return manager:is_connected(id)
  else
    return manager:is_connected()
  end
end

function is_id(id)
  if id then
    return manager:is_id(id)
  else
    return false
  end
end

function is_reading(id)
  if id then
    return manager:is_reading(id)
  else
    return manager:is_reading()
  end
end

function is_taking()
  return manager:is_taking()
end

function load_configuration(filename)
  if not filename then
    filename = ""
  end

  _history["load_configuration"] = filename

  if not system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end

  if not manager:load_configuration(filename) then
    return false, "failed to load configuration file \"" .. filename .. "\""
  end

  return true, ""
end

function load_location(filename)
  if not filename then
    filename = ""
  end

  _history["load_location"] = filename
  
  if not system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if not manager:load_location(filename) then
    return false, "failed to load location file \"" .. filename .. "\""
  end

  return true, ""  
end

function load_script(filename)
  if not filename then
    filename = ""
  end

  _history["load_script"] = filename

  if not system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end

  if not manager:load_script(filename) then
    return false, "failed to load script file \"" .. filename .. "\""
  end
  
  return true, ""
end

function load_take(filename)
  if not filename then
    filename = ""
  end

  _history["load_take"] = filename

  if not system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end 

  if not manager:load_take(filename) then
    return false, "failed to load take file \"" .. filename .. "\""
  end
  
  return true, ""
end

function load_take_source(filename)
  if filename then
    _history["load_take_source"] = filename
  
    local result, message = load_take(filename)
    if not result then
      return result, message
    end
  end

  if not have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end
  if is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  if not system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end

  if not manager:load_take_source() then
    return false, "failed to load take as " .. _NAME .. " source"
  end

  return true, ""
end

function num_reading()
  local container = reading()
  if container then
    return table.getn(container:list())
  else
	return 0
  end
end

function open(filename)
  if not filename then
    filename = ""
  end

  _history["open"] = filename

  if not system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end 

  if not manager:open(filename) then
    return false, "failed to open file \"" .. filename .. "\""
  end

  return true, ""
end

function reading()
  return manager:reading()
end

function replay_take(filename)
  local take_name = filename

  if not filename and have_take() then
    local current_take = take()
    if current_take then
      take_name = current_take.name
    end
  end

  local result, message = load_take_source(filename)
  if not result then
    return result, message
  end

  local result, message = start_take("", "Replay of \"" .. take_name .. "\"")
  if not result then
    return result, message
  end

  return true, ""
end

function save_configuration(filename)
  if not filename then
    filename = ""
  end

  _history["save_configuration"] = filename

  if not system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end
  if not is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end

  if not manager:save_configuration(filename) then
    return false, "failed to save configuration file \"" .. filename .. "\""
  end

  return true, ""
end

function scan()
  if is_connected() then
    return false, "failed precondition, \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end 

  local num_device = 0
  local num_device_existing = 0
  
  -- Run all device enumeration routines.
  local enumeration = {
    ["bluetooth"] = bluetooth.enumerate(),
    ["emulate"] = emulate.enumerate(),
    ["plugin"] = plugin.enumerate(),
    ["usb"] = usb.enumerate()
  }

  local configured = configuration()

  -- Iterate through each enumeration result and add the
  -- device to the configuration.
  local container
  for _,container in base.pairs(enumeration) do
    local parent_id = ""

    local enumerated_node
    for _,enumerated_node in base.pairs(container:list()) do

      local source_configured = false
      if configured then
        local configured_node
        for _,configured_node in base.pairs(configured:list()) do
          if enumerated_node.source == configured_node.source then
            source_configured = true
            break
          end
        end
      end

      if not source_configured then
        -- Use the device name as the id if it is available. Otherwise
        -- fall back on the id field, which will be a cleaned version
        -- of the device address or identifier.
        local id = enumerated_node.name
        if not is_id(id) then
          id = enumerated_node.id
        end

        local result, id = system.unique_id(id)
        if result and not is_configured(id) then
          local is_bus = false
          if enumerated_node.bus then
            is_bus = true
          end
        
          local configured_node = manager:insert(id, is_bus)
          if configured_node then
            configured_node.name = enumerated_node.name
            configured_node.source = enumerated_node.source
            if string.len(enumerated_node.parent) > 0 then
              configured_node.parent = parent_id
            else
              if is_bus then
                parent_id = id
              end
            end

            num_device = num_device + 1
          else
            return false, "failed to insert " .. _NAME .. " configuration with id \"" .. id .. "\""
          end
        end
      else
        num_device_existing = num_device_existing + 1
      end
    end
  end -- for each container

  if 0 == num_device then
    if 0 == num_device_existing then
      return false, "no devices found"
    else
      return false, "no additional devices found"
    end
  end

  return true, ""
end

function set_configuration(key, value, id)
  if not is_configured() then
    return false, "failed precondition, \"is_configured() == true\""
  end

  local result = false

  local container = configuration()
  if container then
    local configured_node
    for _,configured_node in base.pairs(container:list()) do
      if not id or (id == configured_node.id) then
        configured_node[key] = value
        result = true
      end
    end
  end

  return result, ""
end

function set_delay(value, id)
  if is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end

  return set_configuration("delay", value, id)
end

function set_filter_version(value, id)
  if is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return set_configuration("filter_version", value, id)
end

function set_gain(value, id)
  if is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return set_configuration("gain", value, id)
end

function set_gain_sensor(value, id)
  if is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return set_configuration("gain_sensor", value, id)
end

function set_gain_sensor_prefilter(value, id)
  if is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return set_configuration("gain_sensor_prefilter", value, id)
end

function set_gselect(value, id)
  if is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end

  return set_configuration("gselect", value, id)
end

function set_gyroscope_only(value, id)
  if is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end
  
  -- Convert real value to boolean.
  if base.type(value) == base.type(0.0) then
    value = (value > 0)
  end

  return set_configuration("gyroscope_only", value, id)
end

function set_name(value, id)
  if is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end

  return set_configuration("name", value, id)
end

function sample_rate_to_delay(value)
  if not value then
    return 0
  end

  local min_rate = 50
  local max_rate = 120
  
  if value > max_rate then
    value = max_rate
  elseif value < min_rate then
    value = min_rate
  end
  
  -- The 0 delay value is reserved to specify
  -- default delay.
  return 1 - (value - min_rate) * 0.0125
end

function set_sample_rate(value, id)  
  return set_delay(sample_rate_to_delay(value), id)
end

function set_source(value, id)
  if is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end

  return set_configuration("source", value, id)
end

function start(id)
  if is_reading(id) then
    if id then
      return false, "failed precondition \"is_reading(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_reading() == false\""
    end
  end

  -- Connect.
  if not is_connected(id) then
    local result, message = connect(id)
    if not result then
      return result, message
    end
  end

  if id then
    if not manager:start(id) then
      return false, "failed to start reading from " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    if not manager:start() then
      return false, "failed to start reading from at least one " .. _NAME .. " in configuration"
    end
  end

  return true, ""
end

function start_take(name, description)
  if is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  -- Start reading.
  if not is_reading() then
    local result, message = start()
    if not result then
      return result, message
    end
  end

  -- Create default parameter values.
  if not name then
    name = ""
  end
  if not description then
    description = ""
  end 

  -- Start take.
  if not manager:start_take(name, description) then
    return false, "failed to start take"
  end

  return true, ""
end

function stop(id)
  if not is_reading(id) then
    if id then
      return false, "failed precondition \"is_reading(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition \"is_reading() == true\""
    end
  end

  -- Stop take.
  if is_taking() then
    local result, message = stop_take()
    if not result then
      return result, message
    end
  end

  -- Stop reading.
  if id then
    if not manager:stop(id) then
      return false, "failed to stop reading from " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    if not manager:stop() then
      return false, "failed to stop reading from at least one " .. _NAME .. " in configuration"
    end
  end

  return true, ""
end

function stop_take()
  if not manager:is_taking() then
    return false, "failed precondition, \"is_taking() == true\""
  end

  -- Stop take.
  if not manager:stop_take() then
    return false, "failed to stop take"
  end

  return true, ""
end

function take()
  return manager:take()
end


function bluetooth.enumerate()
  if is_connected() then
    return nil
  end
  if connected() then
    return nil
  end
  
  if base.type(manager["enumerate_bluetooth"]) == base.type(function () end) then
    return manager:enumerate_bluetooth()
  else
    return nil
  end
end

function bluetooth.write_configuration(id, write_factory)
  return false, "not implemented for Bluetooth devices"
end


function emulate.enumerate()
  if is_connected() then
    return nil
  end
  if connected() then
    return nil
  end
  
  if base.type(manager["enumerate_emulate"]) == base.type(function () end) then
    return manager:enumerate_emulate()
  else
    return nil
  end
end

function emulate.write_configuration(id, write_factory)
  return false, "not implemented for Emulated devices"
end


function plugin.enumerate()
  if is_connected() then
    return nil
  end
  if connected() then
    return nil
  end

  if base.type(manager["enumerate_plugin"]) == base.type(function () end) then
    return manager:enumerate_plugin()
  else
    return nil
  end
end


function usb.enumerate()
  if is_connected() then
    return nil
  end
  if connected() then
    return nil
  end

  if base.type(manager["enumerate_usb"]) == base.type(function () end) then
    return manager:enumerate_usb()
  else
    return nil
  end
end

function usb.restore_configuration(id)
  if not is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  if is_connected(id) then
    return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
  end

  if base.type(manager["restore_configuration_usb"]) == base.type(function () end) then
    if not manager:restore_configuration_usb(id) then
      return false, "failed to restore factory configuration to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    return false, "not implemented for USB devices"
  end

  return true, ""
end

function usb.write_configuration(id, write_factory)
  if not is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  if is_connected(id) then
    return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
  end

  if nil == write_factory then
    if _super then
      write_factory = true
    else
      write_factory = false
    end
  end

  if base.type(manager["write_configuration_usb"]) == base.type(function () end) then
    if not manager:write_configuration_usb(id, write_factory) then
      return false, "failed to write configuration to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    return false, "not implemented for USB devices"
  end

  return true, ""
end

function system.calibrate_from_take(id, calibrate_accelerometer)
  if not have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  if not system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end
  
  -- Only calibrate the accelerometers if we specifically ask for it.
  if nil == calibrate_accelerometer then
    if _super then
      calibrate_accelerometer = true
    else
      calibrate_accelerometer = false
    end
  end

  if not manager:calibrate_from_take(id, calibrate_accelerometer) then
    return false, "failed to generate " .. _NAME .. " calibration from take data"
  end
  
  return true, ""
end

function system.configuration_matches_take()
  if not have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  
  if not manager:configuration_matches_take() then
    return false, "current configuration does not match current take"
  end

  return true, ""
end

function system.console_client(address, port)
  if not address or string.len(address) == 0 then
    address = "127.0.0.1"
  end
  if not port then
    port = 0
  end
  
  if not manager:console_client(address, port) then
    return false, "failed to create connection to address \"" .. address .. "\" on port " .. port
  end
  
  return true, ""
end

function system.disable_input()
  if not manager:disable_input() then
    return false, "failed to disable remote input"
  end

  return true, ""
end

function system.enable_input(address, port)
  if not address then
    address = ""
  end
  if not port then
    port = 0
  end
  
  if not manager:enable_input(address, port) then
    return false, "failed to enable remote input address \"" .. address .. "\" on port " .. port
  end
  
  return true, ""
end

function system.export_type()
  -- Export type definitions.
  local bvh = {
    ["description"] = "Biovision BVH",
    ["option"] = "precision=0"
  }
  local csv = {
    ["description"] = "Comma Separated Value (CSV) text format",
    ["option"] = "header=1,space=0"
  } 
  local dae = {
    ["description"] = "COLLADA Document Object Model (DOM)",
    ["option"] = "xsi=0"
  }
  local fbx = {
    ["description"] = "Autodesk FBX",
    ["option"] = "binary=1,format=-1"
  }
  local mov = {
    ["description"] = "Maya move ASCII channel data",
    ["option"] = "precision=0"
  }
  local svg = {
    ["description"] = "Scalable Vector Graphics (SVG)",
    ["option"] = ""
  } 

  local valid_type = {
    ["bvh"] = bvh,
    ["csv"] = csv,
    ["dae"] = dae,
    ["fbx"] = fbx,
    ["mov"] = mov,
    ["svg"] = svg
  }
  
  -- A few more valid types that reference already existing types.
  valid_type["xml"] = valid_type["dae"]
  valid_type["move"] = valid_type["mov"]
  valid_type["txt"] = valid_type["mov"]

  return valid_type
end

function system.file_exists(filename)
  if not filename then
    filename = ""
  end

  if not manager:file_exists(filename) then
    return false
  end

  return true
end

function system.geocode_address(address)
  if not address then
    address = ""
  end

  if not manager:geocode_address(address) then
    return false, "failed to geocode address \"" .. address .. "\""
  end

  return true, ""
end

function system.get_default(name)
  if not name then
    name = ""
  end
  
  return manager:get_default(name)
end

function system.get_history()
  return _history
end

function system.get_preference()
  return manager:get_preference()
end

function system.initialize()
  if false == _initialized then
    if not system.file_exists(_initialize_filename) then
      return false, "failed precondition \"system.file_exists(\"" .. _initialize_filename .. "\") == true\""
    end

    if load_script(_initialize_filename) then
      _initialized = true
    else
      return false, "failed to load initialization file, \"" .. _initialize_filename .. "\""
    end
  end

  return true, ""
end

function system.is_filename(filename)
  if not filename then
    filename = ""
  end

  return manager:is_filename(filename)
end

function system.is_initialized()
  return true == _initialized
end

function system.load_plugin(name)
  if is_connected() then
    return false, "failed precondition, \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if not name then
    name = ""
  end

  if base.type(manager["load_plugin"]) == base.type(function () end) then
    if not manager:load_plugin(name) then
      if string.len(name) > 0 then
        return false, "failed load plugin named \"" .. name .. "\""
      else
        return false, "failed to load at least one plugin"
      end
    end
  else
    return false, "plugin interface not implemented"
  end

  return true, ""
end

function system.location(latitude, longitude, elevation, address)
  if latitude <= -90 or latitude >= 90 then
    return false, "failed precondition \"-90 < latitude < 90\""
  end
  
  if longitude <= -180 or longitude >= 180 then
    return false, "failed precondition \"-180 < longitude < 180\""
  end
  
  if elevation < -1000 or elevation > 600000 then
    return false, "failed precondition \"-1000 <= elevation <= 600000\""
  end
  
  if not address then
    address = ""
  end

  if not manager:location(latitude, longitude, elevation, address) then
    return false, "failed to set location, invalid parameter"
  end
  
  return true, ""
end

function system.log(filename)
  if not filename then
    filename = ""
  end

  if not system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end
  
  if system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end  

  if not manager:log(filename) then
    return false, "failed to set log file \"" .. filename .. "\""
  end
  
  return true, ""
end

function system.open_database(filename)
  if not filename then
    filename = ""
  end

  if not system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  
  if system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end

  if not manager:open_database(filename) then
    return false, "failed to open database file \"" .. filename .. "\""
  end
  
  return true, ""
end

function system.print(...)
  local result = ""
  for key,value in base.ipairs(arg) do
    result = result .. base.tostring(value)
  end
  result = result .. "\n"

  manager:print(result)
end

function system.quit()
  return manager:quit()
end

function system.restart()
  return manager:restart()
end

function system.save_initialization()
  local script_filename = "/index.lua"
  
  if not system.is_filename(_initialize_filename) then
    return false, "failed precondition \"system.is_filename(\"" .. _initialize_filename .. "\") == true\""
  end 
  if not system.file_exists(script_filename) then
    return false, "failed precondition \"system.file_exists(\"" .. script_filename .. "\") == true\""
  end

  if not manager:save_initialization(_initialize_filename, script_filename) then
    return false, "failed to save initialization to file, \"" .. _initialize_filename .. "\""
  end

  -- If the default location file exists at this point, write the
  -- current configuration out to it.
  if system.file_exists(_location_filename) then
    local result, message = system.save_location()
    if not result then
      return false, message
    end
  end

  return system.initialize()
end

function system.save_location(filename)
  local script_filename = "/location.lua"

  if not filename then
    filename = _location_filename
  end
  
  if not system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. _initialize_filename .. "\") == true\""
  end 
  if not system.file_exists(script_filename) then
    return false, "failed precondition \"system.file_exists(\"" .. script_filename .. "\") == true\""
  end
  
  if not manager:save_location(filename, script_filename) then
    return false, "failed to current location to file, \"" .. filename .. "\""
  end

  return true, ""
end

function system.set_data_path(path)
  if not path then
    path = ""
  end
  if system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end  
  
  if not manager:set_data_path(path) then
    return false, "failed to set data path \"" .. path .. "\""
  end
  
  return true, ""
end

function system.set_default(name, value)
  if not name then
    name = ""
  end
  if not value then
    value = ""
  end 
  
  return manager:set_default(name, value)
end

function system.set_search_path(path)
  if not path then
    path = ""
  end
  if system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end 
   
  if not manager:set_search_path(path) then
    return false, "failed to set search path \"" .. path .. "\""
  end
  
  return true, "" 
end

function system.sleep(seconds)
  return manager:sleep(seconds)
end

function system.start_services(service)
  if system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end

  local result = true
  local message = ""

  for name,port in base.pairs(service) do
    if base.type(manager[name]) == base.type(function() end) then
      -- Lua syntax to call a member function by string name,
      -- instance:method(arg) == instance["method"](instance, arg)
      service[name] = manager[name](manager, port)

      if not service[name] then
        -- Only describe the first failed service.
        if result then
          message = "failed to start service \"" .. name .. "\" on port " .. base.tostring(port)
        end
        result = false
      end
    else
      -- Only describe the first failed service.
      if result then
        message = "service \"" .. name .. "\" not implemented, failed to start on port " .. base.tostring(port)
      end
      result = false
    end
  end

  return result, message
end

function system.unique_id(id)
  if not is_id(id) then
    return false, "failed precondition \"is_id(\"" .. id .. "\") == true\""
  end
  
  if not is_configured(id) then
    return true, id
  end

  local postfix = 1

  -- Search for an existing integer postfix. If there is
  -- one, use that as our base.
  local i, j = string.find(id, "%d+$")
  if i and j then
    postfix = base.tonumber(string.sub(id, i, j)) + 1
    id = string.sub(id, 1, i-1)
  end

  return system.unique_id(id .. base.tostring(postfix))
end

function system.unload_plugin(name)
  if is_connected() then
    return false, "failed precondition, \"is_connected() == false\""
  end
  if connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if not name then
    name = ""
  end  

  if base.type(manager["unload_plugin"]) == base.type(function () end) then
    if not manager:unload_plugin(name) then
      return false, "failed to unload at least one plugin"
    end
  else
    return false, "plugin interface not implemented"
  end

  return true, ""
end

function xml.command_to_xml(command, ...)
  local fn = _M[command]

  -- Split commands of the form "table.command" and
  -- bind fn to the _M[table][command] entry.
  local command1, command2
  _, _, command1, command2 = string.find(command, "^([^%.]+)%.([^%.]+)$")
  if command1 and command2 then
    fn = _M[command1][command2]
  end


  local result = ""
  local n = table.getn(arg)
  if n > 0 then
    if n > 1 then
      if n > 2 then
        if n > 3 then
          result = xml.result_to_xml(fn(arg[1], arg[2], arg[3], arg[4]))
        else
          result = xml.result_to_xml(fn(arg[1], arg[2], arg[3]))
        end
      else
        result = xml.result_to_xml(fn(arg[1], arg[2]))
      end
    else
      result = xml.result_to_xml(fn(arg[1]))
    end
  else
    result = xml.result_to_xml(fn())
  end

  return
    "<?xml version=\"1.0\"?>" ..
    "<methodResponse><params>" ..
    result ..
    "</params></methodResponse>"
end

function xml.command_table_to_xml(command, ...)
  local module_command

  local command1, command2
  _, _, command1, command2 = string.find(command, "^([^%.]+)%.([^%.]+)$")
  if command1 and command2 then
    module_command = _M[command1][command2]
  end

  return xml.command_to_xml(module_command, args)
end

function xml.encode_attribute(value)
  local result = xml.encode_string(value) 
  result = string.gsub(result, "\"", "&quot;")
  return result
end

function xml.encode_string(value)
  local result = base.tostring(value) 
  result = string.gsub(result, "&", "&amp;")
  result = string.gsub(result, "<", "&lt;")
  result = string.gsub(result, ">", "&gt;")
  result = string.gsub(result, "\\", "\\\\")
  return result
end

function xml.result_to_xml(...)
  -- Make a table of type conversions for
  -- XML output.
  local xml_type = {
    ["string"]  = base.type(""),
    ["number"]  = base.type(0.0),
    ["boolean"] = base.type(true)
  }

  local result = ""
  for key,value in base.ipairs(arg) do
    local value_type = xml_type[base.type(value)]
    if not value_type then
      value = base.tostring(value)
      value_type = base.type(value)
    end
    
    result = result .. "<param><value><" .. value_type
    if nil ~= value then
      if base.type(true) == base.type(value) then
        if true == value then
          value = 1
        else
          value = 0
        end
      end

      result =
        result .. ">" .. xml.encode_string(value) ..
        "</" .. value_type .. ">"
      else
        result = result .. "/>"
    end
    result = result .. "</value></param>"
  end
  return result;
end

--
-- End public function definitions.
--
