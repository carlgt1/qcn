/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// FLASH
//-----------------------------------------------------------------------------
#ifndef FLASH_H
#define FLASH_H

#include "upsd34xx.h"

//-----------------------------------------------------------------------------
#define DATA_POLLING_FLAG 0x80 /* DQ7 */
#define ERROR_FLAG        0x20 /* DQ5 */
#define ERROR_ERASE_FLAG  0x04 /* DQ3 */

#define FSx_ADDR_BEGIN  fs.begin
#define FSx_ADDR_END    fs.end
#define FSx_PAGES       fs.pages
#define FSx_SIZE        fs.size

//-----------------------------------------------------------------------------
typedef struct {  
  u16 begin;
  u16 end;
  u8  pages;
  u16 size;
} t_fs;

//-----------------------------------------------------------------------------
u32  FLASH_Space (u16 begin, u16 end, u8 pages);
u8   FLASH_Wait_Polling (vu8 xdata *addr);

void FLASH_Write_Byte (u32 lin_addr, u8 dato);
void FLASH_Write_Mems (u32 lin_addr, u8 *mems_data_buff);

void FLASH_Read_Byte (u32 lin_addr, u8 *dato);
void FLASH_Read_Mems (u32 lin_addr, u8 *mems_data_buff);

void Flash_Erase_Page (u8 page);
void Flash_Erase_Pages (void);

//-----------------------------------------------------------------------------
#endif
  