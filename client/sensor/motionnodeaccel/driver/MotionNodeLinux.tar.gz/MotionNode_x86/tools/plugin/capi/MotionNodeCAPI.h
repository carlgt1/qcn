/**
  @file    MotionNodeCAPI.h
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2

  (C) Copyright GLI Interactive LLC 2008. All rights reserved.

  The coded instructions, statements, computer programs, and/or related
  material (collectively the "Data") in these files contain unpublished
  information proprietary to GLI Interactive LLC, which is protected by
  US federal copyright law and by international treaties.

  The Data may not be disclosed or distributed to third parties, in whole
  or in part, without the prior written consent of GLI Interactive LLC.

  The Data is provided "as is" without express or implied warranty, and
  with no claim as to its suitability for any purpose.
*/
#ifndef __MOTIONNODE_CAPI_H_
#define __MOTIONNODE_CAPI_H_

#if defined(WIN32)
#  if defined(STATIC_CAPI)
#    define MOTIONNODE_CAPI_IMPORT_API
#  else
#    if defined(BUILD_CAPI)
#      define MOTIONNODE_CAPI_IMPORT_API __declspec(dllexport)
#    else
#      define MOTIONNODE_CAPI_IMPORT_API __declspec(dllimport)
#    endif /* BUILD_CAPI */
#  endif /* STATIC_CAPI */
#  if defined(STDCALL_CAPI)
#    define MOTIONNODE_CAPI_CALL_API __stdcall
#  else
#    define MOTIONNODE_CAPI_CALL_API __cdecl
#  endif /* STDCALL_CAPI */
#else
#  define MOTIONNODE_CAPI_IMPORT_API
#  define MOTIONNODE_CAPI_CALL_API
#endif /* WIN32 */


#ifdef __cplusplus
extern "C" {
#endif

#define MNCAPI_PREVIEW_SIZE (14)
#define MNCAPI_SENSOR_SIZE   (9)
#define MNCAPI_RAW_SIZE      (9)

enum mncapi_error_t {
  MNCAPI_FAILURE = 0,
  MNCAPI_SUCCESS = 1
};

enum mncapi_stream_t {
  MNCAPI_PREVIEW  = 1,
  MNCAPI_SENSOR   = 2,
  MNCAPI_RAW      = 3
};

enum mncapi_blocking_t {
  MNCAPI_NOBLOCK  = -1,
  MNCAPI_FOREVER  =  0,
  MNCAPI_DEFAULT  =  1
};

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_open(enum mncapi_stream_t type);

MOTIONNODE_CAPI_IMPORT_API
void MOTIONNODE_CAPI_CALL_API
mncapi_close(int handle);

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_set_blocking(int handle, int second);

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_sample(int handle, float * data, int data_size);

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_sample_int16(int handle, short * data, int data_size);

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_get_preview(float * data);

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_get_sensor(float * data);

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_get_raw(short * data);

MOTIONNODE_CAPI_IMPORT_API
int MOTIONNODE_CAPI_CALL_API
mncapi_open_host(enum mncapi_stream_t type, const char * host, int port);

#ifdef __cplusplus
}
#endif

#endif /* __MOTIONNODE_CAPI_H_ */
