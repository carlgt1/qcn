/**
  @file    javascript/Edit.js
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2
*/

/**
  Open an editable text field based on the value of a DOM
  element. When the editable field loses focus execute the
  user defined command if the text value has changed.
  
  Only edit one field at a time, based on property _editing_id.
*/
var GLI_Edit = function() {
  var _element_id = 'edit';
  var _editing_id = null;
  var _command = null;
  var _argument = null;

  return {
    element_id : _element_id,
  
    open : function(element, command, argument)
    {
      if (null === _editing_id) {
        var edit = document.getElementById(_element_id);
        edit.innerHTML = '';
    
        var position = GLI_Position.compute(element);
        edit.style.left = position.left.toString() + 'px';
        edit.style.top = position.top.toString() + 'px';
    
        var length = 10;
        if (element.className == 'edit_float') {
          length = 5;
        }
    
        var input = document.createElement('input');
        if (input) {
          edit.appendChild(input);
    
          input.setAttribute('size', Math.max(length,element.innerHTML.length + 5));
          input.setAttribute('type', 'text');
          input.setAttribute('value', text_content(element));
          
          GLI_EventListener.insert(input, 'blur', GLI_Edit.close);
          GLI_EventListener.insert(input, 'keypress', GLI_Edit.keypress);
    
          edit.style.display = 'block';
          input.focus();
          input.select();
          
          _editing_id = element.id;
          _command = command;
          _argument = argument;
        }
      }
      
      return true;
    },
    close : function()
    {
      if (null !== _editing_id) {  
        var edit = document.getElementById(_element_id);
        var value = edit.firstChild.value;
        var element = document.getElementById(_editing_id);
        
        GLI_EventListener.erase_element(edit.firstChild);
    
        if (value !== text_content(element)) {
          if ('edit_float' === element.className) {
            value = parseFloat(value);
            if (isNaN(value)) {
              value = 0;
            }
          }
    
          _editing_id = null;
          GLI_Command.send(_command, value, _argument);
        }
        element.innerHTML = value;
    
        edit.style.display = 'none';
        edit.innerHTML = '';
        
        _editing_id = null;
        _command = null;
        _argument = null;
      }
      return true;
    },
    keypress : function(event)
    {
      if (null !== _editing_id) {
        if (event && (13 === event.keyCode)) {
          GLI_Edit.close();
          GLI_EventListener.stop(event);
          return false;
        }
      }
      return true;
    }
  }
}();
// END module GLI_Edit
