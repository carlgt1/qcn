/**
  @file    example.c
  @author  Luke Tokheim, luke@motionnode.com
  @version 1.2

  (C) Copyright GLI Interactive LLC 2008. All rights reserved.

  The coded instructions, statements, computer programs, and/or related
  material (collectively the "Data") in these files contain unpublished
  information proprietary to GLI Interactive LLC, which is protected by
  US federal copyright law and by international treaties.

  The Data may not be disclosed or distributed to third parties, in whole
  or in part, without the prior written consent of GLI Interactive LLC.

  The Data is provided "as is" without express or implied warranty, and
  with no claim as to its suitability for any purpose.
*/
#include <MotionNodeCAPI.h>
#include <stdio.h>

/**
  Number of active sensors for the "example_raw" function.
  Note that this example can be extended to the other
  stream types.
*/
#define RAW_NUM_DEVICE 1


void example_preview()
{
  int handle = mncapi_open(MNCAPI_PREVIEW);
  if (handle > 0)
  {
    float data[MNCAPI_PREVIEW_SIZE];
    if (MNCAPI_SUCCESS == mncapi_sample(handle, data, MNCAPI_PREVIEW_SIZE))
    {
      /* Have a sample of preview data, print it out. */
      printf("q = {%f, %f, %f, %f}\n",
        data[0], data[1], data[2], data[3]);
      printf("q_local = {%f, %f, %f, %f}\n",
        data[4], data[5], data[6], data[7]);
      printf("euler = {%f, %f, %f} radian\n", data[8], data[9], data[10]);
      printf("accel = {%f, %f, %f} g\n", data[11], data[12], data[13]);

      /* Possibly more useful formatting.
      printf("q       = {% 1.2f, % 1.2f, % 1.2f, % 1.2f}\n",
        data[0], data[1], data[2], data[3]);
      printf("q_local = {% 1.2f, % 1.2f, % 1.2f, % 1.2f}\n",
        data[4], data[5], data[6], data[7]);
      printf("euler   = {% 1.3f, % 1.3f, % 1.3f} radian\n",
        data[8], data[9], data[10]);
      printf("accel   = {% 1.3f, % 1.3f, % 1.3f} g\n",
        data[11], data[12], data[13]);
      */

      printf("\n");
    }
    mncapi_close(handle);
  }
}

void example_sensor()
{
  int handle = mncapi_open(MNCAPI_SENSOR);
  if (handle > 0)
  {
    float data[MNCAPI_SENSOR_SIZE];
    if (MNCAPI_SUCCESS == mncapi_sample(handle, data, MNCAPI_SENSOR_SIZE))
    {
      /* Have a sample of sensor data, print it out. */
      printf("a = {%f, %f, %f} g\n", data[0], data[1], data[2]);
      printf("m = {%f, %f, %f} uT\n", data[3], data[4], data[5]);
      printf("g = {%f, %f, %f} deg/sec\n", data[6], data[7], data[8]);

      /* Possibly more useful formatting.
      printf("a = {% 1.3f, % 1.3f, % 1.3f} g\n", data[0], data[1], data[2]);
      printf("m = {% 2.2f, % 2.2f, % 2.2f} uT\n", data[3], data[4], data[5]);
      printf("g = {% 3.1f, % 3.1f, % 3.1f} deg/sec\n",
        data[6], data[7], data[8]);
      */

      printf("\n");
    }
    mncapi_close(handle);
  }
} 

void example_raw()
{
  int handle = mncapi_open(MNCAPI_RAW);
  if (handle > 0)
  {
    short data[MNCAPI_RAW_SIZE*RAW_NUM_DEVICE];
    if (RAW_NUM_DEVICE == mncapi_sample_int16(handle, data, MNCAPI_RAW_SIZE*RAW_NUM_DEVICE))
    {
      int i;
      short * p = data;

      for (i=0; i<RAW_NUM_DEVICE; i++) {
        /* Have a sample of raw data, print it out. */
        if (RAW_NUM_DEVICE > 1) {
          printf("device = {%i}\n", i);
        }
        printf("a = {%i, %i, %i}\n", p[0], p[1], p[2]);
        printf("m = {%i, %i, %i}\n", p[3], p[4], p[5]);
        printf("g = {%i, %i, %i}\n", p[6], p[7], p[8]);
        printf("\n");

        p += MNCAPI_RAW_SIZE;
      }
    }
    mncapi_close(handle);
  }
} 

void example_simple_api()
{
  {
    float data[14];
    if (MNCAPI_SUCCESS == mncapi_get_preview(data))
    {
      // ... Use data
    }

    // Optional step, clean up resources.
    mncapi_close(MNCAPI_PREVIEW);
  }

  {
    float data[9];
    if (MNCAPI_SUCCESS == mncapi_get_sensor(data))
    {
      // ... Use data
    }

    // Optional step, clean up resources.
    mncapi_close(MNCAPI_SENSOR);
  }

  {
    short data[9];
    if (MNCAPI_SUCCESS == mncapi_get_raw(data))
    {
      // ... Use data
    }

    // Optional step, clean up resources.
    mncapi_close(MNCAPI_RAW);
  }
}


int main(int argc, char * argv[])
{
  example_preview();
  example_sensor();
  example_raw();

  example_simple_api();

  return 0;
}
