//
//  AppController+Devices.m
//  JoyWarrior Tilt Utility
//
//  Created by ilja on 19.02.08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AppController+Devices.h"
#import "DiscoverHIDInterface.h"

@implementation AppController (Devices)


- (NSArray*) discoverInterfacesWithDeviceID:(UInt16) inDeviceID
{
    CFMutableArrayRef newInterfaces;
	
	newInterfaces = CreateDiscoverHIDInterfaces(0x07c0, inDeviceID);
	if (newInterfaces && CFArrayGetCount (newInterfaces) >= 2)
    {
        NSArray *result = [NSArray arrayWithArray:(NSArray*)newInterfaces];
        CFRelease(newInterfaces);
		return result;
	}
    if ( newInterfaces )
    {
        CFRelease (newInterfaces);
    }
    return nil;
}

- (NSArray*) discoverDevicePropertiesWithDeviceID:(UInt16) inDeviceID
{
    CFMutableArrayRef deviceProperties;
	
	deviceProperties = CreateDiscoverHIDDeviceProperties(0x07c0, inDeviceID);
	if (CFArrayGetCount (deviceProperties) >= 2)
    {
        NSArray *result = [NSArray arrayWithArray:(NSArray*)deviceProperties];
        CFRelease(deviceProperties);
		return result;
	}
    if ( deviceProperties )
    {
        CFRelease (deviceProperties);
    }
    return nil;
}

- (NSArray *) discoverInterfaces
{
	NSMutableArray *result = [NSMutableArray array];
    
    [result addObjectsFromArray: [self discoverInterfacesWithDeviceID: 0x1113]]; // JoyWarrior24 Force 8
    
    [result addObjectsFromArray: [self discoverInterfacesWithDeviceID: 0x1114]]; // MouseWarrior24 Force 6
    
    [result addObjectsFromArray: [self discoverInterfacesWithDeviceID: 0x1116]]; // JoyWarrior24 Force 14
    
    return (NSArray*)result;
}

- (NSArray *) discoverDeviceProperties
{
	NSMutableArray *result = [NSMutableArray array];
    
    [result addObjectsFromArray:[self discoverDevicePropertiesWithDeviceID: 0x1113]]; // JoyWarrior24 Force 8
    
    [result addObjectsFromArray: [self discoverDevicePropertiesWithDeviceID: 0x1114]]; // MouseWarrior24 Force 6
    
    [result addObjectsFromArray: [self discoverDevicePropertiesWithDeviceID: 0x1116]]; // JoyWarrior24 Force 14
    
    return (NSArray*)result;
}

@end
