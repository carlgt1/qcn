/************************ (c) 2004 STMicroelectronics ************************ 
VERSION:       3.0
DATE:          22/04/2005
AUTHOR:        Robert Hornych
COMPILER:      SDCC (v2.4.0)
COMPILER:      KEIL (C-compiler v7.05; Assembler v7.04a; Linker v5.03)
******************************************************************************
THE SOFTWARE INCLUDED IN THIS FILE IS FOR GUIDANCE ONLY. ST MICROELECTRONICS
SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES
WITH RESPECT TO ANY CLAIMS ARISING FROM USE OF THIS SOFTWARE.
******************************************************************************/

//-----------------------------------------------------------------------------
// I2C
//-----------------------------------------------------------------------------
#ifndef I2C_H
#define I2C_H

#include "upsd34xx.h"

//-----------------------------------------------------------------------------
//| Choose speed of I2C                         |
//|---------------------------------------------|
//| Bit Rate (kHz) @ fosc                       |
//|---------------------------------------------|
//| CR2 CR1 CR0 | 12MHz | 24MHz | 36MHz | 40MHz |
//|---------------------------------------------|
//|   0 0 0     |  375  |  750  |  ---  |  ---  |
//|   0 0 1     |  250  |  500  |  750  |  833  |
//|   0 1 0     |  200  |  400  |  600  |  666  |
//|   0 1 1     |  100  |  200  |  300  |  333  | S1CON_VALUE = 0x03;
//|   1 0 0     |   50  |  100  |  150  |  166  | S1CON_VALUE = 0x80;
//|   1 0 1     |   25  |   50  |   75  |   83  | S1CON_VALUE = 0x81;
//|   1 1 0     |   12.5|   25  |   37.5|   41  |
//|   1 1 1     |   6.25|   12.5|  18.75|   20  |
//|---------------------------------------------|
#define S1CON_VALUE (u8)(0x80) 

//-----------------------------------------------------------------------------
//| Choose number of samples                                     |
//|--------------------------------------------------------------|
//| fosc (MHz)                |    6 |   12 |   24 |   33 |   40 |
//| STANDART                  |      |      |      |      |      |
//| S1SETUP Value             | 0x93 | 0xA7 | 0xCF | 0xEE | 0xFF | 
//| Number of Samples         |   20 |   40 |   80 |  111 |  128 |
//| FAST                      |      |      |      |      |      |
//| S1SETUP Value             | 0x82 | 0x85 | 0x8B | 0x90 | 0x93 | 
//| Number of Samples         |    3 |    6 |   12 |   17 |   20 |
//|--------------------------------------------------------------|
#define kS1SETUP_VALUE (u8)(0xCF)

//-----------------------------------------------------------------------------
//---address of slave I want to communicate---
#define kLIS3L02DQ_SLAVE_ADDR    0x3A 

//---according i2c protocol read/write---
#define kSLAVE_ADDR_WRITE        0x00
#define kSLAVE_ADDR_READ         0x01

//---i2c_state---
#define kMASTER_SEND             0x10
#define kMASTER_SEND_END         0x11
#define kMASTER_RECEIVE          0x20
#define kMASTER_RECEIVE_END      0x21
#define kNACK                    0xA1
#define kBUSLOST                 0xA2
#define kTIME_OUT                0xA3
#define kNO_ACTION               0xA4

//-----------------------------------------------------------------------------
// I2C basic functions
void I2C_Init        (void);
u8   i2c_master      (void);
u8   i2c_write_reg   (u8 device_addr, u8 reg_addr, u8 reg_value);
u8   i2c_read_reg    (u8 device_addr, u8 reg_addr, u8 length);
u8   i2c_test_BLOST  (void);
u8   i2c_test_ACKREP (void);

// I2C interrupt rutine
#if (COMPILER == SDCC)
  void i2c_isr (void) interrupt I2C_VECTOR using 2;
#endif

// READ DATA FROM I2C BUFFER
u8 i2c_read_buffer_u8 (u8 position, u8 *dato);
u8 i2c_read_buffer_u16 (u8 position, u16 *dato, u8 ble);

//-----------------------------------------------------------------------------
#endif
