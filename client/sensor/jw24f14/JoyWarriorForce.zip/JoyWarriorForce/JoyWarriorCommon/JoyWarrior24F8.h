/*
 *  JoyWarrior24F8.h
 *  JoyWarrior Programmingtool
 *
 *  Created by ilja on 03.11.07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <IOKit/hid/IOHIDLib.h>

int JWReadByteFromAddress (IOHIDDeviceInterface122 **hidInterface, UInt8 inAddress, UInt8 *result);
int JWWriteByteToAddress (IOHIDDeviceInterface122 **hidInterface, UInt8 inAddress, UInt8 inData);

SInt16 JWMergeAxisBytes (UInt8 inLSB, UInt8 inMSB);
SInt16 JWMergeOffsetBytes (UInt8 inLSB, UInt8 inMSB);

void JWDiffMsbLsb (UInt16 value, UInt8 *inLSB, UInt8 *inMSB);
