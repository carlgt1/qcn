#include <math.h>
#include <stdio.h>
#include <stdlib.h>

float average(float series[], int ndat);
float sqr(float fIn);
int rmean(int ndat, float series[]);
float wrms_tt(int nstn, float sx[], float sy[], float wt[], float ttobs[], float qx, float qy);
float wrms_misfit(int nstn, float ttobs[], float w[], float tt[]);
int min_loc(float x_cent, float y_cent, float dxi, float dyi, int nstn, float sx[], float sy[], float sw[], float ttobs[], float cx[], float cy[], float cr[], int *i_best);

int main()
{
/* This program was written to emulate how the server-side QCN  
 *         triggering software should work.  The codes is currently 
 *         written to run rapidly on a single processor. 
 *
 *      1) The QCN server receives triggers from 100s to 1000s of sensors.
 *         Each trigger has 1) a time (t), 2) a significance level (w), and 3) a 
 *         location (x,y), associated with it.
 *
 *      2) The server runs a grid search for a 100X100 node array at 10 km spacing.
 *         This program receives a list of triggers and tests the hypothesis that
 *         the source was at each of the 10,000 nodes. The grid is defined by the 
 *         center location of all of the trigger/sensor locations.
 *
 *      3) If the best node is at the edge of the grid search, repeat a grid  
 *         search with the grid re-defined by the previous best node.
 *
 *      4) Once the best node is found within the grid, repeat a grid search at 1km
 *         resolution with the grid defined with a center at the previos best node. 
 *
 *      5) This runs ~50 time faster than a single 1000X1000 grid search at 1 km 
 *         spacing.
 *
 *      6) The loaction outputs a contour of best solutions per batch.
 *           
 *      7) The location program outputs the single best solution of all batches.
 *
 */
   
   int    nlocx =  100; int nlocy =100;                  /*  # of possible X & Y points for EQ  */
   int    nnode =  nlocx*nlocy;                          /*  # of nodes to check                */
   float  r_best = 9999999., x_best, y_best;             /*  Best Lon, Lat, & RMS Misfit Of All */
   int    i;                                             /*  Counting index                     */
   float  rms;
   float  sx[nnode],sy[nnode],sw[nnode],ttobs[nnode];
   float  qx[nnode],qy[nnode],qr[nnode];
   int    i_best;
   FILE  *fpcont,*fpbest,*fptrig;                        /*  Input & Output Files               */
   fpbest = fopen("solution.xy","w");                    /*  Pre-Open Output Best Solution File */
   fpcont = fopen("contour.xyz" ,"w");                   /*  Pre-Open Output Best Solution File */
   fptrig = fopen("triggers.xywt","r");                  /*  Open Output File                   */

   i = 0;                                                /*  Assume Zero Triggers               */
   while ( fscanf(fptrig,"%f %f %f %f",&sx[i],&sy[i],&sw[i],&ttobs[i]) != EOF ) {
      i = i + 1;                                         /* Count Number of Triggers            */
   }
   
   fclose(fptrig);                                       /*  Close Trigger File                 */
   int nstn = i;                                         /*  Store the Number of Triggers       */

   float x_cent = average(sx,nstn);                      /*  Center of Grid Search = Cent of Trigs */ 
   float y_cent = average(sy,nstn);
   float dxi = 10.; float dyi = 10.;                     /*  Node Spacing */
   
   min_loc(x_cent,y_cent,dxi,dyi,nstn,sx,sy,sw,ttobs,qx,qy,qr,&i_best);
   x_cent = qx[i_best];
   y_cent = qy[i_best];
   dxi = 1.; dyi = 1.;
   printf("Epicenter: %f %f %f \n",qx[i_best],qy[i_best],qr[i_best]);/*Display Best Location 2 Screen*/   

   min_loc(x_cent,y_cent,dxi,dyi,nstn,sx,sy,sw,ttobs,qx,qy,qr,&i_best);
   
   printf("Epicenter: %f %f %f \n",qx[i_best],qy[i_best],qr[i_best]);/*Display Best Location 2 Screen*/   
   fprintf(fpbest,"%f %f \n",qx[i_best],qy[i_best],qr[i_best]);            /*  Output Best Loc 2 File: Solution.xy*/
   
   for (i = 0; i <= nnode; i++) {
      fprintf(fpcont,"%f %f %f \n",qx[i],qy[i],qr[i]/qr[i_best]);
   }

   float qr_best = qr[i_best];
   x_cent = qx[i_best]; y_cent = qy[i_best];
   dxi = 10.; dyi = 10.;
   min_loc(x_cent,y_cent,dxi,dyi,nstn,sx,sy,sw,ttobs,qx,qy,qr,&i_best);
   for (i = 0; i <= nnode; i++) {
      fprintf(fpcont,"%f %f %f \n",qx[i],qy[i],qr[i]/qr_best);
   }

   fclose(fpcont);fclose(fpbest);                       /*  Close Output Files                 */
}


float average(float series[], int ndat)
{
   float fave = 0.; int i;
   for (i = 0; i <= ndat; i++) {      fave = fave + series[i];}
   fave = fave / (float)ndat;
   return fave;
}

int min_loc(float x_cent, float y_cent, float dxi, float dyi, int nstn, float sx[], float sy[], float sw[], float ttobs[], float cx[], float cy[], float cr[], int *i_best)
{
/* This program was written to emulate how the client-side QCN distributed computing
 *         triggering software should work.
 *
 *      1) Determine the Batch of epicenter solutions to test (compute the Root
 *         Mean Square (RMS) Misfits for - acutally a weighted RMS). 
 * 
 *      2) Read in a list of triggers, which include 1) a time (ttobs), 2) a
 *         significance level (wt), and 3) a location (sx,sy).
 *
 *      3) Compute the theoretical travel times from the hypothetical epicenter
 *         location to each of the trigger locations (sensor locations).
 *
 *      4) Calculate the weighted RMS misfit. 
 *
 */
   float  Vp = 5.8;                      /*  P-wave Seismic Velocity (km/s)     */
   int    nlocx =  100; int nlocy =100;  /*  # of possible X & Y points for EQ  */
   int    nnode =  nlocx*nlocy;          /*  # of nodes to check                */
   double pi = atan(1.)*4.;              /*  Set pi = 3.14....                  */
   double d2k = 6371./180.*pi;           /*  km-to-degree conversion            */
   float  dx = dxi/d2k;                  /*  Distance Interval for Y            */
   float  dy = dyi/d2k;                  /*  Distance Interval for Y            */
   int    i,j,k,ii,jj;                   /*  indices                            */
   float  rms;                           /*  Route Mean Squared Misfit          */
   float  rmsmin=9999999.; int irmsmn=-1;/*  Set Min error high to be reset     */
   float  qx[nnode],qy[nnode];

   j = -1; k = 0; ii = -1;                /*  Starting Lon & Lat Indices         */
   for (i = 0; i <= nnode; i++) {        /*  For each node                      */
      j = j + 1;                         /*  Step through longitude positions   */
      if (j > nlocx) {                   /*  Loop back to 0 point if > nlocx    */
         j=0;                            /*  Step through Longitudes            */
         k=k+1;                          /*  Step through Latitudes             */
      }
      ii = ii + 1;
      qx[ii] = x_cent + dx*(float)(j-nlocx/2);/*  Node Longitude                */
      qy[ii] = y_cent + dy*(float)(k-nlocy/2);/*  Node Latitude                 */
   } 

   rmin(nstn, ttobs);                    /*  Remove the Min Time from Series    */
   
   for (i = 0; i <= nnode; i++) {        /*  For Each Node/Epicenter            */
      rms = wrms_tt(nstn, sx, sy, sw, ttobs, qx[i], qy[i]);/* Calc RMS MF  */
      if (rms < rmsmin) {                /*  Store Best/Min Misfit Solution     */
         rmsmin = rms;                   /*      Store Min Misfit               */
         irmsmn = i;                     /*      Store Index of Min Misfit      */
      }                                  /*                                     */
      cx[i]=qx[i]; cy[i]=qy[i]; cr[i]=rms;
   }                                     /*                                     */
      
   *i_best = irmsmn;
//   printf("%f %f %f \n",cx[*i_best],cy[*i_best],cr[*i_best]);
}                                        /*                                     */


   
int rmean(int ndat, float series[])
{
/*  This subroutine removes the mean of a real series.                          */
   int i;                                /*  Index                              */
   float ave = 0.;                       /*  Zero summation before starting     */
   for (i = 0; i <= ndat; i++) {         /*                                     */
      ave = ave + series[i];             /*  Sum over series                    */
   }                                     /*                                     */
   ave = ave/((float)ndat);              /*  Normalize summation by # of points */
   for (i = 0; i <= ndat; i++) {         /*                                     */
      series[i] = series[i]-ave;         /*  Remove Mean                        */
   }                                     /*                                     */
}                                        /*                                     */



int rmin(int ndat, float series[])
{
/*  This subroutine removes the minimum value of a real series.                 */
   int i;                                /*  Index                              */
   float ave = 0.;                       /*                                     */  
   float min = 99999999.;                /*  Zero summation before starting     */
   for (i = 0; i <= ndat; i++) { if( series[i] < min ) {min = series[i];} }/* Find Minimum */
   for (i = 0; i <= ndat; i++) { series[i] = series[i]-min;}/*  Remove Min      */
}                                        /*                                     */


float sqr(float fIn)
{
/* There must be an intrinsic subroutine for this ... but I'm not a good C
 * Programmer.
 */
   float sqrf = fIn*fIn; return sqrf;
}

float rand01()
{
/* Creates a random number from zero to 1                                       */
   float r0 = rand()/((double)RAND_MAX + 1); return r0;
}

float wrms_tt(int nstn, float sx[], float sy[], float wt[], float ttobs[], float qx, float qy) 
{
/* This subroutine determines the Weighted Root Mean Square Misfit of a set of 
 *          travel times from an isotropic Vp = 5 km/s seismic velocity model.
 */ 
   double pi = atan(1.)*4.;              /*  Set pi = 3.14....                    */
   double d2k = 6371./180.*pi;           /*  km-to-degree conversion              */
   int j;                                /*  Index for stations                   */
   float factor;                         /*  Squeezing of meridians near poles    */
   float del, tt[nstn];                  /*  EQ-to-Station distance & travel time */
   float  rms;                           /*  Route-Mean Square Misfit             */
   for (j = 0; j < nstn; j++) {          /*                                       */
      factor = cos((qy+sy[j])/2.);       /*  longitude squeezing toward N Pole    */
      factor = sqrt(sqr(factor));        /*                                       */
      del    = sqrt( sqr(factor*(qx-sx[j])) + sqr(qy-sy[j]))*d2k;
      tt[j]  = del/5.8;                  /*  EQ to Station Travel Time            */
   }
   rmin(nstn, tt);                       /*  Remove the Average time from Series  */
   rms  = wrms_misfit(nstn,ttobs,wt, tt);/*  Route Mean Squared Misfit            */
   return rms;                           /*  Return the Weighted RMS Misfit       */
}

float wrms_misfit(int nstn, float ttobs[], float wt[], float tt[])
{
/* This subroutine determines the Weighted Root Mean Square Misfit of input observed
 *          (ttobs) and theoretical (tt) travel times.
 */
   float rms = 0.;                        /*  Root Mean Square Misfit             */
   int i;                                 /*  Index Counter                       */
   float wt_tot = 0.;                     /*  Total Weight (Denominator)          */
   
   for (i = 1; i < nstn; i++) {           /*  For Each Data Point                 */
      rms=rms+wt[i]*(sqr(ttobs[i]-tt[i]));/*  Sum for Numerator                   */
      wt_tot = wt_tot + wt[i];            /*  Sum for Denominator                 */
   }

   rms = sqrt(rms/(wt_tot));              /*  Divide and take Root                */
   
   return rms;                            /*  Return The RMS Misfit               */
} 




