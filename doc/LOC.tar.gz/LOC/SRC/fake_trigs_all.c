#include <math.h>
#include <stdio.h>
#include <stdlib.h>


float sqr(float fIn);
float rand01();

int main ()
/* This program was written to provide a set of fake triggers given a
 * fake epicenter location, and a set of sensor location.
 */

{
   float Vp = 5.8;                            /*  P-wave Seismic Velocity (km/s)     */
   float qx1, qy1;                            /*  EQ location                        */
   int   i,j,k;                               /*  Indices                            */
   FILE  *fp0, *fp1, *fp2, *fp3;              /*  File Names                         */
   
   srand( time(NULL) );                       /*  Initialize Randomizing Seed        */
   
   fp0 = fopen("epicenter.xy","r");           /*  Open Epicenter Input File          */
   fp1 = fopen("triggers.xywt","w");          /*  Open Output File                   */
   fp2 = fopen("sensor_locs.xy","r");         /*  Open Sensor Locations Input File   */
   fscanf(fp0,"%f %f",&qx1,&qy1);             /*  Input epicenter location           */
   
   int   nstn  = 1000;                        /*  Number of Stations                 */
   float  xmin = 237.;float ymin = 32.;       /*  Min longitude & latitude of grid   */
   int    nlocx =  1000; int nlocy =1000;     /*  # of possible X & Y points for EQ  */
   int    nnode =  nlocx*nlocy;               /*  # of nodes to check                */
   double pi = atan(1.)*4.;                   /*  Set pi = 3.14....                  */
   double d2k = 6371./180.*pi;                /*  km-to-degree conversion            */
   float  dx = 1./d2k; float dy = 1./d2k;     /*  Distance Interval for X & Y        */
   float sx[nstn],sy[nstn];                   /*  Sensor Locations                   */
   float sw[nstn];                            /*  Sensor Weight by Significance level*/
   
   j = 0;                                     /*  Start with Zero Sensors            */
   while ( fscanf(fp2,"%f %f",&sy[j],&sx[j]) != EOF ) { /*  Read In Lat & Lon   */
    if (sx[j] < 0.) {sx[j]=sx[j]+360.;};      /*  Make Lon from 0-360, not -180to180 */
    j = j + 1;                                /*  Count Sensors                      */
   }
   nstn = j;                                  /*  Reset # of Sensors                 */
   
   float  tt[nstn];                           /*  EQ-to-Sensor Travel Time Matrix    */
   float  factor;                             /*  Factor Narrows Meridians w/ Lat    */ 
   float  ttobs[nstn];                        /*  Create Fake Observed Travel Times  */ 
   float  sig;                                /*  RMS Misfit OF Times                */
   float  del;                                /*  EQ-to-Sensor Distance              */
   
   for (j = 0; j < nstn; j++) {
     factor = cos((qy1+sy[j])/2.);            /*  Longitude squeezing toward N Pole  */
     factor = sqrt(sqr(factor));              /*                                     */
     del    = sqrt( sqr(factor*(qx1-sx[j])) + sqr(qy1-sy[j]) )*d2k;/* EQ-to-Sensor Distance */
     ttobs[j]=del/5.8 +0.1*(1-rand01()*2.);   /*  Travel time + Random Error         */
     if (del <= d2k/2.) {del = d2k/2.;}       /*  Don't Make Distance Scaling More Than 2.*/
     sw[j] = ( 1. + rand01() ) * 3./(del/d2k);/*  Set a random weight                */
     fprintf(fp1,"%f %f %f %f \n",sx[j],sy[j],sw[j],ttobs[j]);/*  Output Trigger*/
   }
   fclose(fp1); fclose(fp2); fclose(fp0);     /*  Close Input & Output Files         */
   return 0;                                  /*  Done                               */
}


float sqr(float fIn)
{
/* There must be an intrinsic subroutine for this ... but I'm not a good C
 * Programmer.
 */
   float sqrf = fIn*fIn; return sqrf;
}

float rand01()
{
/* Creates a random number from zero to 1                                            */
   float r0 = rand()/((double)RAND_MAX + 1); return r0;
}
